package gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon;

public class AppCompany_const {


//    public static String INTRESTITIAL_AD_PUB_ID = "ca-app-pub-2016753772242629/2687576773";
//    public static String SPLASH_INTRESTITIAL_AD_PUB_ID = "ca-app-pub-2016753772242629/4549229451";
//    public static String BANNER_AD_PUB_ID = "ca-app-pub-2016753772242629/5313740117";
//    public static String RECTANGLE_BANNER_AD_PUB_ID = "ca-app-pub-2016753772242629/5862311122";
//    public static String NATIVE_ADVANCE_AD_PUB_ID = "ca-app-pub-2016753772242629/1374495106";
//    public static String OPEN_APP_AD_PUB_ID = "ca-app-pub-2016753772242629/6802319286";

    public static boolean isActive_adMob = true;

    public static int is_show_open_ad = 1;

    public static String BANNER_AD_PUB_ID = "ca-app-pub-3940256099942544/6300978111";
    public static String RECTANGLE_BANNER_AD_PUB_ID = "ca-app-pub-3940256099942544/6300978111";
    public static String INTRESTITIAL_AD_PUB_ID = "ca-app-pub-3940256099942544/1033173712";
    public static String SPLASH_INTRESTITIAL_AD_PUB_ID = "ca-app-pub-3940256099942544/1033173712";
    public static String NATIVE_ADVANCE_AD_PUB_ID = "ca-app-pub-3940256099942544/1044960115";
    public static String OPEN_APP_AD_PUB_ID = "ca-app-pub-3940256099942544/9257395921";



}