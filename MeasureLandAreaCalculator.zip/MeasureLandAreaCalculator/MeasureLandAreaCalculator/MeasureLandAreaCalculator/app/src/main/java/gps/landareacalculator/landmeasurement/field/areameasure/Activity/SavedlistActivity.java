package gps.landareacalculator.landmeasurement.field.areameasure.Activity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;

import java.util.List;

import gps.landareacalculator.landmeasurement.field.areameasure.Adpter.SavedMesurmentAdpter;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.AppCompany_const;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.PrefManager;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.BaseActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.DatabaseHelper;
import gps.landareacalculator.landmeasurement.field.areameasure.Modelclass.MesurmentModel;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class SavedlistActivity extends BaseActivity {
    private RecyclerView rcv_saved_data;
    TextView  txt_no_data ;
    private SavedMesurmentAdpter saved_mesurement_adpter;
    private List<MesurmentModel> mesurment_list;
    private DatabaseHelper databaseHelper;
    ImageView img_back ;
    Toolbar toolbar;

    PrefManager prefManager;
    RelativeLayout layout;

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_savedlist);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        prefManager = new PrefManager(SavedlistActivity.this);
        layout = (RelativeLayout) findViewById(R.id.adView);
        if (!prefManager.getvalue()) {
            if (AppCompany_const.isActive_adMob) {
                com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(this);
                adView.setAdSize(getAdSize());
                adView.setAdUnitId(AppCompany_const.BANNER_AD_PUB_ID);
                layout.addView(adView);
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);

            }
        }

        rcv_saved_data = findViewById(R.id.rcv_saved_data);
        txt_no_data = findViewById(R.id.txt_no_data);
        img_back = findViewById(R.id.img_back);

        databaseHelper = new DatabaseHelper(this);

        rcv_saved_data.setLayoutManager(new LinearLayoutManager(this));

        mesurment_list = databaseHelper.getPolygonData();

        if (mesurment_list.isEmpty()) {
            txt_no_data.setVisibility(View.VISIBLE);
            rcv_saved_data.setVisibility(View.GONE);
            layout.setVisibility(View.GONE);
        } else {
            txt_no_data.setVisibility(View.GONE);
            rcv_saved_data.setVisibility(View.VISIBLE);
            saved_mesurement_adpter = new SavedMesurmentAdpter(this, mesurment_list, databaseHelper);
            rcv_saved_data.setAdapter(saved_mesurement_adpter);
            layout.setVisibility(View.VISIBLE);
        }

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}