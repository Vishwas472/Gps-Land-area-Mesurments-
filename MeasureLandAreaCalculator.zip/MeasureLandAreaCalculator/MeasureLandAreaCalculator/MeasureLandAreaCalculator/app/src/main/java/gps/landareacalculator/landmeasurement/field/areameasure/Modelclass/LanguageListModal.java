package gps.landareacalculator.landmeasurement.field.areameasure.Modelclass;

public class LanguageListModal {
    public int languageImage;
    public String languageName;
    public String languageCode;


    public LanguageListModal(int languageImage, String languageName, String languageCode) {
        this.languageImage = languageImage;
        this.languageName = languageName;
        this.languageCode = languageCode;
    }

    public int getLanguageImage() {
        return languageImage;
    }

    public void setLanguageImage(int languageImage) {
        this.languageImage = languageImage;
    }

    public String getLanguageName() {
        return languageName;
    }

    public void setLanguageName(String languageName) {
        this.languageName = languageName;
    }

    public String getLanguageCode() {
        return languageCode;
    }

    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }
}
