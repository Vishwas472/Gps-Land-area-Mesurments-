package gps.landareacalculator.landmeasurement.field.areameasure.Modelclass;

import android.graphics.Bitmap;

public class MesurmentModel {
    private int id;
    private String name;
    private double area;
    private String markerPoints;
    private String midPoints;
    private String areaUnit;
    private String mapType;
    private String perimeterUnit;
    private String distanceType;
    private String image;
    private int color;
    private Bitmap bitmap;

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public void setMarkerPoints(String markerPoints) {
        this.markerPoints = markerPoints;
    }

    public void setMidPoints(String midPoints) {
        this.midPoints = midPoints;
    }

    public void setAreaUnit(String areaUnit) {
        this.areaUnit = areaUnit;
    }

    public void setMapType(String mapType) {
        this.mapType = mapType;
    }

    public void setPerimeterUnit(String perimeterUnit) {
        this.perimeterUnit = perimeterUnit;
    }

    public void setDistanceType(String distanceType) {
        this.distanceType = distanceType;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setColor(int color) {
        this.color = color;
    }






    public MesurmentModel(String name, double area, String markerPoints, String midPoints, String areaUnit, String mapType, String perimeterUnit, String distanceType, String image, int color) {
        this.name = name;
        this.area = area;
        this.markerPoints = markerPoints;
        this.midPoints = midPoints;
        this.areaUnit = areaUnit;
        this.mapType = mapType;
        this.perimeterUnit = perimeterUnit;
        this.distanceType = distanceType;
        this.image = image;
        this.color = color;

    }


    public MesurmentModel(String name, double area, Bitmap bitmap, String type, String coordinates) {
        this.name = name;
        this.area = area;
        this.distanceType = type;
        this.markerPoints = coordinates;
        this.bitmap = bitmap;
    }
    public MesurmentModel(String name, String coordinates, String type) {
        this.name = name;
        this.distanceType = type;
        this.markerPoints = coordinates;
    }



    public int getColor() {
        return color;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getArea() {
        return area;
    }

    public String getMarkerPoints() {
        return markerPoints;
    }

    public String getMidPoints() {
        return midPoints;
    }

    public String getAreaUnit() {
        return areaUnit;
    }

    public String getMapType() {
        return mapType;
    }

    public String getPerimeterUnit() {
        return perimeterUnit;
    }

    public String getDistanceType() {
        return distanceType;
    }

    public String getImage() {
        return image;
    }
}
