package gps.landareacalculator.landmeasurement.field.areameasure.Adpter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.List;

import gps.landareacalculator.landmeasurement.field.areameasure.Activity.AreaUpdateActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.Activity.DistanceUpdateActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.Activity.SavedDataupdateActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.DatabaseHelper;
import gps.landareacalculator.landmeasurement.field.areameasure.Modelclass.MesurmentModel;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class SavedMesurmentAdpter extends RecyclerView.Adapter<SavedMesurmentAdpter.ViewHolder> {
    private Context context;
    private List<MesurmentModel> polygonList;
    private DatabaseHelper databaseHelper;

    public SavedMesurmentAdpter(Context context, List<MesurmentModel> polygonList, DatabaseHelper databaseHelper) {
        this.context = context;
        this.polygonList = polygonList;
        this.databaseHelper = databaseHelper;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_saved_mesurment, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MesurmentModel polygon = polygonList.get(position);
        holder.txt_name.setText("Name :-" + polygon.getName());
        String Type = polygon.getDistanceType();
        double totalDistance = 0;
        if (Type.equals("AUTO_MANNUAL_DISTANCE")) {
            totalDistance = polygon.getArea();
            holder.txt_mesurement.setText(String.format("Distance : %.2f %s", totalDistance, polygon.getAreaUnit()));
        } else if (Type.equals("AUTO-MANNUAL-AREA")) {
            holder.txt_mesurement.setText(String.format("Area: : %.2f  %s", polygon.getArea(), polygon.getAreaUnit()));
        } else if (Type.equals("Polygon")) {
            holder.txt_mesurement.setText(String.format("Area : %.2f %s  ", polygon.getArea(), polygon.getAreaUnit()));
        } else if (Type.equals("LineString")) {
            holder.txt_mesurement.setText(String.format("Distance : %.2f %s ", polygon.getArea(), polygon.getAreaUnit()));
        } else {
            holder.txt_mesurement.setVisibility(View.GONE);
        }

        if (polygon.getImage() != null && !polygon.getImage().isEmpty()) {
            File imgFile = new File(polygon.getImage());
            if (imgFile.exists()) {
                Bitmap bitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                holder.Image_mapes.setImageBitmap(bitmap);
            } else {
            }
        }


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Type.equals("AUTO_MANNUAL_DISTANCE")) {
                    Intent intent = new Intent(context, DistanceUpdateActivity.class);
                    intent.putExtra("name", polygon.getName());
                    context.startActivity(intent);
                } else if (Type.equals("AUTO-MANNUAL-AREA")) {
                    Intent intent = new Intent(context, AreaUpdateActivity.class);
                    intent.putExtra("name", polygon.getName());
                    context.startActivity(intent);
                } else if (Type.equals("Polygon")) {
                    Intent intent = new Intent(context, AreaUpdateActivity.class);
                    intent.putExtra("name", polygon.getName());
                    context.startActivity(intent);
                } else if (Type.equals("LineString")) {
                    Intent intent = new Intent(context, DistanceUpdateActivity.class);
                    intent.putExtra("name", polygon.getName());
                    context.startActivity(intent);
                } else {
                    Intent intent = new Intent(context, SavedDataupdateActivity.class);
                    intent.putExtra("name", polygon.getName());
                    context.startActivity(intent);
                }
            }
        });


        holder.img_delet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int position = holder.getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {

                    databaseHelper.deletePolygonByName(polygon.getName());


                    polygonList.remove(position);


                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, polygonList.size());
                }
            }
        });

    }


    @Override
    public int getItemCount() {
        return polygonList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_name, txt_mesurement;
        ImageView Image_mapes, img_delet;

        public ViewHolder(View itemView) {
            super(itemView);
            txt_name = itemView.findViewById(R.id.txt_name);
            txt_mesurement = itemView.findViewById(R.id.txt_mesurement);
            Image_mapes = itemView.findViewById(R.id.Image_mapes);
            img_delet = itemView.findViewById(R.id.img_delet);
        }
    }
}
