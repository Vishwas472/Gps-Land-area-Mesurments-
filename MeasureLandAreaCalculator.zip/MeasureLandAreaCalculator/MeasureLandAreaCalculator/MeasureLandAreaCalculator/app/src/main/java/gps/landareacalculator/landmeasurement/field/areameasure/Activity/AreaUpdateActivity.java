package gps.landareacalculator.landmeasurement.field.areameasure.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.flask.colorpicker.ColorPickerView;
import com.flask.colorpicker.OnColorSelectedListener;
import com.flask.colorpicker.builder.ColorPickerClickListener;
import com.flask.colorpicker.builder.ColorPickerDialogBuilder;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.SphericalUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Stack;

import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.AppCompany_const;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.PrefManager;
import gps.landareacalculator.landmeasurement.field.areameasure.Modelclass.MesurmentModel;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.BaseActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.DatabaseHelper;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class AreaUpdateActivity extends BaseActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener, GoogleMap.OnMarkerDragListener, GoogleMap.OnMapClickListener {
    private GoogleMap map;
    private DatabaseHelper databaseHelper;
    private TextView txt_area;
    private List<Polyline> polyline_list = new ArrayList<>();
    private List<Polygon> polygon_list = new ArrayList<>();
    private List<Marker> vertex_marker_list = new ArrayList<>();
    private List<Marker> mid_point_marker_list = new ArrayList<>();
    private Stack<List<LatLng>> undoStack = new Stack<>();
    private Stack<List<LatLng>> redoStack = new Stack<>();
    List<LatLng> points_list;
    private Polyline polyline;
    private Polygon polygon;
    Toolbar toolbar;
    private Spinner sp_permeter_unit,
            sp_area_unit;
    CardView card_edit;
    ImageView img_hide_show,
            img_undo,
            img_redo,
            img_colour,
            img_Delet,
            img_map_type,
            img_current_location,
            img_back;
    RelativeLayout rel_save;
    LinearLayout lin_spinner;
    private FusedLocationProviderClient fusedLocationClient;
    private boolean showLength = false;
    private double totalDistance = 0;
    private boolean polygonFinalized = false;
    private int polygonColor;
    private String str_current_map_type = " ";
    private boolean isEditMode = false;
    TextView txt_name;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;
    boolean isActionOne = true;

    PrefManager prefManager;
    RelativeLayout layout;

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area_update);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        prefManager = new PrefManager(AreaUpdateActivity.this);
        layout = (RelativeLayout) findViewById(R.id.adView);
        if (!prefManager.getvalue()) {
            if (AppCompany_const.isActive_adMob) {
                com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(this);
                adView.setAdSize(getAdSize());
                adView.setAdUnitId(AppCompany_const.BANNER_AD_PUB_ID);
                layout.addView(adView);
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);

            }
        }

        txt_area = findViewById(R.id.txt_area);
        sp_permeter_unit = findViewById(R.id.sp_permeter_unit);
        img_hide_show = findViewById(R.id.img_hide_show);
        sp_area_unit = findViewById(R.id.sp_area_unit);
        img_undo = findViewById(R.id.img_undo);
        img_redo = findViewById(R.id.img_redo);
        img_colour = findViewById(R.id.img_colour);
        img_Delet = findViewById(R.id.img_Delet);
        rel_save = findViewById(R.id.rel_save);
        img_map_type = findViewById(R.id.img_map_type);
        card_edit = findViewById(R.id.card_edit);
        lin_spinner = findViewById(R.id.lin_spinner);
        img_back = findViewById(R.id.img_back);
        txt_name = findViewById(R.id.txt_name);
        img_current_location = findViewById(R.id.img_current_location);


        databaseHelper = new DatabaseHelper(this);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        String name = getIntent().getStringExtra("name");
        txt_name.setText(name);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        img_hide_show.setOnClickListener(v -> {
            showLength = !showLength;
            if (showLength) {
                img_hide_show.setImageResource(R.drawable.ic_show);
            } else {
                img_hide_show.setImageResource(R.drawable.ic_hide);
            }
            updateMidpointMarkers();
        });
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.permeter_units, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_permeter_unit.setAdapter(adapter);
        sp_permeter_unit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                updateMidpointMarkers();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                Toast.makeText(AreaUpdateActivity.this, "No unit selected", Toast.LENGTH_SHORT).show();
            }
        });
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.area_units, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_area_unit.setAdapter(adapter2);
        sp_area_unit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                updateAreaText();


            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                Toast.makeText(AreaUpdateActivity.this, "No unit selected", Toast.LENGTH_SHORT).show();
            }
        });

        img_colour.setOnClickListener(v -> openColorPicker());
        img_Delet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearMap();

            }
        });
        rel_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = getIntent().getStringExtra("name");


                JSONArray pointsArray = new JSONArray();
                for (Marker marker : vertex_marker_list) {
                    LatLng position = marker.getPosition();
                    try {
                        JSONObject point = new JSONObject();
                        point.put("latitude", position.latitude);
                        point.put("longitude", position.longitude);
                        pointsArray.put(point);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }


                JSONArray Middledata = new JSONArray();
                for (Marker markerdata : mid_point_marker_list) {
                    LatLng ssss = markerdata.getPosition();
                    try {
                        JSONObject point = new JSONObject();
                        point.put("latitude", ssss.latitude);
                        point.put("longitude", ssss.longitude);
                        Middledata.put(point);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }


                String Areaunit = sp_area_unit.getSelectedItem().toString();
                String permterunit = sp_permeter_unit.getSelectedItem().toString();

                map.snapshot(bitmap -> {
                    if (bitmap != null) {
                        String encodedImage = saveBitmapToFile(bitmap);
                        databaseHelper.updatePolygonData(name, totalDistance, pointsArray.toString(), Middledata.toString(), Areaunit, "Street View", permterunit, "AUTO-MANNUAL-AREA", encodedImage, polygonColor);
                        Toast.makeText(AreaUpdateActivity.this, "Saved Data ", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {

                        Toast.makeText(AreaUpdateActivity.this, "Failed to capture screenshot", Toast.LENGTH_SHORT).show();
                    }
                });


            }
        });
        img_map_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMapTypeDialog();
            }
        });
        card_edit.setOnClickListener(v -> {
            isEditMode = !isEditMode;
            updateUIVisibility();
            updateMarkerInteractions();
        });


        img_undo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (points_list.isEmpty()) {
                    undoAction();
                } else {
                    undoAction2();
                }
            }
        });
        img_redo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (points_list.isEmpty()) {
                    redoAction();
                } else {
                    redoAction2();
                }
            }
        });

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        img_current_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getCurrentLocation();
            }
        });

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        map.setOnMarkerClickListener(this);
        map.setOnMarkerDragListener(this);
        map.setOnMapClickListener(this);

        String name = getIntent().getStringExtra("name");
        txt_name.setText(name);
        List<MesurmentModel> polygonDataList = databaseHelper.getPolygonDataByName(name);
        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();

        for (MesurmentModel polygonData : polygonDataList) {

            points_list = parsePoints(polygonData.getMarkerPoints());
            polygonColor = polygonData.getColor();
            if (points_list != null && !points_list.isEmpty()) {
                drawPolygon(points_list, polygonColor);

                for (LatLng point : points_list) {
                    boundsBuilder.include(point);
                }
            } else {

                map.setOnMapClickListener(this);

            }


            totalDistance = polygonData.getArea();
            String areaUnitString = polygonData.getAreaUnit();
            int unitPosition;

            switch (areaUnitString) {
                case "Square Meters (m²)":
                    unitPosition = 0;
                    break;
                case "Square Kilometers (km²)":
                    unitPosition = 1;
                    break;
                case "Square Feet (ft²)":
                    unitPosition = 2;
                    break;
                case "Square Yards (yd²)":
                    unitPosition = 3;
                    break;
                case "Square Miles (mi²)":
                    unitPosition = 4;
                    break;
                case "Hectares (ha)":
                    unitPosition = 5;
                    break;
                default:
                    unitPosition = 0; // Default to square meters
            }

            String areaUnits = getUnitSuffix(unitPosition);

            txt_area.setText(String.format("Area : %.2f %s", totalDistance, areaUnits));
            String areaUnit = polygonData.getAreaUnit();
            String permeterunit = polygonData.getPerimeterUnit();

            ArrayAdapter<String> adapter = (ArrayAdapter<String>) sp_area_unit.getAdapter();
            int position = adapter.getPosition(areaUnit);
            if (position != -1) {
                sp_area_unit.setSelection(position);
            }

            ArrayAdapter<String> adapter2 = (ArrayAdapter<String>) sp_permeter_unit.getAdapter();
            int position2 = adapter2.getPosition(permeterunit);
            if (position2 != -1) {
                sp_permeter_unit.setSelection(position2);
            }

            str_current_map_type = polygonData.getMapType();
            setMapType(map, str_current_map_type);
            updateMarkerInteractions();
        }


        if (!polygonDataList.isEmpty()) {
            try {
                LatLngBounds bounds = boundsBuilder.build();
                int padding = 100;
                map.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, padding));
            } catch (IllegalStateException e) {
                fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
                    if (location != null) {
                        LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                        map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15));
                    } else {
                    }
                });
            }

        }


    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        if (!isEditMode) return false;

        if (mid_point_marker_list.contains(marker)) {
            handleMidpointInsertion(marker);
            return true;
        }

        if (!polygonFinalized) {
            int index = vertex_marker_list.indexOf(marker);
            if (index == 0 && vertex_marker_list.size() >= 3) {
                finalizePolygon();
                return true;
            }
        }

        showDeleteMarkerDialog(marker);


        return false;
    }

    @Override
    public void onMarkerDragStart(Marker marker) {
        if (marker.getTitle() != null && marker.getTitle().equals("Insert here")) {
            saveStateForUndo();
        }
    }

    @Override
    public void onMarkerDrag(Marker marker) {
        if (marker.getTitle() != null && marker.getTitle().equals("Insert here")) {

            int edgeIndex = (int) marker.getTag();
            List<LatLng> tempPoints = new ArrayList<>();
            int vertexCount = vertex_marker_list.size();

            for (int i = 0; i < vertexCount; i++) {
                tempPoints.add(vertex_marker_list.get(i).getPosition());
                if (i == edgeIndex) {
                    tempPoints.add(marker.getPosition());
                }
            }

            redrawPolygonTemporary(tempPoints);
            updateAreaText();
        } else {
            updateAreaText();
            updatePolygonShape();
        }
    }

    @Override
    public void onMarkerDragEnd(Marker marker) {
        if (marker.getTitle() != null && marker.getTitle().equals("Insert here")) {

            handleMidpointInsertion(marker);

        } else {
            updatePolygonShape();
            updateAreaText();

        }
    }

    @Override
    public void onMapClick(@NonNull LatLng latLng) {
        if (!isEditMode) return;

        if (!polygonFinalized) {
            saveState();
            addVertexMarker(latLng);
            updatePolyline();
            if (vertex_marker_list.size() >= 3) {
                createPolygon();
                polygonFinalized = true ;
                updateMidpointMarkers();
            }

        }else {

                Log.d("hshsh", "ssss: "+polygonFinalized);
                addVertexMarker(latLng);
                updatePolygonShape();
                updateMidpointMarkers();

                if (vertex_marker_list.size() >= 3)
                {
                    createPolygon();
                    polygonFinalized = true ;
                    updateMidpointMarkers();
                }

        }

    }

    private void createPolygon() {
        if (polygon != null) {
            polygon.remove();
        }
        if (vertex_marker_list.size() < 3) return;


        List<LatLng> polygonPoints = new ArrayList<>();
        for (Marker m : vertex_marker_list) {
            polygonPoints.add(m.getPosition());
        }

        redrawPolygonTemporary(polygonPoints);
        polygonFinalized = true;
        updateAreaText();

        if (polyline != null) {
            polyline.remove();
            polyline = null;
        }
    }

    private void updateAreaText() {
        if (polygon_list != null) {

            ArrayList<LatLng> points_list = new ArrayList<>();
            for (Marker marker : vertex_marker_list) {
                points_list.add(marker.getPosition());
            }


            double areaInSquareMeters = calculatePolygonArea(points_list);


            int selectedUnitPosition = sp_area_unit.getSelectedItemPosition();
            totalDistance = convertArea(areaInSquareMeters, selectedUnitPosition);

            txt_area.setText(String.format("Area: %.2f %s", totalDistance
                    , getUnitSuffix(selectedUnitPosition)));
        } else {
            txt_area.setText("Area: 0.00 sq meters");
        }


    }

    private String getUnitSuffix(int unitPosition) {
        switch (unitPosition) {
            case 0:
                return "m²";
            case 1:
                return "km²";
            case 2:
                return "ft²";
            case 3:
                return "yd²";
            case 4:
                return "mi²";
            case 5:
                return "ha";
            default:
                return "m²";
        }
    }

    private double convertArea(double areaInSquareMeters, int unitPosition) {
        switch (unitPosition) {
            case 0:
                return areaInSquareMeters;
            case 1:
                return areaInSquareMeters / 1_000_000;
            case 2:
                return areaInSquareMeters * 10.7639;
            case 3:
                return areaInSquareMeters * 1.19599;
            case 4:
                return areaInSquareMeters / 2_589_988;
            case 5:
                return areaInSquareMeters / 10_000;
            default:
                return areaInSquareMeters;
        }
    }

    private double calculatePolygonArea(ArrayList<LatLng> points_list) {
        return SphericalUtil.computeArea(points_list);
    }

    private void clearMap() {

        img_redo.setVisibility(View.GONE);
        img_undo.setVisibility(View.GONE);
        img_Delet.setVisibility(View.GONE);

        for (Marker marker : vertex_marker_list) {
            marker.remove();
        }
        vertex_marker_list.clear();

        for (Marker marker : mid_point_marker_list) {
            marker.remove();
        }
        mid_point_marker_list.clear();

        for (Polyline polyline : polyline_list) {
            polyline.remove();
        }
        polyline_list.clear();


        for (Polygon polygon : polygon_list) {
            polygon.remove();
        }
        polygon_list.clear();

        if (polygon != null) {
            polygon.remove();
            polygon = null;
        }
        undoStack.clear();
        redoStack.clear();

        if (polyline != null) {
            polyline.remove();
            polyline = null;
        }
        totalDistance = 0;
        txt_area.setText("Area: 0.00 km2");


        polygonFinalized = false;
    }

    public void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15));
            }
        });
    }

    private void openColorPicker() {
        ColorPickerDialogBuilder.with(this).setTitle("Choose color").initialColor(polygonColor).wheelType(ColorPickerView.WHEEL_TYPE.FLOWER).density(12).setOnColorSelectedListener(new OnColorSelectedListener() {
            @Override
            public void onColorSelected(int selectedColor) {
            }
        }).setPositiveButton("ok", new ColorPickerClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int selectedColor, Integer[] allColors) {
                changePolygonColor(selectedColor);
            }
        }).setNegativeButton("cancel", (dialog, which) -> {
        }).build().show();
    }

    private void changePolygonColor(int selectedColor) {
        polygonColor = selectedColor;
        for (Polygon polygon : polygon_list) {
            polygon.setFillColor(polygonColor);
        }
    }

    private void undoAction() {
        if (!undoStack.isEmpty()) {
            redoStack.push(getCurrentState());
            List<LatLng> previousState = undoStack.pop();
            restorePolygon(previousState);

        }
    }
    private void undoAction2() {
        if (!vertex_marker_list.isEmpty()) {
            redoStack.push(getCurrentPositions());


            Marker lastMarker = vertex_marker_list.remove(vertex_marker_list.size() - 1);
            lastMarker.remove();

            if (vertex_marker_list.size() >= 3) {
                polygonFinalized = true;
                updatePolygonShape();
                updatePolyline();
                updateMidpointMarkers();
                updateAreaText();
            } else {
                polygonFinalized = false;

                for (Polyline line : polyline_list) {
                    line.remove();
                }
                polyline_list.clear();
                for (Polygon p : polygon_list) {
                    p.remove();
                }
                polygon_list.clear();



                for (Marker m : mid_point_marker_list) {
                    m.remove();
                }
                mid_point_marker_list.clear();
                updateMidpointMarkers();

                updatePolyline();
                updateAreaText();
            }
        }
    }

    private void restoreState(List<LatLng> positions) {
        for (Marker marker : vertex_marker_list) {
            marker.remove();
        }
        vertex_marker_list.clear();

        if (polyline != null) {
            polyline.remove();
            polyline = null;
        }
        if (polygon != null) {
            polygon.remove();
            polygon = null;
        }
        for (Marker marker : mid_point_marker_list) {
            marker.remove();
        }
        mid_point_marker_list.clear();

        for (LatLng pos : positions) {
            Marker marker = map.addMarker(new MarkerOptions()
                    .position(pos)
                    .title("Vertex " + (vertex_marker_list.size() + 1))
                    .draggable(true)
                    .icon(getCustomMarkerIcon(R.drawable.red_marker)));
            if (marker != null) {
                vertex_marker_list.add(marker);
            }
        }

        if (vertex_marker_list.size() >= 3 && polygonFinalized == true) {
            polygonFinalized = true;
            createPolygon();
            updateMidpointMarkers();
            updateAreaText();
        } else {
            polygonFinalized = false;
            updatePolyline();
            updateAreaText();
            updatePolygonShape();
        }
    }

    private String saveBitmapToFile(Bitmap bitmap) {
        File directory = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "PolygonImages");
        if (!directory.exists()) {
            directory.mkdirs();
        }

        String fileName = "polygon_" + System.currentTimeMillis() + ".png";
        File imageFile = new File(directory, fileName);

        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

        return imageFile.getAbsolutePath();
    }

    private void redoAction() {
        if (!redoStack.isEmpty()) {
            undoStack.push(getCurrentState());
            List<LatLng> nextState = redoStack.pop();
            restorePolygon(nextState);
        }
    }

    private void redoAction2() {
        if (!redoStack.isEmpty()) {
            undoStack.push(getCurrentState());
            List<LatLng> nextState = redoStack.pop();
            restoreState(nextState);
        }
    }

    private void restorePolygon(List<LatLng> points_list) {
        if (points_list == null || points_list.isEmpty()) {
            return;
        }
        for (Marker marker : vertex_marker_list) {
            marker.remove();
        }
        vertex_marker_list.clear();

        for (Polyline polyline : polyline_list) {
            polyline.remove();
        }
        polyline_list.clear();

        for (Polygon polygon : polygon_list) {
            polygon.remove();
        }
        polygon_list.clear();

        drawPolygon(points_list, polygonColor);
        updateMidpointMarkers();
        updateAreaText();
    }

    private List<LatLng> getCurrentState() {
        List<LatLng> state = new ArrayList<>();
        for (Marker marker : vertex_marker_list) {
            state.add(marker.getPosition());
        }
        return state;
    }

    private void updateUIVisibility() {
        int visibility = isEditMode ? View.VISIBLE : View.GONE;
        img_hide_show.setVisibility(visibility);
        img_colour.setVisibility(visibility);
        img_Delet.setVisibility(visibility);
        rel_save.setVisibility(visibility);
        img_map_type.setVisibility(visibility);
        img_current_location.setVisibility(visibility);
        lin_spinner.setVisibility(visibility);
        card_edit.setVisibility(View.GONE);
        img_undo.setVisibility(visibility);
        img_redo.setVisibility(visibility);

    }

    private void updateMarkerInteractions() {
        for (Marker marker : vertex_marker_list) {
            marker.setDraggable(isEditMode);


        }
        for (Marker marker : mid_point_marker_list) {
            marker.setDraggable(isEditMode);
        }
    }

    private void setMapType(GoogleMap map, String mapType) {
        if (mapType == null) return;

        switch (mapType) {
            case "Street View":
                map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                break;
            case "Satellite View":
                map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                break;
            case "Terrain View":
                map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                break;
            case "Hybrid View":
                map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                break;
            default:
                map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                break;
        }
    }

    private void showMapTypeDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_map_type, null);
        CheckBox checkStreetView = dialogView.findViewById(R.id.check_street_view);
        CheckBox checkSatelliteView = dialogView.findViewById(R.id.check_satilite_view);
        CheckBox checkTerrainView = dialogView.findViewById(R.id.check_terrain_view);
        CheckBox checkHybridView = dialogView.findViewById(R.id.check_hybrid_view);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        switch (str_current_map_type) {
            case "Street View":
                checkStreetView.setChecked(true);
                break;
            case "Satellite View":
                checkSatelliteView.setChecked(true);
                break;
            case "Terrain View":
                checkTerrainView.setChecked(true);
                break;
            case "Hybrid View":
                checkHybridView.setChecked(true);
                break;
        }
        View.OnClickListener listener = v -> {
            checkStreetView.setChecked(false);
            checkSatelliteView.setChecked(false);
            checkTerrainView.setChecked(false);
            checkHybridView.setChecked(false);
            ((CheckBox) v).setChecked(true);
            if (v == checkStreetView) {
                map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                str_current_map_type = "Street View";
            } else if (v == checkSatelliteView) {
                map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                str_current_map_type = "Satellite View";
            } else if (v == checkTerrainView) {
                map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                str_current_map_type = "Terrain View";
            } else if (v == checkHybridView) {
                map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                str_current_map_type = "Hybrid View";
            }


            dialog.dismiss();
        };
        checkStreetView.setOnClickListener(listener);
        checkSatelliteView.setOnClickListener(listener);
        checkTerrainView.setOnClickListener(listener);
        checkHybridView.setOnClickListener(listener);
        dialog.show();
    }

    private void finalizePolygon() {
        polygonFinalized = true;
        createPolygon();
        updateMidpointMarkers();
    }

    private void showDeleteMarkerDialog(Marker marker) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.diloge_marker_delet, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();

        LinearLayout lin_no = dialogView.findViewById(R.id.lin_no);
        LinearLayout lin_yes = dialogView.findViewById(R.id.lin_yes);

        lin_no.setOnClickListener(v -> dialog.dismiss());

        lin_yes.setOnClickListener(v -> {
            removeMarker(marker);
            dialog.dismiss();
            updateAreaText();
        });
        dialog.setCancelable(true);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );


        dialog.show();
    }

    private void removeMarker(Marker marker) {
        int index = vertex_marker_list.indexOf(marker);
        if (index != -1) {
            marker.remove();
            vertex_marker_list.remove(index);
            updatePolygonShape();
        }
    }

    private void handleMidpointInsertion(Marker midMarker) {
        saveStateForUndo();


        int edgeIndex = (int) midMarker.getTag();
        int n = vertex_marker_list.size();


        Marker A_marker = vertex_marker_list.get(edgeIndex);
        Marker B_marker = vertex_marker_list.get((edgeIndex + 1) % n);
        LatLng A = A_marker.getPosition();
        LatLng B = B_marker.getPosition();
        LatLng M = midMarker.getPosition();


        Marker newMarker = map.addMarker(new MarkerOptions().position(M).title("Vertex " + (vertex_marker_list.size() + 1)).draggable(true).icon(getCustomMarkerIcon(R.drawable.red_marker)));


        int insertIndex = edgeIndex + 1;
        vertex_marker_list.add(insertIndex, newMarker);


        A_marker.setIcon(getCustomMarkerIcon(R.drawable.red_marker));
        B_marker.setIcon(getCustomMarkerIcon(R.drawable.red_marker));

        polyline_list.get(edgeIndex).remove();
        polyline_list.remove(edgeIndex);
        int strokeColor = ContextCompat.getColor(this, R.color.RED);
        Polyline polyline1 = map.addPolyline(new PolylineOptions().add(A, M).color(strokeColor));
        Polyline polyline2 = map.addPolyline(new PolylineOptions().add(M, B).color(strokeColor));

        polyline_list.add(edgeIndex, polyline1);
        polyline_list.add(edgeIndex + 1, polyline2);

        midMarker.remove();

        updateMidpointMarkers();

        updateAreaText();
    }

    private void saveStateForUndo() {
        List<LatLng> currentState = new ArrayList<>();
        for (Marker marker : vertex_marker_list) {
            currentState.add(marker.getPosition());
        }
        undoStack.push(new ArrayList<>(currentState));
        redoStack.clear();
    }

    private void redrawPolygonTemporary(List<LatLng> points_list) {

        for (Polygon polygon : polygon_list) {
            polygon.remove();
        }
        polygon_list.clear();

        for (Polyline polyline : polyline_list) {
            polyline.remove();
        }
        polyline_list.clear();
        int strokeColor = ContextCompat.getColor(this, R.color.RED);

        Polygon polygon = map.addPolygon(new PolygonOptions().addAll(points_list).strokeColor(strokeColor).fillColor(polygonColor));
        polygon_list.add(polygon);

        polygonFinalized = true;

        for (int i = 0; i < points_list.size(); i++) {
            LatLng start = points_list.get(i);
            LatLng end = points_list.get((i + 1) % points_list.size());
            Polyline polyline = map.addPolyline(new PolylineOptions().add(start, end).color(strokeColor));
            polyline_list.add(polyline);
        }

    }

    private void drawPolygon(List<LatLng> points_list, int polygonColor) {
        int strokeColor = ContextCompat.getColor(this, R.color.RED);

        for (int i = 0; i < points_list.size(); i++) {
            LatLng start = points_list.get(i);
            LatLng end = points_list.get((i + 1) % points_list.size());

            Polyline polyline = map.addPolyline(new PolylineOptions().add(start, end).color(strokeColor));
            polyline_list.add(polyline);
        }
        Polygon polygon = map.addPolygon(new PolygonOptions().addAll(points_list).strokeColor(strokeColor).fillColor(polygonColor));
        polygon_list.add(polygon);

        for (LatLng point : points_list) {
            Marker marker = map.addMarker(new MarkerOptions().position(point).icon(getCustomMarkerIcon(R.drawable.red_marker)).title("Vertex").draggable(true));
            vertex_marker_list.add(marker);

            polygonFinalized = true;
        }
    }

    private void updatePolygonShape() {
        List<LatLng> newPoints = new ArrayList<>();
        for (Marker marker : vertex_marker_list) {
            newPoints.add(marker.getPosition());
        }

        if (!newPoints.isEmpty()) {
            for (Polygon polygon : polygon_list) {
                polygon.remove();
            }
            polygon_list.clear();
            int strokeColor = ContextCompat.getColor(this, R.color.RED);
            Polygon polygon = map.addPolygon(new PolygonOptions().addAll(newPoints).strokeColor(strokeColor).fillColor(polygonColor));
            polygon_list.add(polygon);
        }

        for (Polyline polyline : polyline_list) {
            polyline.remove();
        }
        polyline_list.clear();

        for (int i = 0; i < newPoints.size(); i++) {
            LatLng start = newPoints.get(i);
            LatLng end = newPoints.get((i + 1) % newPoints.size());


            int strokeColor = ContextCompat.getColor(this, R.color.RED);
            Polyline polyline = map.addPolyline(new PolylineOptions().add(start, end).color(strokeColor));
            polyline_list.add(polyline);
        }

        updateMidpointMarkers();
    }

    private void updateMidpointMarkers() {
        for (Marker m : mid_point_marker_list) {
            m.remove();
        }
        mid_point_marker_list.clear();

        int n = vertex_marker_list.size();
        if (n < 2) return;
        Map<String, String> unitShortForms = new HashMap<>();

        unitShortForms.put("Meters", "M");
        unitShortForms.put("Kilometers", "Km");
        unitShortForms.put("Feet", "Ft");
        unitShortForms.put("Yards", "Yd");
        unitShortForms.put("Miles", "Mi");
        unitShortForms.put("Hectares", "H");


        String selectedUnit = sp_permeter_unit.getSelectedItem().toString();
        String shortForm = unitShortForms.getOrDefault(selectedUnit, selectedUnit);

        double conversionFactor = getUnitConversionFactor(selectedUnit);

        for (int i = 0; i < n; i++) {
            LatLng A = vertex_marker_list.get(i).getPosition();
            LatLng B = vertex_marker_list.get((i + 1) % n).getPosition();
            LatLng mid = SphericalUtil.interpolate(A, B, 0.5); // <-- KEY LINE

            float[] results = new float[1];
            Location.distanceBetween(A.latitude, A.longitude, B.latitude, B.longitude, results);
            double distanceInSelectedUnit = results[0] * conversionFactor;
            String lengthText = String.format("%.2f %s", distanceInSelectedUnit, shortForm);

            MarkerOptions markerOptions = new MarkerOptions().position(mid).title("Insert here").draggable(true).anchor(0.5f, 0.5f).icon(getCustomMarkerIcon(R.drawable.middle_marker));


            if (showLength) {
                Bitmap lengthBitmap = createTextBitmap(lengthText);
                markerOptions.icon(BitmapDescriptorFactory.fromBitmap(lengthBitmap));
            }

            Marker midMarker = map.addMarker(markerOptions);
            midMarker.setTag(i);
            mid_point_marker_list.add(midMarker);
        }
    }

    private Bitmap createTextBitmap(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextSize(14);
        textView.setTextColor(Color.BLACK);
        textView.setBackgroundColor(getResources().getColor(R. color. white_with_low_opacity));
        textView.setPadding(10, 10, 10, 10);
        textView.measure(android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED), android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED));
        textView.layout(0, 0, textView.getMeasuredWidth(), textView.getMeasuredHeight());
        Bitmap bitmap = Bitmap.createBitmap(textView.getMeasuredWidth(), textView.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        textView.draw(canvas);
        return bitmap;
    }

    private double getUnitConversionFactor(String selectedUnit) {
        switch (selectedUnit) {
            case "Kilometers":
                return 0.001;
            case "Miles":
                return 0.000621371;
            default:
                return 1;
        }
    }

    private List<LatLng> parsePoints(String pointsJson) {
        List<LatLng> points_list = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(pointsJson);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject point = jsonArray.getJSONObject(i);
                double lat = point.getDouble("latitude");
                double lng = point.getDouble("longitude");
                points_list.add(new LatLng(lat, lng));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return points_list;
    }

    private void saveState() {
        List<LatLng> positions = getCurrentPositions();
        undoStack.push(new ArrayList<>(positions));
        redoStack.clear();
    }

    private List<LatLng> getCurrentPositions() {
        List<LatLng> positions = new ArrayList<>();
        for (Marker marker : vertex_marker_list) {
            positions.add(marker.getPosition());
        }
        return positions;
    }

    private void updatePolyline() {
        if (polyline != null) {
            polyline.remove();
        }
        if (vertex_marker_list.size() < 2) return;
        PolylineOptions options = new PolylineOptions().width(5).color(Color.RED);
        for (Marker m : vertex_marker_list) {
            options.add(m.getPosition());
        }
        polyline = map.addPolyline(options);
    }

    private void addVertexMarker(LatLng latLng) {
        img_undo.setVisibility(View.VISIBLE);
        img_Delet.setVisibility(View.VISIBLE);
        img_redo.setVisibility(View.VISIBLE);
        Marker marker = map.addMarker(new MarkerOptions().position(latLng).title("Vertex " + (vertex_marker_list.size() + 1)).draggable(true).icon(getCustomMarkerIcon(R.drawable.red_marker)));
        if (marker != null) {
            vertex_marker_list.add(marker);
        }
    }

    private BitmapDescriptor getCustomMarkerIcon(int drawableResId) {
        Drawable drawable = getResources().getDrawable(drawableResId);
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}