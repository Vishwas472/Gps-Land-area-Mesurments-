package gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Log;
import android.view.WindowManager;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.ump.ConsentForm;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.FormError;
import com.google.android.ump.UserMessagingPlatform;
import com.microsoft.clarity.Clarity;
import com.microsoft.clarity.ClarityConfig;
import com.microsoft.clarity.models.LogLevel;

import gps.landareacalculator.landmeasurement.field.areameasure.Activity.LanguageActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.HomeActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.R;


public class SplashActivity extends AppCompatActivity {

     boolean Ad_Show=false;
    PrefManager prefManager;
    ConsentForm mConsentForm;
    ConsentInformation mConsentInformation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }

        setContentView(R.layout.activity_splash_screen);
        ClarityConfig config = new ClarityConfig("r0b69j15pi");
        config.setLogLevel(LogLevel.None); // Note: Use "LogLevel.Verbose" value while testing to debug initialization issues.
        Clarity.initialize(getApplicationContext(), config);

        AppCompany_const.is_show_open_ad = 0;
        prefManager = new PrefManager(SplashActivity.this);

        if (isOnline()) {
            if (prefManager.isFirstTimeLaunch()) {
                SplashActivity.this.DoConsentProcess();
            } else {
                ContinueAdsProcess();
            }
        } else {
            ContinueWithoutAdsProcess();
        }


    }

    public void DoConsentProcess() {
        ConsentRequestParameters build = new ConsentRequestParameters.Builder().setTagForUnderAgeOfConsent(false).build();
        ConsentInformation consentInformation = UserMessagingPlatform.getConsentInformation(this);
        this.mConsentInformation = consentInformation;

        consentInformation.requestConsentInfoUpdate(this, build, new ConsentInformation.OnConsentInfoUpdateSuccessListener() {
            public void onConsentInfoUpdateSuccess() {
                if (mConsentInformation.isConsentFormAvailable()) {
                    Log.e("============", "onConsentInfoUpdateSuccess: ");
                    SplashActivity.this.LoadConsentForm();
                    return;
                } else {
                    ContinueAdsProcess();
                }

            }
        }, new ConsentInformation.OnConsentInfoUpdateFailureListener() {
            public void onConsentInfoUpdateFailure(FormError formError) {
                SplashActivity.this.ErrorProcess();
            }
        });
    }

    public void LoadConsentForm() {
        UserMessagingPlatform.loadConsentForm(this, new UserMessagingPlatform.OnConsentFormLoadSuccessListener() {
            public void onConsentFormLoadSuccess(ConsentForm consentForm) {
                SplashActivity.this.mConsentForm = consentForm;
                if (SplashActivity.this.mConsentInformation.getConsentStatus() == 2) {
                    consentForm.show(SplashActivity.this, new ConsentForm.OnConsentFormDismissedListener() {
                        public void onConsentFormDismissed(FormError formError) {
                            if (mConsentInformation.getConsentStatus() == 3) {
                                prefManager.setFirstTimeLaunch(false);
                                if (mConsentInformation.canRequestAds()) {
                                    SplashActivity.this.ContinueAdsProcess();
                                }
                            }
                            SplashActivity.this.LoadConsentForm();

                        }
                    });
                }
            }
        }, new UserMessagingPlatform.OnConsentFormLoadFailureListener() {
            public void onConsentFormLoadFailure(FormError formError) {
                SplashActivity.this.ErrorProcess();
            }
        });
    }

    public void ErrorProcess() {
        HomeScreen();
    }


    public boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }


    public void ContinueAdsProcess() {
        if (!prefManager.getvalue()) {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                public void run() {
                    if (SplashActivity.this.Ad_Show) {
                        SplashActivity.this.HomeScreen();
                    }
                }
            }, 8000);
            LoadAdMobInterstitialAd();
            return;
        }
        ContinueWithoutAdsProcess();
    }

    public void ContinueWithoutAdsProcess() {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            public void run() {
                SplashActivity.this.HomeScreen();
            }
        }, 3000);
    }

    private void LoadAdMobInterstitialAd() {

        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, AppCompany_const.SPLASH_INTRESTITIAL_AD_PUB_ID, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                HomeScreen();
                interstitialAd.show(SplashActivity.this);
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                HomeScreen();
            }
        });
    }


    public void HomeScreen() {
        this.Ad_Show = false;
        startActivity(new Intent(this, LanguageActivity.class));
        AppCompany_const.is_show_open_ad = 1;
        finish();
    }


    public void onBackPressed() {
        super.onBackPressed();
        ExitApp();
    }

    public void ExitApp() {
        moveTaskToBack(true);
        finish();
        Process.killProcess(Process.myPid());
        System.exit(0);
    }


}