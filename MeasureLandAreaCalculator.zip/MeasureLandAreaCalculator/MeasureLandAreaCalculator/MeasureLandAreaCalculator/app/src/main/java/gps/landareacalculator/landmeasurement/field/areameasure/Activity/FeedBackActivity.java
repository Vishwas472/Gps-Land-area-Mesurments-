package gps.landareacalculator.landmeasurement.field.areameasure.Activity;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class FeedBackActivity extends AppCompatActivity {
    ImageView img_back;
    RelativeLayout rel_user_experice, rel_faild, rel_dont, rel_other, rel_submit;
    TextView txt_user_experice, txt_fail, txt_dont, txt_other;
    EditText edt_details;
    private String selectedFeedback = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed_back);
        img_back = findViewById(R.id.img_back);


        rel_user_experice = findViewById(R.id.rel_user_experice);
        rel_faild = findViewById(R.id.rel_faild);
        rel_dont = findViewById(R.id.rel_dont);
        rel_other = findViewById(R.id.rel_other);
        txt_user_experice = findViewById(R.id.txt_user_experice);
        txt_fail = findViewById(R.id.txt_fail);
        txt_dont = findViewById(R.id.txt_dont);
        txt_other = findViewById(R.id.txt_other);
        rel_submit = findViewById(R.id.rel_submit);
        edt_details = findViewById(R.id.edt_details);


        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        selectOption(rel_user_experice, txt_user_experice);

        rel_user_experice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectOption(rel_user_experice, txt_user_experice);
            }
        });
        rel_faild.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectOption(rel_faild, txt_fail);
            }
        });
        rel_dont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectOption(rel_dont, txt_dont);
            }
        });
        rel_other.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectOption(rel_other, txt_other);
            }
        });

        rel_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("GSGSGS", "Selected Option: " + selectedFeedback);


                Dialog dialog = new Dialog(FeedBackActivity.this);
                dialog.setContentView(R.layout.diloge_feedback_complated);
                dialog.setCancelable(false);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.getWindow().setLayout(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
                RelativeLayout rel_Feedback = dialog.findViewById(R.id.rel_Feedback);

                rel_Feedback.setOnClickListener(v -> {
                    dialog.dismiss();
                    finish();
                });


                dialog.show();
            }
        });


    }

    private void selectOption(RelativeLayout selectedOption, TextView TextView) {


        rel_user_experice.setBackgroundResource(R.drawable.btn_grey);
        rel_faild.setBackgroundResource(R.drawable.btn_grey);
        rel_dont.setBackgroundResource(R.drawable.btn_grey);
        rel_other.setBackgroundResource(R.drawable.btn_grey);


        txt_user_experice.setTextColor(ContextCompat.getColor(this, R.color.grey));
        txt_dont.setTextColor(ContextCompat.getColor(this, R.color.grey));
        txt_fail.setTextColor(ContextCompat.getColor(this, R.color.grey));
        txt_other.setTextColor(ContextCompat.getColor(this, R.color.grey));
        selectedOption.setBackgroundResource(R.drawable.blues_bg);
        TextView.setTextColor(Color.WHITE);

        String feedbackText = TextView.getText().toString();
        edt_details.setText(feedbackText);
        edt_details.setTextColor(ContextCompat.getColor(this, R.color.blacks)); // default text color

        if (feedbackText.equalsIgnoreCase("Others")) {
            edt_details.setText(""); // clear EditText
            edt_details.setHint("Please describe..."); // optional
            edt_details.setBackgroundResource(R.drawable.btn_grey); // default background
            edt_details.setTextColor(ContextCompat.getColor(this, R.color.blacks)); // default text color
        }



        if (!feedbackText.equalsIgnoreCase("Others")) {
            selectedFeedback = feedbackText;
        } else {
            selectedFeedback = "";
        }



    }


    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();


    }
}