package gps.landareacalculator.landmeasurement.field.areameasure.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.flask.colorpicker.ColorPickerView;
import com.flask.colorpicker.OnColorSelectedListener;
import com.flask.colorpicker.builder.ColorPickerClickListener;
import com.flask.colorpicker.builder.ColorPickerDialogBuilder;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.SphericalUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Stack;

import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.AppCompany_const;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.PrefManager;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.BaseActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.DatabaseHelper;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class ManuallyAreaCalculateActivity extends BaseActivity implements OnMapReadyCallback, GoogleMap.OnMapClickListener, GoogleMap.OnMarkerClickListener, GoogleMap.OnMarkerDragListener {
    private GoogleMap map;
    private DatabaseHelper dbHelper;
    private final List<Marker> Vertex_marker_list = new ArrayList<>();
    private final List<Marker> Midpoint_marker_list = new ArrayList<>();
    private Stack<List<LatLng>> undoStack = new Stack<>();
    private Stack<List<LatLng>> redoStack = new Stack<>();
    private Polyline polyline;
    private Polygon polygon;
    Toolbar toolbar;
    private int polygonColor = Color.argb(51, 255, 0, 0);
    RelativeLayout rel_save;
    private Spinner sp_area_units, sp_permeter_unit;
    private TextView txt_area;
    ImageView img_undo, img_redo, img_current_location, img_map_type, img_colour, img_hide_show, img_delet, img_back;
    private FusedLocationProviderClient fusedLocationClient;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;
    private boolean polygonFinalized = false;
    private boolean showLength = true;
    private String str_current_map_type = "Street View";

    PrefManager prefManager;
    RelativeLayout layout;

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manually_area_calculate);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);


        prefManager = new PrefManager(ManuallyAreaCalculateActivity.this);
        layout = (RelativeLayout) findViewById(R.id.adView);
        if (!prefManager.getvalue()) {
            if (AppCompany_const.isActive_adMob) {
                com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(this);
                adView.setAdSize(getAdSize());
                adView.setAdUnitId(AppCompany_const.BANNER_AD_PUB_ID);
                layout.addView(adView);
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);

            }
        }

        txt_area = findViewById(R.id.txt_area);
        sp_area_units = findViewById(R.id.sp_area_units);
        sp_permeter_unit = findViewById(R.id.sp_permeter_unit);
        img_delet = findViewById(R.id.img_delet);
        img_hide_show = findViewById(R.id.img_hide_show);
        rel_save = findViewById(R.id.rel_save);
        img_undo = findViewById(R.id.img_undo);
        img_redo = findViewById(R.id.img_redo);
        img_colour = findViewById(R.id.img_colour);
        img_map_type = findViewById(R.id.img_map_type);
        img_current_location = findViewById(R.id.img_curret_loction);

        img_back = findViewById(R.id.img_back);

        dbHelper = new DatabaseHelper(this);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.area_units, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_area_units.setAdapter(adapter);
        sp_area_units.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                updateAreaText();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }
        });

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.permeter_units, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_permeter_unit.setAdapter(adapter2);
        sp_permeter_unit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                updateMidpointMarkers();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }
        });

        img_hide_show.setOnClickListener(v -> {
            showLength = !showLength;
            if (showLength) {
                img_hide_show.setImageResource(R.drawable.ic_show);
            } else {
                img_hide_show.setImageResource(R.drawable.ic_hide);
            }
            if (polygonFinalized == true) {
                updateMidpointMarkers();
            } else {
                Toast.makeText(this, "Polygon Finzlize First then Show Legth ", Toast.LENGTH_SHORT).show();
            }
        });
        rel_save.setOnClickListener(v -> {

            Dialog dialog = new Dialog(ManuallyAreaCalculateActivity.this);
            dialog.setContentView(R.layout.custom_dialog_save);
            dialog.setCancelable(true);
            EditText nameInput = dialog.findViewById(R.id.dialog_name_input);
            RelativeLayout saveButton = dialog.findViewById(R.id.rel_save);
            RelativeLayout cancelButton = dialog.findViewById(R.id.rel_cancel);
            dialog.setCancelable(true);
            Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            dialog.show();

            saveButton.setOnClickListener(view -> {
                String name = nameInput.getText().toString();
                if (name.isEmpty()) {
                    Toast.makeText(ManuallyAreaCalculateActivity.this, "Please enter an area name", Toast.LENGTH_SHORT).show();
                } else {
                    String areaText = txt_area.getText().toString();
                    double areaValue = 0.0;
                    try {
                        String numericAreaText = areaText.replaceAll("[^0-9.]", "");
                        areaValue = Double.parseDouble(numericAreaText);
                    } catch (NumberFormatException e) {
                        Toast.makeText(ManuallyAreaCalculateActivity.this, "Invalid area value", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    JSONArray pointsArray = new JSONArray();
                    for (Marker marker : Vertex_marker_list) {
                        LatLng position = marker.getPosition();
                        try {
                            JSONObject point = new JSONObject();
                            point.put("latitude", position.latitude);
                            point.put("longitude", position.longitude);
                            pointsArray.put(point);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    JSONArray Middledata = new JSONArray();
                    for (Marker markerdata : Midpoint_marker_list) {
                        LatLng ssss = markerdata.getPosition();
                        try {
                            JSONObject point = new JSONObject();
                            point.put("latitude", ssss.latitude);
                            point.put("longitude", ssss.longitude);
                            Middledata.put(point);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    String Areaunit = sp_area_units.getSelectedItem().toString();
                    String permterunit = sp_permeter_unit.getSelectedItem().toString();
                    double finalAreaValue = areaValue;
                    map.snapshot(bitmap -> {
                        if (bitmap != null) {
                            String encodedImage = saveBitmapToFile(bitmap);
                            dbHelper.insertPolygonData(name, finalAreaValue, pointsArray.toString(), Middledata.toString(), Areaunit, str_current_map_type, permterunit, "AUTO-MANNUAL-AREA", encodedImage, polygonColor);
                            Toast.makeText(ManuallyAreaCalculateActivity.this, "Polygon saved successfully", Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        } else {
                            Toast.makeText(ManuallyAreaCalculateActivity.this, "Failed to capture screenshot", Toast.LENGTH_SHORT).show();
                        }
                    });
                    Toast.makeText(ManuallyAreaCalculateActivity.this, "Polygon saved!", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }
            });

            cancelButton.setOnClickListener(view -> {
                dialog.dismiss();
            });
        });
        img_delet.setOnClickListener(v -> clearMap());
        img_undo.setOnClickListener(v -> undoAction());
        img_colour.setOnClickListener(v -> openColorPicker());
        img_redo.setOnClickListener(v -> redoAction());
        img_map_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMapTypeDialog();
            }
        });


        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        img_current_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getCurrentLocation();
            }
        });

    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;
        LatLng initialLocation = new LatLng(20.5937, 78.9629);
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(initialLocation, 5));

        map.setOnMapClickListener(this);
        map.setOnMarkerClickListener(this);
        map.setOnMarkerDragListener(this);


        checkLocationPermission();

    }

    @Override
    public void onMapClick(LatLng latLng) {


        if (!polygonFinalized) {

            saveState();
            addVertexMarker(latLng);
            updatePolyline();
            Log.d("hshsh", "onMapClick: " + polygonFinalized);

            if (Vertex_marker_list.size() >= 3) {
                createPolygon();
                polygonFinalized = true;
                updateMidpointMarkers();
            }
        } else {
            Log.d("hshsh", "ssss: " + polygonFinalized);
            addVertexMarker(latLng);
            updatePolygonShape();
            updateMidpointMarkers();

            if (Vertex_marker_list.size() >= 3) {
                createPolygon();
                polygonFinalized = true;
                updateMidpointMarkers();
            }

        }


    }

    @Override
    public boolean onMarkerClick(Marker marker) {

        if (polygonFinalized && marker.getTitle() != null && marker.getTitle().equals("Insert here")) {
            saveState();
            handleMidpointInsertion(marker);
            return true;
        }
        if (!polygonFinalized) {
            int index = Vertex_marker_list.indexOf(marker);
            if (index == 0 && Vertex_marker_list.size() >= 3) {
                finalizePolygon();
                return true;
            }
        }

        showDeleteDialog(marker);

        return false;
    }

    @Override
    public void onMarkerDragStart(@NonNull Marker marker) {
        if (marker.getTitle() != null && marker.getTitle().equals("Insert here")) {
            saveState();
        }
    }

    @Override
    public void onMarkerDrag(@NonNull Marker marker) {
        if (Vertex_marker_list.contains(marker)) {
            if (polygonFinalized == true) {
                updatePolygonShape();
                updateMidpointMarkers();
                updateAreaText();
            } else {
                updatePolyline();
            }

        } else if (Midpoint_marker_list.contains(marker)) {
            int edgeIndex = (int) marker.getTag();
            LatLng newPos = marker.getPosition();
            List<LatLng> polygonPoints = new ArrayList<>();
            for (Marker m : Vertex_marker_list) {
                polygonPoints.add(m.getPosition());
            }
            polygonPoints.add(edgeIndex + 1, newPos);
            polygon.setPoints(polygonPoints);
            updateAreaText();

        }


    }

    @Override
    public void onMarkerDragEnd(@NonNull Marker marker) {
        if (Midpoint_marker_list.contains(marker)) {

            int edgeIndex = (int) marker.getTag();
            LatLng newVertex = marker.getPosition();


            Marker newMarker = map.addMarker(new MarkerOptions().position(newVertex).title("Vertex " + (Vertex_marker_list.size() + 1)).draggable(true).icon(getCustomMarkerIcon(R.drawable.red_marker)));


            Vertex_marker_list.add(edgeIndex + 1, newMarker);


            marker.remove();
            Midpoint_marker_list.remove(marker);

            if (polygonFinalized == true) {
                updatePolygonShape();
                updateMidpointMarkers();
                updateAreaText();
            }
        } else if (Vertex_marker_list.contains(marker)) {
            if (polygonFinalized == true) {
                updatePolygonShape();
                updateMidpointMarkers();
                updateAreaText();
            }
        }
    }

    private void showMapTypeDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_map_type, null);
        CheckBox checkStreetView = dialogView.findViewById(R.id.check_street_view);
        CheckBox checkSatelliteView = dialogView.findViewById(R.id.check_satilite_view);
        CheckBox checkTerrainView = dialogView.findViewById(R.id.check_terrain_view);
        CheckBox checkHybridView = dialogView.findViewById(R.id.check_hybrid_view);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        switch (str_current_map_type) {
            case "Street View":
                checkStreetView.setChecked(true);
                break;
            case "Satellite View":
                checkSatelliteView.setChecked(true);
                break;
            case "Terrain View":
                checkTerrainView.setChecked(true);
                break;
            case "Hybrid View":
                checkHybridView.setChecked(true);
                break;
        }
        View.OnClickListener listener = v -> {
            checkStreetView.setChecked(false);
            checkSatelliteView.setChecked(false);
            checkTerrainView.setChecked(false);
            checkHybridView.setChecked(false);
            ((CheckBox) v).setChecked(true);
            if (v == checkStreetView) {
                map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                str_current_map_type = "Street View";
            } else if (v == checkSatelliteView) {
                map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                str_current_map_type = "Satellite View";
            } else if (v == checkTerrainView) {
                map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                str_current_map_type = "Terrain View";
            } else if (v == checkHybridView) {
                map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                str_current_map_type = "Hybrid View";
            }


            dialog.dismiss();
        };
        checkStreetView.setOnClickListener(listener);
        checkSatelliteView.setOnClickListener(listener);
        checkTerrainView.setOnClickListener(listener);
        checkHybridView.setOnClickListener(listener);
        dialog.show();
    }

    private void openColorPicker() {
        ColorPickerDialogBuilder.with(this).setTitle("Choose color").initialColor(polygonColor).wheelType(ColorPickerView.WHEEL_TYPE.FLOWER).density(12).setOnColorSelectedListener(new OnColorSelectedListener() {
            @Override
            public void onColorSelected(int selectedColor) {
            }
        }).setPositiveButton("ok", new ColorPickerClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int selectedColor, Integer[] allColors) {
                changeBackgroundColor(selectedColor);
            }
        }).setNegativeButton("cancel", (dialog, which) -> {
        }).build().show();
    }

    private void changeBackgroundColor(int selectedColor) {
        polygonColor = selectedColor;
        if (polygon != null && Vertex_marker_list.size() >= 3) {
            int strokeColor = ContextCompat.getColor(this, R.color.RED);

            PolygonOptions polygonOptions = new PolygonOptions().strokeWidth(5).strokeColor(strokeColor).fillColor(polygonColor);
            for (Marker m : Vertex_marker_list) {
                polygonOptions.add(m.getPosition());
            }
            polygon.remove();
            polygon = map.addPolygon(polygonOptions);
        } else if (Vertex_marker_list.size() >= 3) {
            createPolygon();
        }
    }

    private List<LatLng> getCurrentPositions() {
        List<LatLng> positions = new ArrayList<>();
        for (Marker marker : Vertex_marker_list) {
            positions.add(marker.getPosition());
        }
        return positions;
    }

    private void redoAction() {
        if (!redoStack.isEmpty()) {
            undoStack.push(getCurrentPositions());
            List<LatLng> nextState = redoStack.pop();
            restoreState(nextState);
        }
    }

    private void undoAction() {
        if (!Vertex_marker_list.isEmpty()) {
            // Save the current state for redo
            redoStack.push(getCurrentPositions());

            // Remove the last marker
            Marker lastMarker = Vertex_marker_list.remove(Vertex_marker_list.size() - 1);
            lastMarker.remove();

            // Remove and rebuild polygon or polyline accordingly
            if (Vertex_marker_list.size() >= 3) {
                polygonFinalized = true;
                createPolygon();
                updateMidpointMarkers();
                updateAreaText();
            } else {
                polygonFinalized = false;
                if (polygon != null) {
                    polygon.remove();
                    polygon = null;
                }
                updatePolyline();
                updateMidpointMarkers();
                updateAreaText();
            }
        }
    }

    private void restoreState(List<LatLng> positions) {
        for (Marker marker : Vertex_marker_list) {
            marker.remove();
        }
        Vertex_marker_list.clear();
        if (polyline != null) {
            polyline.remove();
            polyline = null;
        }
        if (polygon != null) {
            polygon.remove();
            polygon = null;
        }
        for (Marker marker : Midpoint_marker_list) {
            marker.remove();
        }
        Midpoint_marker_list.clear();


        for (LatLng pos : positions) {
            Marker marker = map.addMarker(new MarkerOptions().position(pos).title("Vertex " + (Vertex_marker_list.size() + 1)).draggable(true).icon(getCustomMarkerIcon(R.drawable.red_marker)));
            if (marker != null) {
                Vertex_marker_list.add(marker);
            }
        }

        if (Vertex_marker_list.size() >= 3) {
            polygonFinalized = true;
            createPolygon();
            updateMidpointMarkers();
            updateAreaText();
        } else {
            polygonFinalized = false;
            updatePolyline();
            updateAreaText();
        }
    }

    private void updateAreaText() {
        if (polygon != null) {

            ArrayList<LatLng> points = new ArrayList<>();
            for (Marker marker : Vertex_marker_list) {
                points.add(marker.getPosition());
            }


            double areaInSquareMeters = calculatePolygonArea(points);


            int selectedUnitPosition = sp_area_units.getSelectedItemPosition();
            double convertedArea = convertArea(areaInSquareMeters, selectedUnitPosition);


            txt_area.setText(String.format("Area: %.2f %s", convertedArea, getUnitSuffix(selectedUnitPosition)));
        } else {
            txt_area.setText("Area: 0.00 km2");
        }
    }

    private String getUnitSuffix(int unitPosition) {
        switch (unitPosition) {
            case 0:
                return "m²";
            case 1:
                return "km²";
            case 2:
                return "ft²";
            case 3:
                return "yd²";
            case 4:
                return "mi²";
            case 5:
                return "ha";
            default:
                return "m²";
        }
    }

    private double calculatePolygonArea(ArrayList<LatLng> points) {
        return SphericalUtil.computeArea(points);
    }

    private double convertArea(double areaInSquareMeters, int unitPosition) {
        switch (unitPosition) {
            case 0:
                return areaInSquareMeters;
            case 1:
                return areaInSquareMeters / 1_000_000;
            case 2:
                return areaInSquareMeters * 10.7639;
            case 3:
                return areaInSquareMeters * 1.19599;
            case 4:
                return areaInSquareMeters / 2_589_988;
            case 5:
                return areaInSquareMeters / 10_000;
            default:
                return areaInSquareMeters;
        }
    }

    private void clearMap() {

        img_delet.setVisibility(View.GONE);
        img_redo.setVisibility(View.GONE);
        img_undo.setVisibility(View.GONE);
        for (Marker marker : Vertex_marker_list) {
            marker.remove();
        }
        Vertex_marker_list.clear();

        for (Marker marker : Midpoint_marker_list) {
            marker.remove();
        }
        Midpoint_marker_list.clear();


        if (polyline != null) {
            polyline.remove();
            polyline = null;
        }

        if (polygon != null) {
            polygon.remove();
            polygon = null;
        }

        txt_area.setText("Area: 0.00 km2");

        polygonFinalized = false;
        polygonColor = Color.argb(51, 255, 0, 0);
    }

    private String saveBitmapToFile(Bitmap bitmap) {
        File directory = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "PolygonImages");
        if (!directory.exists()) {
            directory.mkdirs();
        }

        String fileName = "polygon_" + System.currentTimeMillis() + ".png";
        File imageFile = new File(directory, fileName);

        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

        return imageFile.getAbsolutePath();
    }

    private void saveState() {
        List<LatLng> currentState = new ArrayList<>();
        for (Marker marker : Vertex_marker_list) {
            currentState.add(marker.getPosition());
        }
        undoStack.push(new ArrayList<>(currentState));
        redoStack.clear();
    }


    public void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15));
            }
        });
    }

    private void checkLocationPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    private void addVertexMarker(LatLng latLng) {
        img_delet.setVisibility(View.VISIBLE);
        img_redo.setVisibility(View.VISIBLE);
        img_undo.setVisibility(View.VISIBLE);


        Marker marker = map.addMarker(new MarkerOptions().position(latLng).title("Vertex " + (Vertex_marker_list.size() + 1)).draggable(true).icon(getCustomMarkerIcon(R.drawable.red_marker)));
        if (marker != null) {
            Vertex_marker_list.add(marker);
        }
    }

    private void showDeleteDialog(Marker marker) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.diloge_marker_delet, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();

        LinearLayout lin_no = dialogView.findViewById(R.id.lin_no);
        LinearLayout lin_yes = dialogView.findViewById(R.id.lin_yes);

        lin_no.setOnClickListener(v -> dialog.dismiss());

        lin_yes.setOnClickListener(v -> {
            deleteMarker(marker);
            dialog.dismiss();
            updateAreaText();
        });
        dialog.setCancelable(true);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        dialog.show();
    }

    private void deleteMarker(Marker marker) {
        saveState();
        marker.remove();
        Vertex_marker_list.remove(marker);

        if (Vertex_marker_list.isEmpty()) {
            polygonFinalized = false;
            Midpoint_marker_list.clear();
            polyline.remove();
        }

        if (polygonFinalized) {
            createPolygon();
            updateMidpointMarkers();
            updatePolyline();
            updateAreaText();
        } else {
            updatePolyline();
        }
    }

    private void handleMidpointInsertion(Marker midMarker) {
        int edgeIndex = (int) midMarker.getTag();
        int n = Vertex_marker_list.size();
        Marker A_marker = Vertex_marker_list.get(edgeIndex);
        Marker B_marker = Vertex_marker_list.get((edgeIndex + 1) % n);
        LatLng M = midMarker.getPosition();
        Marker newMarker = map.addMarker(new MarkerOptions().position(M).title("Vertex " + (Vertex_marker_list.size() + 1)).draggable(true).icon(getCustomMarkerIcon(R.drawable.red_marker)));

        Vertex_marker_list.add(edgeIndex + 1, newMarker);
        midMarker.remove();

        if (polygonFinalized) {
            createPolygon();
        } else {
            updatePolyline();
        }
        updateMidpointMarkers();
    }

    private void finalizePolygon() {
        polygonFinalized = true;
        createPolygon();
        updateMidpointMarkers();
    }

    private BitmapDescriptor getCustomMarkerIcon(int drawableResId) {
        Drawable drawable = getResources().getDrawable(drawableResId);
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    private void createPolygon() {
        if (polygon != null) {
            polygon.remove();
        }
        if (Vertex_marker_list.size() < 3) return;
        int strokeColor = ContextCompat.getColor(this, R.color.RED);

        PolygonOptions options = new PolygonOptions().strokeWidth(5).strokeColor(strokeColor).fillColor(polygonColor);
        for (Marker m : Vertex_marker_list) {
            options.add(m.getPosition());
        }
        polygon = map.addPolygon(options);
        updateAreaText();

        if (polyline != null) {
            polyline.remove();
            polyline = null;
        }
    }

    private void updateMidpointMarkers() {

        for (Marker m : Midpoint_marker_list) {
            m.remove();
        }
        Midpoint_marker_list.clear();

        int n = Vertex_marker_list.size();
        if (n < 2) return;

        // Map units
        Map<String, String> unitShortForms = new HashMap<>();
        unitShortForms.put("Meters", "M");
        unitShortForms.put("Kilometers", "Km");
        unitShortForms.put("Feet", "Ft");
        unitShortForms.put("Yards", "Yd");
        unitShortForms.put("Miles", "Mi");
        unitShortForms.put("Hectares", "H");

        String selectedUnit = sp_permeter_unit.getSelectedItem().toString();
        String shortForm = unitShortForms.getOrDefault(selectedUnit, selectedUnit);
        double conversionFactor = getUnitConversionFactor(selectedUnit);

        for (int i = 0; i < n; i++) {
            LatLng A = Vertex_marker_list.get(i).getPosition();
            LatLng B = Vertex_marker_list.get((i + 1) % n).getPosition();


            LatLng mid = SphericalUtil.interpolate(A, B, 0.5); // <-- KEY LINE


            float[] results = new float[1];
            Location.distanceBetween(A.latitude, A.longitude, B.latitude, B.longitude, results);
            double distanceInSelectedUnit = results[0] * conversionFactor;
            String lengthText = String.format("%.2f %s", distanceInSelectedUnit, shortForm);

            MarkerOptions markerOptions = new MarkerOptions().position(mid).title("Insert here").draggable(true).anchor(0.5f, 0.5f); // Centered

            if (showLength) {
                Bitmap lengthBitmap = createTextBitmap(lengthText);
                markerOptions.icon(BitmapDescriptorFactory.fromBitmap(lengthBitmap));
            } else {
                markerOptions.icon(getCustomMarkerIcon(R.drawable.middle_marker));
            }

            Marker midMarker = map.addMarker(markerOptions);
            midMarker.setTag(i);
            Midpoint_marker_list.add(midMarker);
        }
    }


    private double getUnitConversionFactor(String unit) {
        switch (unit) {
            case "Kilometers":
                return 0.001;
            case "Feet":
                return 3.28084;
            case "Yards":
                return 1.09361;
            case "Miles":
                return 0.000621371;
            case "Hectares":
                return 0.0001;
            default:
                return 1;
        }
    }

    private void updatePolyline() {
        if (polyline != null) {
            polyline.remove();
        }
        if (Vertex_marker_list.size() < 2) return;
        int strokeColor = ContextCompat.getColor(this, R.color.RED);
        PolylineOptions options = new PolylineOptions().width(5).color(strokeColor);
        for (Marker m : Vertex_marker_list) {
            options.add(m.getPosition());
        }
        polyline = map.addPolyline(options);
    }

    private void updatePolygonShape() {
        if (polygon != null) {
            List<LatLng> points = new ArrayList<>();
            for (Marker m : Vertex_marker_list) {
                points.add(m.getPosition());
            }
            polygon.setPoints(points);
        }
    }

    private Bitmap createTextBitmap(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextSize(14);
        textView.setTextColor(Color.BLACK);
        textView.setBackgroundColor(getResources().getColor(R.color.white_with_low_opacity));
        textView.setPadding(10, 10, 10, 10);
        textView.measure(android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED), android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED));
        textView.layout(0, 0, textView.getMeasuredWidth(), textView.getMeasuredHeight());
        Bitmap bitmap = Bitmap.createBitmap(textView.getMeasuredWidth(), textView.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        textView.draw(canvas);
        return bitmap;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation();
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}