package gps.landareacalculator.landmeasurement.field.areameasure.Adpter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RadioButton;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import gps.landareacalculator.landmeasurement.field.areameasure.Modelclass.LanguageListModal;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.LocaleHelper;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class LangugesAdapter extends RecyclerView.Adapter<LangugesAdapter.ThemeMainViewHolder> {
    private final Context context;
    private final ArrayList<LanguageListModal> languageList;
    private int selectedPosition =0 ;

    public LangugesAdapter(Context context, ArrayList<LanguageListModal> languageList, String selectedLangCode) {
        this.languageList = languageList;
        this.context = context;
        this.selectedPosition = getSelectedPosition(selectedLangCode);
        if (this.selectedPosition < 0 || this.selectedPosition >= languageList.size()) {
            this.selectedPosition = 0;
        }
    }

    @NonNull
    @Override
    public ThemeMainViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.language_list_item, parent, false);
        return new ThemeMainViewHolder(itemView);
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onBindViewHolder(@NonNull final ThemeMainViewHolder holder, final int position) {
        final LanguageListModal languageListModal = languageList.get(position);
        holder.txt_languges_name.setText(languageListModal.getLanguageName());
        holder.img_flag.setImageResource(languageListModal.getLanguageImage());

        boolean isSelected = selectedPosition == position;
        holder.rdSelectLanguage.setChecked(isSelected);
        if (isSelected) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(context, R.color.color_primary));
            holder.txt_languges_name.setTextColor(ContextCompat.getColor(context, R.color.white));
        } else {
            holder.itemView.setBackgroundColor(Color.TRANSPARENT);
            holder.txt_languges_name.setTextColor(ContextCompat.getColor(context, R.color.black_2));
        }

        holder.itemView.setOnClickListener(v -> {
            selectedPosition = position;
            LocaleHelper.setLocale(context, languageListModal.getLanguageCode());
            notifyDataSetChanged();
        });
    }

    @Override
    public int getItemCount() {
        return languageList.size();
    }

    public String getSelectedLanguageCode() {
        if (selectedPosition < 0 || selectedPosition >= languageList.size()) {
            selectedPosition = 0;
        }
        return languageList.get(selectedPosition).getLanguageCode();
    }


    private int getSelectedPosition(String languageCode) {
        for (int i = 0; i < languageList.size(); i++) {
            if (languageList.get(i).getLanguageCode().equals(languageCode)) {
                return i;
            }
        }
        return 0;
    }

    public static class ThemeMainViewHolder extends RecyclerView.ViewHolder {
        AppCompatTextView txt_languges_name;
        AppCompatImageView img_flag;
        RadioButton rdSelectLanguage;
        LinearLayout lin_Parents;

        ThemeMainViewHolder(View itemView) {
            super(itemView);
            txt_languges_name = itemView.findViewById(R.id.txt_languges_name);
            img_flag = itemView.findViewById(R.id.img_flag);
            rdSelectLanguage = itemView.findViewById(R.id.rdSelectLanguage);
            lin_Parents = itemView.findViewById(R.id.lin_Parents);
        }
    }
}