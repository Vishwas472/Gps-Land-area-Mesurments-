package gps.landareacalculator.landmeasurement.field.areameasure;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.ProcessLifecycleOwner;

import java.util.List;
import java.util.Objects;

import android.os.Handler;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.AcknowledgePurchaseResponseListener;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.ProductDetailsResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.common.collect.ImmutableList;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.messaging.FirebaseMessaging;

import gps.landareacalculator.landmeasurement.field.areameasure.Activity.AutomaticAreaCalCulatoreActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.Activity.AutomaticDistanceCalculateActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.Activity.FeedBackActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.Activity.KmlFileReaderActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.Activity.LandAreaFormulaActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.Activity.ManuallyAreaCalculateActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.Activity.ManuallyDistanceCalculateActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.Activity.SavedlistActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.Activity.SettingActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.AppCompany_const;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.PrefManager;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.BaseActivity;

public class HomeActivity extends BaseActivity implements PurchasesUpdatedListener {

    RelativeLayout rel_area_mesure, rel_saved_list, rel_kml_file, rel_distance_mesure, rel_formula;
    private static final int PICK_KML_FILE_REQUEST = 1;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 100;
    private static final int LOCATION_SERVICE_REQUEST_CODE = 100;
    ImageView img_setting, img_ads;
    FirebaseAnalytics mFirebaseAnalytics;
    public BillingClient mBillingClient;
    RelativeLayout layout;
    com.google.android.gms.ads.AdView adView;
    int adCode;
    PrefManager prefManager;
    InterstitialAd mInterstitialAd;
    private static final int STAR_COUNT = 5;
    private ImageView[] starImageViews = new ImageView[STAR_COUNT];

    void LoadAD() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, AppCompany_const.INTRESTITIAL_AD_PUB_ID, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                mInterstitialAd = interstitialAd;
                mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        LoadAD();
                        if (adCode == 1) {
                            Intent intent = new Intent(HomeActivity.this, ManuallyDistanceCalculateActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }
                        if (adCode == 2) {
                            Intent intent = new Intent(HomeActivity.this, AutomaticDistanceCalculateActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }
                        if (adCode == 3) {
                            Intent intent = new Intent(HomeActivity.this, ManuallyAreaCalculateActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }
                        if (adCode == 4) {
                            Intent intent = new Intent(HomeActivity.this, AutomaticAreaCalCulatoreActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }
                        if (adCode == 5) {
                            Intent intent = new Intent(HomeActivity.this, SavedlistActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }
                        if (adCode == 6) {

                            Intent intent = new Intent(HomeActivity.this, LandAreaFormulaActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);


                        }

                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        Log.d("TAG", "The ad failed to show.");


                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        mInterstitialAd = null;
                        Log.d("TAG", "The ad was shown.");
                    }
                });
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                mInterstitialAd = null;
            }
        });
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle params = new Bundle();
        params.putInt("AppLandAreaOpenHomeScreenID", 1);
        mFirebaseAnalytics.logEvent("AppLandAreaOpenHomeScreen", params);

        prefManager = new PrefManager(HomeActivity.this);

        BillingClient build = BillingClient.newBuilder(this).enablePendingPurchases().setListener(this).build();
        this.mBillingClient = build;
        build.startConnection(new BillingClientStateListener() {
            public void onBillingServiceDisconnected() {
            }

            public void onBillingSetupFinished(BillingResult billingResult) {
            }
        });
        queryPurchases();

        layout = findViewById(R.id.adView);
        if (!prefManager.getvalue()) {
            if (AppCompany_const.isActive_adMob) {
                LoadAD();
//                adView = new com.google.android.gms.ads.AdView(this);
//                adView.setAdSize(AdSize.MEDIUM_RECTANGLE);
//                adView.setAdUnitId(AppCompany_const.RECTANGLE_BANNER_AD_PUB_ID);
//                layout.addView(adView);
//                AdRequest adRequest = new AdRequest.Builder().build();
//                adView.loadAd(adRequest);

            }
        }

        rel_area_mesure = findViewById(R.id.rel_area_mesure);
        rel_saved_list = findViewById(R.id.rel_saved_list);
        rel_kml_file = findViewById(R.id.rel_kml_file);
        rel_distance_mesure = findViewById(R.id.rel_distance_mesure);
        rel_formula = findViewById(R.id.rel_formula);
        img_setting = findViewById(R.id.img_setting);
        img_ads = findViewById(R.id.img_ads);

        if (!isLocationEnabled()) {
            showLocationDialog();
        }

        showdiloge();
        checkLocationPermission();

        rel_area_mesure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAreamesureDiloge();
            }
        });

        rel_distance_mesure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDistancemesureDiloge();
            }
        });

        rel_saved_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Bundle params = new Bundle();
                params.putInt("AppLandAreaHomeSavedListBtnClickID", view.getId());
                mFirebaseAnalytics.logEvent("AppLandAreaHomeSavedListBtnClick", params);

                adCode = 5;
                if (mInterstitialAd != null) {
                    if (ProcessLifecycleOwner.get().getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {
                        mInterstitialAd.show(HomeActivity.this);
                    }
                } else {
                    Intent intent = new Intent(HomeActivity.this, SavedlistActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }


            }
        });

        rel_kml_file.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Bundle params = new Bundle();
                params.putInt("AppLandAreaHomeKMLFileBtnClickID", view.getId());
                mFirebaseAnalytics.logEvent("AppLandAreaHomeKMLFileBtnClick", params);

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("application/vnd.google-earth.kml+xml");
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivityForResult(intent, PICK_KML_FILE_REQUEST);
            }
        });


        rel_formula.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Bundle params = new Bundle();
                params.putInt("AppLandAreaHomeFormulaBtnClickID", view.getId());
                mFirebaseAnalytics.logEvent("AppLandAreaHomeFormulaBtnClick", params);

                adCode = 6;
                if (mInterstitialAd != null) {
                    if (ProcessLifecycleOwner.get().getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {
                        mInterstitialAd.show(HomeActivity.this);
                    }
                } else {
                    Intent intent = new Intent(HomeActivity.this, LandAreaFormulaActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }


            }
        });

        img_setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(HomeActivity.this, SettingActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        img_ads.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogRemoveAds();
            }
        });

        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(new OnCompleteListener<String>() {
            @Override
            public void onComplete(@NonNull Task<String> task) {
                if (!task.isSuccessful()) {
                    Log.w("Home", "Fetching FCM registration token failed", task.getException());
                    return;
                }

                // Get new FCM registration token
                String token = task.getResult();

                // Log and toast
                String msg = "InstanceID Token: %s" + token;
                Log.d("Home", msg);
            }
        });

    }

    private void showdiloge() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.diloge_rating);

        ImageView img_rate = dialog.findViewById(R.id.img_rate);
        TextView txt_Rate_this = dialog.findViewById(R.id.txt_Rate_this);
        TextView txt_request = dialog.findViewById(R.id.txt_request);
        ImageView img_cancel = dialog.findViewById(R.id.img_cancel);
        RelativeLayout rel_rate = dialog.findViewById(R.id.rel_rate);
        TextView txt_rate = dialog.findViewById(R.id.txt_rate);
        LinearLayout ratingBarLayout = dialog.findViewById(R.id.custom_rating_bar);
        final float[] currentRating = {0};

        setupCustomRatingBar(currentRating,ratingBarLayout,img_rate,txt_Rate_this,txt_request,img_cancel,rel_rate,txt_rate); // Pass the correct ratingBarLayout


        dialog.setCancelable(false);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );

        img_cancel.setOnClickListener(view -> dialog.dismiss());

        rel_rate.setOnClickListener(v -> {
            if (currentRating[0] == 0.0f) {
                Toast.makeText(HomeActivity.this, "Please provide a rating before continuing.", Toast.LENGTH_SHORT).show();
                return;
            }

            updateUI((int) currentRating[0], img_rate, txt_rate, txt_request, rel_rate, txt_Rate_this);

            if (currentRating[0] == 2.0f) {
                dialog.dismiss();
                Dialog dialog2 = new Dialog(HomeActivity.this);
                dialog2.setContentView(R.layout.diloge_request_feedback);
                dialog2.setCancelable(false);

                RelativeLayout rel_Feedback = dialog2.findViewById(R.id.rel_Feedback);
                TextView txt_later = dialog2.findViewById(R.id.txt_later);

                rel_Feedback.setOnClickListener(view1 -> {
                    Intent intent = new Intent(HomeActivity.this, FeedBackActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    dialog2.dismiss();
                });

                txt_later.setOnClickListener(view1 -> dialog2.dismiss());

                dialog2.setCancelable(true);
                Objects.requireNonNull(dialog2.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog2.getWindow().setLayout(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );

                dialog2.show();
            }else if (currentRating[0] == 1.0f) {
                dialog.dismiss();
                Dialog dialog2 = new Dialog(HomeActivity.this);
                dialog2.setContentView(R.layout.diloge_request_feedback);
                dialog2.setCancelable(false);

                RelativeLayout rel_Feedback = dialog2.findViewById(R.id.rel_Feedback);
                TextView txt_later = dialog2.findViewById(R.id.txt_later);

                rel_Feedback.setOnClickListener(view1 -> {
                    Intent intent = new Intent(HomeActivity.this, FeedBackActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    dialog2.dismiss();
                });

                txt_later.setOnClickListener(view1 -> dialog2.dismiss());

                dialog2.setCancelable(true);
                Objects.requireNonNull(dialog2.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog2.getWindow().setLayout(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );

                dialog2.show();
            }else if (currentRating[0] == 3.0f) {
                dialog.dismiss();
                Dialog dialog2 = new Dialog(HomeActivity.this);
                dialog2.setContentView(R.layout.diloge_request_feedback);
                dialog2.setCancelable(false);

                RelativeLayout rel_Feedback = dialog2.findViewById(R.id.rel_Feedback);
                TextView txt_later = dialog2.findViewById(R.id.txt_later);

                rel_Feedback.setOnClickListener(view1 -> {
                    Intent intent = new Intent(HomeActivity.this, FeedBackActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    dialog2.dismiss();
                });

                txt_later.setOnClickListener(view1 -> dialog2.dismiss());

                dialog2.setCancelable(true);
                Objects.requireNonNull(dialog2.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog2.getWindow().setLayout(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );

                dialog2.show();
            } else {
                dialog.dismiss();
            }
        });

        dialog.show();
    }
    private void setupCustomRatingBar(float[] currentRating, LinearLayout ratingBarLayout, ImageView img_rate, TextView txt_Rate_this, TextView txt_request, ImageView img_cancel, RelativeLayout rel_rate, TextView txt_rate) {
        for (int i = 0; i < STAR_COUNT; i++) {
            final int index = i;
            ImageView star = new ImageView(this);
            star.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            star.setPadding(10, 10, 10, 10);
            star.setImageResource(R.drawable.blank_satr);
            ratingBarLayout.addView(star);
            starImageViews[i] = star;

            // Tap-to-rate
            star.setOnClickListener(v -> {
                int clickedRating = index + 1;
                if (currentRating[0] == clickedRating) {
                    currentRating[0] = clickedRating - 1;
                } else {
                    currentRating[0] = clickedRating;
                }
                updateStarImages(currentRating);
                // Call updateUI based on the selected rating
                updateUI((int) currentRating[0], img_rate, txt_rate, txt_request, rel_rate, txt_Rate_this);
            });
        }

        // Swipe-to-rate
        ratingBarLayout.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_MOVE || event.getAction() == MotionEvent.ACTION_DOWN) {
                float touchX = event.getX();  // Local x relative to ratingBarLayout

                int newRating = 0;
                for (int i = 0; i < STAR_COUNT; i++) {
                    ImageView star = starImageViews[i];
                    int starLeft = star.getLeft();
                    int starRight = star.getRight();

                    if (touchX >= starLeft && touchX < starRight) {
                        newRating = i + 1;
                    }
                }

                // Check if it's fully to the left
                if (touchX < starImageViews[0].getLeft()) {
                    newRating = 0;
                }

                // Check if it's beyond the last star
                if (touchX > starImageViews[STAR_COUNT - 1].getRight()) {
                    newRating = STAR_COUNT;
                }

                if (newRating != currentRating[0]) {
                    currentRating[0] = newRating;
                    updateStarImages(currentRating);
                    // Call updateUI based on the new rating
                    updateUI((int) currentRating[0], img_rate, txt_rate, txt_request, rel_rate, txt_Rate_this);
                }
            }
            return true;
        });
    }

    private void updateStarImages(float[] currentRating) {
        for (int i = 0; i < STAR_COUNT; i++) {
            if (i < currentRating[0]) {
                starImageViews[i].setImageResource(R.drawable.rate_star);
            } else {
                starImageViews[i].setImageResource(R.drawable.blank_satr);
            }
        }
    }

    private void updateUI(int rating, ImageView img_rate, TextView txt_rate, TextView txt_request, RelativeLayout rel_rate, TextView txt_Rate_this) {

        switch (rating) {
            case 0:
                img_rate.setImageResource(R.drawable.rate);
                txt_Rate_this.setText("Please Rate This App");
                txt_request.setText("Please take a minute to rate this app");
                rel_rate.setBackgroundResource(R.drawable.btn_grey);
                txt_rate.setTextColor(R.color.grey);
                break;
            case 1:
                img_rate.setImageResource(R.drawable.rate_1);
                txt_Rate_this.setText("Oh! We’re Sorry...");
                txt_request.setText("your feedback would be appreciated ");
                rel_rate.setBackgroundResource(R.drawable.bg_purpel);
                txt_rate.setTextColor(Color.WHITE);
                break;
            case 2:
                img_rate.setImageResource(R.drawable.rate_2);
                txt_Rate_this.setText("Oh! We’re Sorry...");
                txt_request.setText("Your feedback would be appreciated");
                rel_rate.setBackgroundResource(R.drawable.bg_purpel);
                txt_rate.setTextColor(Color.WHITE);
                break;
            case 3:
                img_rate.setImageResource(R.drawable.rate_3);
                txt_Rate_this.setText("Thanks for your support!");
                txt_request.setText("Feel free to give us your feedback");
                rel_rate.setBackgroundResource(R.drawable.bg_purpel);
                txt_rate.setTextColor(Color.WHITE);
                break;
            case 4:
                img_rate.setImageResource(R.drawable.rate_4);
                txt_Rate_this.setText("Glad you enjoyed our app");
                txt_request.setText("Your trust will motivate us to do better.");
                rel_rate.setBackgroundResource(R.drawable.bg_purpel);
                txt_rate.setTextColor(Color.WHITE);
                break;
            case 5:
                img_rate.setImageResource(R.drawable.rate_5);
                txt_Rate_this.setText("Glad you enjoyed our app");
                txt_request.setText("Your trust will motivate us to do better.");
                rel_rate.setBackgroundResource(R.drawable.bg_purpel);
                txt_rate.setTextColor(Color.WHITE);
                break;
            default:
                break;
        }
    }

    private boolean isLocationEnabled() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else {

        }
    }

    private void showLocationDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.diloge_location_service);
        dialog.setCancelable(false);

        LinearLayout lin_enable = dialog.findViewById(R.id.lin_enable);
        LinearLayout lin_canecel = dialog.findViewById(R.id.lin_canecel);

        lin_enable.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivityForResult(intent, LOCATION_SERVICE_REQUEST_CODE);

            dialog.dismiss();
        });

        lin_canecel.setOnClickListener(v -> dialog.dismiss());
        dialog.setCancelable(true);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );


        dialog.show();

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isLocationEnabled()) {
                    dialog.dismiss(); // Dismiss dialog if location is enabled
                } else {
                    new Handler(Looper.getMainLooper()).postDelayed(this, 1000); // Re-check every second
                }
            }
        }, 1000);
    }

    private void showDistancemesureDiloge() {

        Dialog dialog = new Dialog(this);


        View view = LayoutInflater.from(this).inflate(R.layout.dialog_area_calucalte, null);
        dialog.setContentView(view);


        dialog.setCancelable(true);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        TextView txtmanuually = view.findViewById(R.id.txtmanuually);
        TextView txtAutomatic = view.findViewById(R.id.txtAutomatic);
        ImageView img_mannually = view.findViewById(R.id.img_mannually);


        RelativeLayout btn_mannually = view.findViewById(R.id.rel_mannually);
        RelativeLayout btn_AutoMatic = view.findViewById(R.id.rel_automatic);
        txtmanuually.setText(R.string.manually_by_multiple_points);
        txtAutomatic.setText(R.string.measure_distance_by_walking);
        img_mannually.setImageResource(R.drawable.ic_manually_2);

        btn_mannually.setOnClickListener(v -> {

            Bundle params = new Bundle();
            params.putInt("AppLandAreaHomeDisatanceManualBtnClickID", v.getId());
            mFirebaseAnalytics.logEvent("AppLandAreaHomeDisatanceManualBtnClick", params);

            adCode = 1;
            if (mInterstitialAd != null) {
                if (ProcessLifecycleOwner.get().getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {
                    mInterstitialAd.show(HomeActivity.this);
                }
            } else {
                Intent intent = new Intent(HomeActivity.this, ManuallyDistanceCalculateActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }


            dialog.dismiss();
        });

        btn_AutoMatic.setOnClickListener(v -> {

            Bundle params = new Bundle();
            params.putInt("AppLandAreaHomeDisatanceAutoBtnClickID", v.getId());
            mFirebaseAnalytics.logEvent("AppLandAreaHomeDisatanceAutoBtnClick", params);

            adCode = 2;
            if (mInterstitialAd != null) {
                if (ProcessLifecycleOwner.get().getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {
                    mInterstitialAd.show(HomeActivity.this);
                }
            } else {
                Intent intent = new Intent(HomeActivity.this, AutomaticDistanceCalculateActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }


            dialog.dismiss();
        });


        dialog.show();
    }

    private void showAreamesureDiloge() {
        Dialog dialog = new Dialog(this);


        View view = LayoutInflater.from(this).inflate(R.layout.dialog_area_calucalte, null);
        dialog.setContentView(view);


        dialog.setCancelable(true);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );

        RelativeLayout btn_mannually = view.findViewById(R.id.rel_mannually);
        RelativeLayout btn_AutoMatic = view.findViewById(R.id.rel_automatic);


        btn_mannually.setOnClickListener(v -> {

            Bundle params = new Bundle();
            params.putInt("AppLandAreaHomeAreaManualBtnClickID", v.getId());
            mFirebaseAnalytics.logEvent("AppLandAreaHomeAreaManualBtnClick", params);

            adCode = 3;
            if (mInterstitialAd != null) {
                if (ProcessLifecycleOwner.get().getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {
                    mInterstitialAd.show(HomeActivity.this);
                }
            } else {
                Intent intent = new Intent(HomeActivity.this, ManuallyAreaCalculateActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }


            dialog.dismiss();
        });

        btn_AutoMatic.setOnClickListener(v -> {

            Bundle params = new Bundle();
            params.putInt("AppLandAreaHomeAreaAutoBtnClickID", v.getId());
            mFirebaseAnalytics.logEvent("AppLandAreaHomeAreaAutoBtnClick", params);

            adCode = 4;
            if (mInterstitialAd != null) {
                if (ProcessLifecycleOwner.get().getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {
                    mInterstitialAd.show(HomeActivity.this);
                }
            } else {
                Intent intent = new Intent(HomeActivity.this, AutomaticAreaCalCulatoreActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }


            dialog.dismiss();
        });


        dialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (!prefManager.getvalue()) {
            if (AppCompany_const.isActive_adMob) {
                if (layout != null) {
                    adView = new com.google.android.gms.ads.AdView(this);
                    adView.setAdSize(AdSize.MEDIUM_RECTANGLE);
                    adView.setAdUnitId(AppCompany_const.RECTANGLE_BANNER_AD_PUB_ID);
                    layout.addView(adView);
                    AdRequest adRequest = new AdRequest.Builder().build();
                    adView.loadAd(adRequest);
                }
            }
        }


        if (!isLocationEnabled()) {
            showLocationDialog(); // Show dialog again if location is still disabled
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_KML_FILE_REQUEST && resultCode == RESULT_OK) {
            Uri selectedFileUri = data.getData();
            if (selectedFileUri != null) {

                Intent intent = new Intent(HomeActivity.this, KmlFileReaderActivity.class);
                intent.putExtra("KML_FILE_URI", selectedFileUri.toString());
                startActivity(intent);
            } else {
                Toast.makeText(this, "No file selected", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                } else {
                    Toast.makeText(this, "Location Permission Denied", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            } else {
                Toast.makeText(this, "Location Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }


    public void dialogRemoveAds() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.diloge_purchase);
        dialog.setCancelable(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );


        LinearLayout lin_purchase = dialog.findViewById(R.id.lin_purchase);
        LinearLayout lin_cancel = dialog.findViewById(R.id.lin_cancel);

        lin_purchase.setOnClickListener(v -> {
            dialog.dismiss();
            try {
                InAppPurchase();
            } catch (Exception e) {
            }
        });

        lin_cancel.setOnClickListener(v -> {
            dialog.dismiss();
        });

        dialog.show();
    }

    public void InAppPurchase() {
        this.mBillingClient.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(ImmutableList.of(QueryProductDetailsParams.Product.newBuilder().setProductId(PrefManager.REMOVE_ADS_PRODUCT_ID).setProductType("inapp").build())).build(), new ProductDetailsResponseListener() {
            public void onProductDetailsResponse(BillingResult billingResult, List<ProductDetails> list) {
                for (ProductDetails next : list) {

                    if (PrefManager.REMOVE_ADS_PRODUCT_ID.equals(next.getProductId())) {
                        mBillingClient.launchBillingFlow(HomeActivity.this, BillingFlowParams.newBuilder().setProductDetailsParamsList(ImmutableList.of(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(next).build())).build()).getResponseCode();
                    }

                }
            }
        });


    }

    @Override
    public void onDestroy() {
        if (adView != null) {
            adView.destroy();
        }
        super.onDestroy();
    }

    private void queryPurchases() {
        this.mBillingClient.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType("inapp").build(), new PurchasesResponseListener() {
            public void onQueryPurchasesResponse(BillingResult billingResult, List<Purchase> list) {
                if (list != null && !list.isEmpty()) {
                    for (Purchase products : list) {
                        if (products.getProducts().contains(PrefManager.REMOVE_ADS_PRODUCT_ID)) {
                            prefManager.setvalue(true);
                        }
                    }
                }
            }
        });


    }

    public void onPurchasesUpdated(BillingResult billingResult, @Nullable List<Purchase> list) {
        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && list != null) {
            for (Purchase handlePurchase : list) {
                handlePurchase(handlePurchase);
            }
        } else if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.USER_CANCELED && billingResult.getResponseCode() == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
            prefManager.setvalue(true);

        }
    }

    private void handlePurchase(Purchase purchase) {
        if (purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
            AcknowledgePurchaseResponseListener acknowledgePurchaseResponseListener = new AcknowledgePurchaseResponseListener() {
                public void onAcknowledgePurchaseResponse(BillingResult billingResult) {
                    Log.e("result", "" + billingResult.getResponseCode() + "::" + billingResult.getDebugMessage());
                    if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                        prefManager.setvalue(true);
                    }
                }
            };
            if (!purchase.isAcknowledged()) {
                this.mBillingClient.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build(), acknowledgePurchaseResponseListener);
            } else if (purchase.getProducts().contains(PrefManager.REMOVE_ADS_PRODUCT_ID)) {
                prefManager.setvalue(true);
            }
        }


    }

    @Override
    public void onBackPressed() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.diloge_exit);
        dialog.setCancelable(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );

        RelativeLayout layout = dialog.findViewById(R.id.adView);
        if (!prefManager.getvalue()) {
            if (AppCompany_const.isActive_adMob) {
                com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(this);
                adView.setAdSize(AdSize.MEDIUM_RECTANGLE);
                adView.setAdUnitId(AppCompany_const.RECTANGLE_BANNER_AD_PUB_ID);
                layout.addView(adView);
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);

            }
        }

        LinearLayout lin_yes = dialog.findViewById(R.id.lin_yes);
        LinearLayout lin_no = dialog.findViewById(R.id.lin_no);

        lin_yes.setOnClickListener(v -> {
            dialog.dismiss();
            finish();
        });

        lin_no.setOnClickListener(v -> {
            dialog.dismiss();
        });

        dialog.show();
    }

}