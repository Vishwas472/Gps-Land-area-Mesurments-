package gps.landareacalculator.landmeasurement.field.areameasure.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Stack;

import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.AppCompany_const;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.PrefManager;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.BaseActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.DatabaseHelper;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class ManuallyDistanceCalculateActivity extends BaseActivity implements OnMapReadyCallback {
    private GoogleMap map;
    DatabaseHelper databaseHelper;
    private List<LatLng> marker_point_list = new ArrayList<>();
    private List<Marker> Vertax_marker_list = new ArrayList<>();
    private List<Marker> Midpoint_marker_list = new ArrayList<>();
    private Stack<List<LatLng>> undoStack = new Stack<>();
    private Stack<List<LatLng>> redoStack = new Stack<>();
    private Polyline polyline;
    Toolbar toolbar;
    private TextView txt_distance;
    private RelativeLayout rel_save;
    ImageView img_hide_show, img_undo, img_redo, img_map_type, img_Delet, img_current_location, img_back;
    Spinner sp_permeter_unit;
    private FusedLocationProviderClient fusedLocationClient;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;
    int a;
    private boolean showDistance = true;
    private String str_current_map_type = "Street View";


    PrefManager prefManager;
    RelativeLayout layout;

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manually_distance_calculate);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        prefManager = new PrefManager(ManuallyDistanceCalculateActivity.this);
        layout = (RelativeLayout) findViewById(R.id.adView);
        if (!prefManager.getvalue()) {
            if (AppCompany_const.isActive_adMob) {
                com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(this);
                adView.setAdSize(getAdSize());
                adView.setAdUnitId(AppCompany_const.BANNER_AD_PUB_ID);
                layout.addView(adView);
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);

            }
        }


        txt_distance = findViewById(R.id.txt_distance);
        img_hide_show = findViewById(R.id.img_hide_show);
        img_undo = findViewById(R.id.img_undo);
        img_redo = findViewById(R.id.img_redo);
        img_map_type = findViewById(R.id.img_map_type);
        img_Delet = findViewById(R.id.img_Delet);
        sp_permeter_unit = findViewById(R.id.sp_permeter_unit);
        rel_save = findViewById(R.id.rel_save);
        img_current_location = findViewById(R.id.img_curret_loction);

        img_back = findViewById(R.id.img_back);

        databaseHelper = new DatabaseHelper(this);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        img_hide_show.setOnClickListener(v -> {
            showDistance = !showDistance;
            drawPolyline();
            if (showDistance) {
                img_hide_show.setImageResource(R.drawable.ic_show);
            } else {
                img_hide_show.setImageResource(R.drawable.ic_hide);
            }
        });

        img_undo.setOnClickListener(v -> undo());
        img_redo.setOnClickListener(v -> redo());
        img_map_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMapTypeDialog();
            }
        });

        img_Delet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearMap();

            }
        });


        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.permeter_units, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_permeter_unit.setAdapter(adapter2);


        sp_permeter_unit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                drawPolyline();
                calculateDistance();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }
        });

        rel_save.setOnClickListener(v -> {

            Dialog dialog = new Dialog(ManuallyDistanceCalculateActivity.this);
            dialog.setContentView(R.layout.custom_dialog_save);
            dialog.setCancelable(true);


            EditText nameInput = dialog.findViewById(R.id.dialog_name_input);
            RelativeLayout saveButton = dialog.findViewById(R.id.rel_save);
            RelativeLayout cancelButton = dialog.findViewById(R.id.rel_cancel);
            dialog.setCancelable(true);
            Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );

            dialog.show();

            saveButton.setOnClickListener(view -> {
                String name = nameInput.getText().toString();
                if (name.isEmpty()) {
                    Toast.makeText(ManuallyDistanceCalculateActivity.this, "Please enter an area name", Toast.LENGTH_SHORT).show();
                } else {
                    String areaText = txt_distance.getText().toString();
                    double areaValue = 0.0;
                    try {
                        String numericAreaText = areaText.replaceAll("[^0-9.]", "");
                        areaValue = Double.parseDouble(numericAreaText);
                    } catch (NumberFormatException e) {
                        Toast.makeText(ManuallyDistanceCalculateActivity.this, "Invalid area value", Toast.LENGTH_SHORT).show();
                        return;
                    }


                    JSONArray pointsArray = new JSONArray();
                    for (Marker marker : Vertax_marker_list) {
                        LatLng position = marker.getPosition();
                        try {
                            JSONObject point = new JSONObject();
                            point.put("latitude", position.latitude);
                            point.put("longitude", position.longitude);

                            pointsArray.put(point);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }


                    JSONArray Middledata = new JSONArray();
                    for (Marker markerdata : Midpoint_marker_list) {
                        LatLng ssss = markerdata.getPosition();
                        try {
                            JSONObject point = new JSONObject();
                            point.put("latitude", ssss.latitude);
                            point.put("longitude", ssss.longitude);

                            Middledata.put(point);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }


                    String Areaunit = sp_permeter_unit.getSelectedItem().toString();
                    String permterunit = sp_permeter_unit.getSelectedItem().toString();

                    double finalAreaValue = areaValue;
                    map.snapshot(bitmap -> {
                        if (bitmap != null) {
                            String encodedImage = saveBitmapToFile(bitmap);

                            databaseHelper.insertPolygonData(name, finalAreaValue, pointsArray.toString(), Middledata.toString(), Areaunit, str_current_map_type, permterunit, "AUTO_MANNUAL_DISTANCE", encodedImage, a);
                            Toast.makeText(ManuallyDistanceCalculateActivity.this, "Distance saved successfully", Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        } else {

                            Toast.makeText(ManuallyDistanceCalculateActivity.this, "Failed to capture screenshot", Toast.LENGTH_SHORT).show();
                        }
                    });


                    Toast.makeText(ManuallyDistanceCalculateActivity.this, "Distance saved!", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }
            });

            cancelButton.setOnClickListener(view -> {
                dialog.dismiss();
            });


        });


        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        img_current_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getCurrentLocation();
            }
        });

    }

    public void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15));
            }
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;

        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 5));
            } else {
                LatLng defaultLocation = new LatLng(20.5937, 78.9629);
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 5));
            }
        });

        map.setOnMapClickListener(latLng -> {
            saveState();
            addVertexMarker(latLng);
            drawPolyline();
            calculateDistance();
        });


        map.setOnMarkerClickListener(marker -> {
            if (Midpoint_marker_list.contains(marker)) {
                convertYellowMarkerToVertex(marker);
                return true;
            } else if (Vertax_marker_list.contains(marker)) {
                showDeleteMarkerDialog(marker);
                return true;
            }
            marker.showInfoWindow();

            return true;
        });


        map.setOnMarkerDragListener(new GoogleMap.OnMarkerDragListener() {
            @Override
            public void onMarkerDragStart(Marker marker) {
                saveState();
            }

            @SuppressLint("PotentialBehaviorOverride")
            @Override
            public void onMarkerDrag(Marker marker) {
                if (Vertax_marker_list.contains(marker)) {
                    updateMarkerPosition(marker);
                    drawPolyline();

                } else if (Midpoint_marker_list.contains(marker)) {
                    int index = Midpoint_marker_list.indexOf(marker);
                    if (index == -1) return;

                    LatLng newPosition = marker.getPosition();


                    LatLng previousPoint = marker_point_list.get(index);
                    LatLng nextPoint = marker_point_list.get(index + 1);

                    int strokeColor = ContextCompat.getColor(ManuallyDistanceCalculateActivity.this, R.color.color_primary);
                    List<LatLng> tempMarkerPoints = new ArrayList<>(marker_point_list);
                    tempMarkerPoints.add(index + 1, newPosition);
                    polyline.remove();

                    polyline = map.addPolyline(new PolylineOptions().
                            addAll(tempMarkerPoints).
                            clickable(true).color(strokeColor));
                }


            }

            @Override
            public void onMarkerDragEnd(Marker marker) {

                if (Midpoint_marker_list.contains(marker)) {
                    insertNewYellowMarkers(marker);
                } else {
                    updateMarkerPosition(marker);
                }
                updateMarkerPosition(marker);
                drawPolyline();
                calculateDistance();
            }
        });

        checkLocationPermission();

    }

    private String saveBitmapToFile(Bitmap bitmap) {
        File directory = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "PolygonImages");
        if (!directory.exists()) {
            directory.mkdirs();
        }

        String fileName = "polygon_" + System.currentTimeMillis() + ".png";
        File imageFile = new File(directory, fileName);

        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

        return imageFile.getAbsolutePath();
    }

    private void clearMap() {
        img_Delet.setVisibility(View.GONE);
        img_undo.setVisibility(View.GONE);
        img_redo.setVisibility(View.GONE);
        if (polyline != null) {
            polyline.remove();
        }


        for (Marker marker : Vertax_marker_list) {
            marker.remove();
        }
        for (Marker marker : Midpoint_marker_list) {
            marker.remove();
        }


        marker_point_list.clear();
        Vertax_marker_list.clear();
        Midpoint_marker_list.clear();


        undoStack.clear();
        redoStack.clear();


        txt_distance.setText("Distance: 0 km");
        showDistance = false;


        str_current_map_type = "Street View";


        if (map != null) {
            map.clear();
        }
    }

    private void showMapTypeDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_map_type, null);

        CheckBox checkStreetView = dialogView.findViewById(R.id.check_street_view);
        CheckBox checkSatelliteView = dialogView.findViewById(R.id.check_satilite_view);
        CheckBox checkTerrainView = dialogView.findViewById(R.id.check_terrain_view);
        CheckBox checkHybridView = dialogView.findViewById(R.id.check_hybrid_view);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();

        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        switch (str_current_map_type) {
            case "Street View":
                checkStreetView.setChecked(true);
                break;
            case "Satellite View":
                checkSatelliteView.setChecked(true);
                break;
            case "Terrain View":
                checkTerrainView.setChecked(true);
                break;
            case "Hybrid View":
                checkHybridView.setChecked(true);
                break;
        }


        View.OnClickListener listener = v -> {

            checkStreetView.setChecked(false);
            checkSatelliteView.setChecked(false);
            checkTerrainView.setChecked(false);
            checkHybridView.setChecked(false);


            ((CheckBox) v).setChecked(true);

            if (v == checkStreetView) {
                map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                str_current_map_type = "Street View";
            } else if (v == checkSatelliteView) {
                map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                str_current_map_type = "Satellite View";
            } else if (v == checkTerrainView) {
                map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                str_current_map_type = "Terrain View";
            } else if (v == checkHybridView) {
                map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                str_current_map_type = "Hybrid View";
            }


            dialog.dismiss();
        };


        checkStreetView.setOnClickListener(listener);
        checkSatelliteView.setOnClickListener(listener);
        checkTerrainView.setOnClickListener(listener);
        checkHybridView.setOnClickListener(listener);

        dialog.show();
    }

    private void checkLocationPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    private void showDeleteMarkerDialog(Marker marker) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.diloge_marker_delet, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();

        LinearLayout lin_no = dialogView.findViewById(R.id.lin_no);
        LinearLayout lin_yes = dialogView.findViewById(R.id.lin_yes);

        lin_no.setOnClickListener(v -> dialog.dismiss());

        lin_yes.setOnClickListener(v -> {
            removeMarker(marker);
            dialog.dismiss();
            calculateDistance();

        });
        dialog.setCancelable(true);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        dialog.show();
    }

    private void removeMarker(Marker marker) {
        int index = Vertax_marker_list.indexOf(marker);
        if (index != -1) {

            marker.remove();
            Vertax_marker_list.remove(index);
            marker_point_list.remove(index);

            drawPolyline();
        }
    }

    private void insertNewYellowMarkers(Marker draggedMarker) {
        int index = Midpoint_marker_list.indexOf(draggedMarker);
        if (index == -1) return;

        LatLng newVertex = draggedMarker.getPosition();
        Midpoint_marker_list.remove(draggedMarker);
        draggedMarker.remove();

        marker_point_list.add(index + 1, newVertex);
        Marker newVertexMarker = map.addMarker(new MarkerOptions()
                .position(newVertex)
                .title("Point " + (index + 2))
                .draggable(true)
                .icon(getCustomMarkerIcon(R.drawable.purple_marker)));
        Vertax_marker_list.add(index + 1, newVertexMarker);

        drawPolyline();
    }

    private void convertYellowMarkerToVertex(Marker marker) {
        LatLng newVertex = marker.getPosition();
        int index = Midpoint_marker_list.indexOf(marker);
        if (index != -1) {
            Midpoint_marker_list.remove(marker);
            marker.remove();

            marker_point_list.add(index + 1, newVertex);
            Marker newMarker = map.addMarker(new MarkerOptions()
                    .position(newVertex)
                    .title("Point " + (index + 2))
                    .draggable(true)
                    .icon(getCustomMarkerIcon(R.drawable.purple_marker)));
            Vertax_marker_list.add(index + 1, newMarker);

            drawPolyline();
        }
    }

    private void updateMarkerPosition(Marker marker) {
        int index = Vertax_marker_list.indexOf(marker);
        if (index != -1) {
            marker_point_list.set(index, marker.getPosition());
        }
    }

    private void saveState() {
        undoStack.push(new ArrayList<>(marker_point_list));
        redoStack.clear();
    }

    private void undo() {
        if (!undoStack.isEmpty()) {
            redoStack.push(new ArrayList<>(marker_point_list));
            marker_point_list = undoStack.pop();
            updateMarkers();
        }
    }

    private void redo() {
        if (!redoStack.isEmpty()) {
            undoStack.push(new ArrayList<>(marker_point_list));
            marker_point_list = redoStack.pop();
            updateMarkers();
        }
    }

    private void updateMarkers() {

        for (Marker marker : Vertax_marker_list) {
            marker.remove();
        }
        Vertax_marker_list.clear();

        for (LatLng point : marker_point_list) {
            Marker marker = map.addMarker(new MarkerOptions()
                    .position(point)
                    .title("Point " + (marker_point_list.indexOf(point) + 1))
                    .draggable(true).icon(getCustomMarkerIcon(R.drawable.purple_marker)));
            Vertax_marker_list.add(marker);
        }
        drawPolyline();
        calculateDistance();
    }

    private void addVertexMarker(LatLng latLng) {
        img_Delet.setVisibility(View.VISIBLE);
        img_undo.setVisibility(View.VISIBLE);
        img_redo.setVisibility(View.VISIBLE);
        Marker marker = map.addMarker(new MarkerOptions()
                .position(latLng)
                .title("Point " + (marker_point_list.size() + 1))
                .draggable(true)
                .icon(getCustomMarkerIcon(R.drawable.purple_marker)));

        if (marker != null) {
            marker_point_list.add(latLng);
            Vertax_marker_list.add(marker);
        }
    }

    private void drawPolyline() {

        if (polyline != null) {
            polyline.remove();
        }

        for (Marker marker : Midpoint_marker_list) {
            marker.remove();
        }
        Midpoint_marker_list.clear();


        if (marker_point_list.size() < 2) {
            return;
        }

        int strokeColor = ContextCompat.getColor(this, R.color.color_primary);

        polyline = map.addPolyline(new PolylineOptions()
                .addAll(marker_point_list)
                .color(strokeColor)
                .width(8)
                .clickable(true));


        boolean isPolylineVisible = polyline.isVisible();


        for (int i = 0; i < marker_point_list.size() - 1; i++) {
            LatLng start = marker_point_list.get(i);
            LatLng end = marker_point_list.get(i + 1);
            LatLng midPoint = getMidPoint(start, end);

            if (isPolylineVisible && showDistance) {

                double segmentDistance = distanceBetween(start, end);
                String selectedUnit = sp_permeter_unit.getSelectedItem().toString();
                String formattedDistance = formatDistance(segmentDistance, selectedUnit);

                Marker distanceMarker = map.addMarker(new MarkerOptions()
                        .position(midPoint)
                        .icon(BitmapDescriptorFactory.fromBitmap(createTextBitmap(formattedDistance))));
                if (distanceMarker != null) {
                    Midpoint_marker_list.add(distanceMarker);
                }
            } else {

                Marker yellowMarker = map.addMarker(new MarkerOptions()
                        .position(midPoint)
                        .icon(getCustomMarkerIcon(R.drawable.middle_marker))
                        .draggable(true));
                if (yellowMarker != null) {
                    Midpoint_marker_list.add(yellowMarker);
                }
            }
        }
    }

    private BitmapDescriptor getCustomMarkerIcon(int drawableResId) {
        Drawable drawable = getResources().getDrawable(drawableResId);
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    private String formatDistance(double distanceInKm, String unit) {
        switch (unit) {
            case "Meters":
                return String.format("%.2f m", distanceInKm * 1000);
            case "Kilometers":
                return String.format("%.2f km", distanceInKm);
            case "Feet":
                return String.format("%.2f ft", distanceInKm * 3280.84);
            case "Yards":
                return String.format("%.2f yd", distanceInKm * 1093.61);
            case "Miles":
                return String.format("%.2f mi", distanceInKm * 0.621371);
            case "Hectares":
                return String.format("%.2f ha", distanceInKm * 100);
            default:
                return String.format("%.2f km", distanceInKm);
        }
    }

    private LatLng getMidPoint(LatLng point1, LatLng point2) {
        return new LatLng(
                (point1.latitude + point2.latitude) / 2,
                (point1.longitude + point2.longitude) / 2
        );
    }

    private Bitmap createTextBitmap(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextSize(14);
        textView.setTextColor(Color.BLACK);
        textView.setBackgroundColor(getResources().getColor(R.color.white_with_low_opacity));
        textView.setPadding(5, 5, 5, 5);

        textView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        Bitmap bitmap = Bitmap.createBitmap(textView.getMeasuredWidth(), textView.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        textView.layout(0, 0, textView.getMeasuredWidth(), textView.getMeasuredHeight());
        textView.draw(canvas);

        return bitmap;
    }

    private double distanceBetween(LatLng point1, LatLng point2) {
        float[] results = new float[1];
        Location.distanceBetween(
                point1.latitude, point1.longitude,
                point2.latitude, point2.longitude,
                results);
        return results[0] / 1000;
    }

    private void calculateDistance() {
        if (marker_point_list.size() < 2) {
            txt_distance.setText("Distance: 0 km");
            return;
        }

        double totalDistance = 0;
        for (int i = 0; i < marker_point_list.size() - 1; i++) {
            totalDistance += distanceBetween(marker_point_list.get(i), marker_point_list.get(i + 1));
        }

        String selectedUnit = sp_permeter_unit.getSelectedItem().toString();
        String formattedDistance = formatDistance(totalDistance, selectedUnit);

        txt_distance.setText("Distance: " + formattedDistance);
    }


    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}