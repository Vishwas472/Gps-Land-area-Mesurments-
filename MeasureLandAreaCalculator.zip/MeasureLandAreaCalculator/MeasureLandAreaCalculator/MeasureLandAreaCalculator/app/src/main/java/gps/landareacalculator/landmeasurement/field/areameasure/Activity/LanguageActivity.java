package gps.landareacalculator.landmeasurement.field.areameasure.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import gps.landareacalculator.landmeasurement.field.areameasure.Adpter.LangugesAdapter;
import gps.landareacalculator.landmeasurement.field.areameasure.HomeActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.Modelclass.LanguageListModal;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.BaseActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.R;


public class LanguageActivity extends BaseActivity {
    private Toolbar toolbar;
    private SharedPreferences preferences;
    private String str_current_languge;
    private RelativeLayout rel_ok;
    private ArrayList<LanguageListModal> languge_list;
    private LangugesAdapter languageListAdapter;
    private RecyclerView rcv_languge_list;
    private static final String PREFS_NAME = "LanguagePrefs";
    private static final String KEY_LANGUAGE = "selected_language";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_langugue_actvity);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        str_current_languge = preferences.getString(KEY_LANGUAGE, "en");

        rcv_languge_list = findViewById(R.id.rcv_languges);
        rel_ok = findViewById(R.id.rel_ok);
        addLanguage();

        rel_ok.setOnClickListener(v -> {
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString(KEY_LANGUAGE, languageListAdapter.getSelectedLanguageCode());
            editor.apply();

            Intent refresh = new Intent(LanguageActivity.this, HomeActivity.class);
            refresh.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(refresh);
            finish();
        });
    }



    public void addLanguage() {
        languge_list = new ArrayList<>();
        languge_list.clear();

        languge_list.add(new LanguageListModal(R.drawable.img_english, "English", "en"));
        languge_list.add(new LanguageListModal(R.drawable.img_hindi, "HINDI", "hi"));
        languge_list.add(new LanguageListModal(R.drawable.img_arabic, "ARABIC", "ar"));
        languge_list.add(new LanguageListModal(R.drawable.img_brazil, "PORTUGUESE(BRAZIL)", "pt"));
        languge_list.add(new LanguageListModal(R.drawable.img_indonsia, "INDONESIAN", "in"));
        languge_list.add(new LanguageListModal(R.drawable.img_spanish, "SPANISH", "es"));
        languge_list.add(new LanguageListModal(R.drawable.img_french, "FRENCH", "fr"));
        languge_list.add(new LanguageListModal(R.drawable.img_korean, "KOREAN", "ko"));
        languge_list.add(new LanguageListModal(R.drawable.img_japnese, "JAPANESE", "ja"));
        languge_list.add(new LanguageListModal(R.drawable.img_mandarin_chinese, "Mandarin Chinese", "zh"));
        languge_list.add(new LanguageListModal(R.drawable.img_thai, "THAI", "th"));
        languge_list.add(new LanguageListModal(R.drawable.img_turkish, "Turkish", "tr"));
        languge_list.add(new LanguageListModal(R.drawable.img_filipino, "Filipino", "fil"));
        languge_list.add(new LanguageListModal(R.drawable.img_malay, "Malay", "ms"));

        languageListAdapter = new LangugesAdapter(LanguageActivity.this, languge_list, str_current_languge);
        rcv_languge_list.setLayoutManager(new LinearLayoutManager(LanguageActivity.this));
        rcv_languge_list.setAdapter(languageListAdapter);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

}