package gps.landareacalculator.landmeasurement.field.areameasure.Adpter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import gps.landareacalculator.landmeasurement.field.areameasure.Modelclass.MesurmentModel;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class KmlFileReaderAdpter extends RecyclerView.Adapter<KmlFileReaderAdpter.ViewHolder> {
    private List<MesurmentModel> snap_shot_list;
    private List<MesurmentModel> selcted_place_mark_list = new ArrayList<>();

    public KmlFileReaderAdpter(List<MesurmentModel> snap_shot_list) {
        this.snap_shot_list = snap_shot_list;

    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.kml_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        MesurmentModel snapshot = snap_shot_list.get(position);
        holder.image_mapes.setImageBitmap(snapshot.getBitmap());
        holder.txt_name.setText(snapshot.getName());
        holder.txt_cordinates.setText(snapshot.getDistanceType());
        holder.txt_type.setText(snapshot.getMarkerPoints());
        String Type = holder.txt_type.getText().toString();
        if (Type == "LineString") {
            holder.txt_mesurement.setText(String.format("Distance : %.2f  ", snapshot.getArea()));
        } else if (Type == "Polygon") {
            holder.txt_mesurement.setText(String.format("Area: %.2f  ", snapshot.getArea()));
        } else {
            holder.txt_mesurement.setVisibility(View.GONE);
        }

        holder.Check_selcation.setOnCheckedChangeListener(null);
        holder.Check_selcation.setChecked(selcted_place_mark_list.contains(snapshot));

        holder.Check_selcation.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                selcted_place_mark_list.add(snapshot);
            } else {
                selcted_place_mark_list.remove(snapshot);
            }
        });


    }


    public List<MesurmentModel> getSelectedPlacemarks() {
        return selcted_place_mark_list;
    }

    @Override
    public int getItemCount() {
        return snap_shot_list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView image_mapes;
        TextView txt_name, txt_mesurement, txt_cordinates, txt_type;
        AppCompatCheckBox Check_selcation;

        public ViewHolder(View itemView) {
            super(itemView);
            image_mapes = itemView.findViewById(R.id.image_mapes);
            txt_name = itemView.findViewById(R.id.txt_name);
            txt_mesurement = itemView.findViewById(R.id.txt_mesurement);
            Check_selcation = itemView.findViewById(R.id.Check_selcation);
            txt_cordinates = itemView.findViewById(R.id.txt_cordinates);
            txt_type = itemView.findViewById(R.id.txt_type);

        }
    }
}
