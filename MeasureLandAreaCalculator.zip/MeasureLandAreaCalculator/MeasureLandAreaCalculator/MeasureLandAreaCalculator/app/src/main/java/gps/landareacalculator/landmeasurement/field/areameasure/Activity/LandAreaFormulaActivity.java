package gps.landareacalculator.landmeasurement.field.areameasure.Activity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;

import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.AppCompany_const;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.PrefManager;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.BaseActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class LandAreaFormulaActivity extends BaseActivity {
    CardView card_shape_area, card_custom_shape;
    ImageView img_back ;
    Toolbar toolbar;

    PrefManager prefManager;
    RelativeLayout layout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_land_area_formula);


        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        prefManager = new PrefManager(LandAreaFormulaActivity.this);
        layout = (RelativeLayout) findViewById(R.id.adView);
        if (!prefManager.getvalue()) {
            if (AppCompany_const.isActive_adMob) {
                com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(this);
                adView.setAdSize(AdSize.MEDIUM_RECTANGLE);
                adView.setAdUnitId(AppCompany_const.RECTANGLE_BANNER_AD_PUB_ID);
                layout.addView(adView);
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);

            }
        }


        card_custom_shape = findViewById(R.id.card_custom_shape);
        card_shape_area = findViewById(R.id.card_shape_area);
        img_back = findViewById(R.id.img_back);


        card_custom_shape.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LandAreaFormulaActivity.this, CustomShapeAreaCalculationActivity.class);
                startActivity(intent);
            }
        });
        card_shape_area.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LandAreaFormulaActivity.this, ShapeAreaActivity.class);
                startActivity(intent);
            }
        });

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

}