package gps.landareacalculator.landmeasurement.field.areameasure.Activity;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.BaseActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.DatabaseHelper;
import gps.landareacalculator.landmeasurement.field.areameasure.Modelclass.MesurmentModel;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class SavedDataupdateActivity extends BaseActivity implements OnMapReadyCallback {
    private GoogleMap map;
    private DatabaseHelper dbHelper;
    Toolbar toolbar;
    TextView txt_name;
    CardView card_edit;
    RelativeLayout rel_save;
    private ImageView img_zoom_in,
            img_zoom_out,
            img_back;
    private LatLng currentMarkerPosition;
    private Marker currentMarker;
    private boolean isEditable = false;
    int color;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_dataupdate);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        txt_name = findViewById(R.id.txt_name);
        card_edit = findViewById(R.id.card_edit);
        rel_save = findViewById(R.id.rel_save);
        img_zoom_in = findViewById(R.id.img_zoom_in);
        img_zoom_out = findViewById(R.id.img_zoom_out);
        img_back = findViewById(R.id.img_back);

        dbHelper = new DatabaseHelper(this);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        String name = getIntent().getStringExtra("name");
        txt_name.setText(name);

        card_edit.setOnClickListener(v -> {
            isEditable = !isEditable;
            if (currentMarker != null) {
                currentMarker.setDraggable(isEditable);

            }

            if (isEditable) {
                card_edit.setVisibility(View.GONE);
            } else {
                card_edit.setVisibility(View.VISIBLE);
            }
            Toast.makeText(this, isEditable ? "Edit mode enabled" : "Edit mode disabled", Toast.LENGTH_SHORT).show();
        });

        rel_save.setOnClickListener(v -> saveData());

        img_zoom_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (map != null) {
                    map.animateCamera(CameraUpdateFactory.zoomIn());
                }
            }
        });


        img_zoom_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (map != null) {
                    map.animateCamera(CameraUpdateFactory.zoomOut());
                }
            }
        });

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    @Override
    public void onMapReady(GoogleMap map) {
        this.map = map;
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(0, 0), 0));
        map.setOnMapClickListener(latLng -> {
            if (isEditable) {
                if (currentMarker != null) {
                    currentMarker.remove();
                }
                currentMarker = map.addMarker(new MarkerOptions()
                        .position(latLng)
                        .title("Selected Point")
                        .draggable(isEditable)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));
                currentMarkerPosition = latLng;
            }
        });

        map.setOnMarkerDragListener(new GoogleMap.OnMarkerDragListener() {
            @SuppressLint("PotentialBehaviorOverride")
            @Override
            public void onMarkerDragStart(Marker marker) {
            }

            @Override
            public void onMarkerDrag(Marker marker) {
            }

            @Override
            public void onMarkerDragEnd(Marker marker) {
                currentMarkerPosition = marker.getPosition();
            }
        });

        loadSavedData();
    }

    private void loadSavedData() {
        String name = getIntent().getStringExtra("name");
        List<MesurmentModel> measurementList = dbHelper.getPolygonDataByName(name);

        if (measurementList != null && !measurementList.isEmpty()) {
            MesurmentModel measurement = measurementList.get(0);

            String markerPointsJson = measurement.getMarkerPoints();

            if (markerPointsJson != null && !markerPointsJson.isEmpty()) {
                List<LatLng> markerPoints = convertJsonToLatLngList(markerPointsJson);

                if (!markerPoints.isEmpty()) {
                    LatLng latLng = markerPoints.get(0);
                    currentMarkerPosition = latLng;
                    currentMarker = map.addMarker(new MarkerOptions()
                            .position(latLng)
                            .title("Saved Point")
                            .draggable(isEditable)
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));
                    map.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 10));
                }
            }
        }
    }


    private List<LatLng> convertJsonToLatLngList(String json) {
        List<LatLng> latLngList = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(json);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                double lat = obj.getDouble("latitude");
                double lng = obj.getDouble("longitude");
                latLngList.add(new LatLng(lat, lng));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return latLngList;
    }

    private void saveData() {
        if (currentMarkerPosition == null) {
            Toast.makeText(this, "No marker selected!", Toast.LENGTH_SHORT).show();
            return;
        }

        String name = txt_name.getText().toString();
        String pointsJson = convertPointsToJson(Collections.singletonList(currentMarkerPosition));


        dbHelper.updatePolygonData(name, 0.0, pointsJson, "", "", "", "", "", "", color);


        map.snapshot(bitmap -> {
            if (bitmap != null) {

                String encodedImage = saveBitmapToFile(bitmap);


                dbHelper.updatePolygonData(name, 0.0, pointsJson, "", "", "", "", "", encodedImage, color);


                Toast.makeText(SavedDataupdateActivity.this, "saved successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(SavedDataupdateActivity.this, "Failed to capture screenshot", Toast.LENGTH_SHORT).show();
            }
        });
        Toast.makeText(this, "updated successfully!", Toast.LENGTH_SHORT).show();
        finish();
    }

    private String saveBitmapToFile(Bitmap bitmap) {
        File directory = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "PolygonImages");
        if (!directory.exists()) {
            directory.mkdirs();
        }

        String fileName = "polygon_" + System.currentTimeMillis() + ".png";
        File imageFile = new File(directory, fileName);

        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

        return imageFile.getAbsolutePath();
    }

    private String convertPointsToJson(List<LatLng> points) {
        try {
            JSONArray pointsArray = new JSONArray();
            for (LatLng latLng : points) {
                JSONObject point = new JSONObject();
                point.put("latitude", latLng.latitude);
                point.put("longitude", latLng.longitude);
                pointsArray.put(point);
            }
            return pointsArray.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            return "";
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}