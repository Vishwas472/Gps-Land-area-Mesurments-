package gps.landareacalculator.landmeasurement.field.areameasure.OtherClass;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import gps.landareacalculator.landmeasurement.field.areameasure.Modelclass.MesurmentModel;

public class KMLParser {
    public static List<MesurmentModel> parseKML(InputStream inputStream) {
        List<MesurmentModel> placemarks = new ArrayList<>();
        try {

            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = factory.newPullParser();
            parser.setInput(inputStream, null);

            String tagName = null;
            String name = null;
            String coordinates = null;
            String geometryType = null;

            int eventType = parser.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        tagName = parser.getName();
                        if ("name".equals(tagName)) {
                            name = parser.nextText();
                        }else if ("coordinates".equals(tagName)) {
                            coordinates = parser.nextText();
                        }  else if ("Point".equals(tagName)) {
                            geometryType = "Point";
                        } else if ("LineString".equals(tagName)) {
                            geometryType = "LineString";
                        } else if ("Polygon".equals(tagName)) {
                            geometryType = "Polygon";
                        }
                        break;

                    case XmlPullParser.END_TAG:
                        if ("Placemark".equals(parser.getName()) && name != null && coordinates != null) {

                            if (geometryType != null) {
                                placemarks.add(new MesurmentModel(name, coordinates, geometryType));
                            }

                            name = null;
                            coordinates = null;
                            geometryType = null;
                        }
                        break;
                }
                eventType = parser.next();
            }

            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return placemarks;
    }

}