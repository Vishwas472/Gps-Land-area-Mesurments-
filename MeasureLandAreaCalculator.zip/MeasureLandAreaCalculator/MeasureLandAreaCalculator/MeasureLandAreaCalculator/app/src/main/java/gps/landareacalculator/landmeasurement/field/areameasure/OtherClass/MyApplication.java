package gps.landareacalculator.landmeasurement.field.areameasure.OtherClass;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Handler;

import androidx.multidex.MultiDex;
import androidx.multidex.MultiDexApplication;

import com.google.firebase.FirebaseApp;

import java.util.Locale;

import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.AppOpenManager;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.PrefManager;

public class MyApplication extends MultiDexApplication {
    @Override
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(LocaleHelper.onAttach(context, Locale.getDefault().getLanguage()));
    }
    PrefManager prefManager;
    public static AppOpenManager appOpenManager;

    @Override
    public void onCreate() {
        super.onCreate();

        MultiDex.install(this);
        FirebaseApp.initializeApp(this);
        prefManager = new PrefManager(this);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                if (!prefManager.getvalue()) {
                    appOpenManager = new AppOpenManager(MyApplication.this);
                }
            }
        }, 2500);



    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }

    public static final String NIGHT_MODE = "NIGHT_MODE";
    private boolean isNightModeEnabled = false;

    private static MyApplication instance;


    public static Context getContext() {
        return instance;
    }

    public static MyApplication getInstance() {
        return instance;
    }

    public static MyApplication get(Context context) {
        return (MyApplication) context.getApplicationContext();
    }


}
