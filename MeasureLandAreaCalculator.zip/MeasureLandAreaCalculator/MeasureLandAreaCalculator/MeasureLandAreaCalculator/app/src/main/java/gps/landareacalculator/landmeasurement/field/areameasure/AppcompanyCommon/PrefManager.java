package gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon;

import android.content.Context;
import android.content.SharedPreferences;


public class PrefManager {
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;
    public static String REMOVE_ADS_PRODUCT_ID = "applandareameasure.remove.ads";
    // shared pref mode
    int PRIVATE_MODE = 0;

    // Shared preferences file name
    private static final String PREF_NAME = "appcompany_land_area";

    private static final String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";
    private static final String REMOVE_ADS = "app_remove_ads";


    SharedPreferences prefGlobal;
    SharedPreferences.Editor editorGlobal;
    Context context;

    public PrefManager(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
        prefGlobal = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editorGlobal = prefGlobal.edit();
    }

    public void setFirstTimeLaunch(boolean isFirstTime) {
        editor.putBoolean(IS_FIRST_TIME_LAUNCH, isFirstTime);
        editor.commit();
    }

    public boolean isFirstTimeLaunch() {
        return pref.getBoolean(IS_FIRST_TIME_LAUNCH, true);
    }

    public void setvalue(boolean value) {
        editor.putBoolean(REMOVE_ADS, value);
        editor.commit();
    }

    public boolean getvalue() {
        return pref.getBoolean(REMOVE_ADS, false);
    }


}
