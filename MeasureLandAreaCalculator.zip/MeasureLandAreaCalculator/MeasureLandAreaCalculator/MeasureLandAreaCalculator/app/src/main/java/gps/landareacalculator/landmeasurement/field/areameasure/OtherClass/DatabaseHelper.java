package gps.landareacalculator.landmeasurement.field.areameasure.OtherClass;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

import gps.landareacalculator.landmeasurement.field.areameasure.Modelclass.MesurmentModel;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "land_measurement.db";
    private static final int DATABASE_VERSION = 1;


    public static final String TABLE_POLYGON = "polygon";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_AREA = "area";
    private static final String COLUM_AREA_UNIT = "Area_unit";
    public static final String COLUMN_MARKER_POINTS = "Marker_points";
    public static final String COLOUM_MIDPOINTS_MARKER = "MID_Points_Marker_points";
    private static final String COLUMN_MAPTYPE = "Map_Type";
    public static final String COLUMN_PERMETER_UNITS = "permeter_Unit";
    private static final String COLUMN_DISTANCE_TYPE = "Type";
    private static final String COLUMN_IMAGE = "Images";
    public static final String COLUMN_COLOR = "color";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_POLYGON_TABLE = "CREATE TABLE " + TABLE_POLYGON + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_AREA + " REAL, " +
                COLUMN_MARKER_POINTS + " TEXT," +
                COLOUM_MIDPOINTS_MARKER + " TEXT," +
                COLUMN_MAPTYPE + " TEXT," +
                COLUM_AREA_UNIT + " TEXT, " +
                COLUMN_PERMETER_UNITS + " TEXT, " +
                COLUMN_IMAGE + " TEXT, " +
                COLUMN_COLOR + " TEXT, " +
                COLUMN_DISTANCE_TYPE + " REAL)";


        db.execSQL(CREATE_POLYGON_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_POLYGON);


            onCreate(db);
        }
    }

    public void insertPolygonData(String name, double area, String pointsJson ,String Midpoint, String timeUnit, String mapType, String Permeterunit, String Mesuretype, String mapimage,int color) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_AREA, area);
        values.put(COLUMN_MARKER_POINTS, pointsJson);
        values.put(COLOUM_MIDPOINTS_MARKER, Midpoint);
        values.put(COLUM_AREA_UNIT, timeUnit);
        values.put(COLUMN_MAPTYPE, mapType);
        values.put(COLUMN_PERMETER_UNITS, Permeterunit);
        values.put(COLUMN_DISTANCE_TYPE, Mesuretype);
        values.put(COLUMN_IMAGE, mapimage);
        values.put(COLUMN_COLOR, color);


        db.insert(TABLE_POLYGON, null, values);
        db.close();
    }


    public List<MesurmentModel> getPolygonData() {
        List<MesurmentModel> polygonDataList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT " +
                COLUMN_NAME + ", " +
                COLUMN_AREA + ", " +
                COLUMN_MARKER_POINTS + ", " +
                COLOUM_MIDPOINTS_MARKER + ", " +
                COLUM_AREA_UNIT + ", " +
                COLUMN_MAPTYPE + ", " +
                COLUMN_PERMETER_UNITS + ", " +
                COLUMN_IMAGE + ", " +
                COLUMN_DISTANCE_TYPE + ", " +
                COLUMN_COLOR +
                " FROM " + TABLE_POLYGON;
        Cursor cursor = db.rawQuery(query, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(COLUMN_NAME));
                @SuppressLint("Range") double area = cursor.getDouble(cursor.getColumnIndex(COLUMN_AREA));
                @SuppressLint("Range") String markerPoints = cursor.getString(cursor.getColumnIndex(COLUMN_MARKER_POINTS));
                @SuppressLint("Range") String midpoints = cursor.getString(cursor.getColumnIndex(COLOUM_MIDPOINTS_MARKER));
                @SuppressLint("Range") String areaUnit = cursor.getString(cursor.getColumnIndex(COLUM_AREA_UNIT));
                @SuppressLint("Range") String mapType = cursor.getString(cursor.getColumnIndex(COLUMN_MAPTYPE));
                @SuppressLint("Range") String permeterunit = cursor.getString(cursor.getColumnIndex(COLUMN_PERMETER_UNITS));
                @SuppressLint("Range") String type = cursor.getString(cursor.getColumnIndex(COLUMN_DISTANCE_TYPE));
                @SuppressLint("Range") String images = cursor.getString(cursor.getColumnIndex(COLUMN_IMAGE));
                @SuppressLint("Range") int color = cursor.getInt(cursor.getColumnIndex(COLUMN_COLOR));


                MesurmentModel polygon = new MesurmentModel(name, area, markerPoints, midpoints, areaUnit, mapType, permeterunit, type, images, color);
                polygonDataList.add(polygon);
            }
            cursor.close();
        }
        db.close();
        return polygonDataList;
    }


    public List<MesurmentModel> getPolygonDataByName(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<MesurmentModel> polygonList = new ArrayList<>();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_POLYGON + " WHERE " + COLUMN_NAME + "=?", new String[]{name});

        if (cursor != null) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") double area = cursor.getDouble(cursor.getColumnIndex(COLUMN_AREA));
                @SuppressLint("Range") String markerPoints = cursor.getString(cursor.getColumnIndex(COLUMN_MARKER_POINTS));
                @SuppressLint("Range") String midpoints = cursor.getString(cursor.getColumnIndex(COLOUM_MIDPOINTS_MARKER));
                @SuppressLint("Range") String areaUnit = cursor.getString(cursor.getColumnIndex(COLUM_AREA_UNIT));
                @SuppressLint("Range") String mapType = cursor.getString(cursor.getColumnIndex(COLUMN_MAPTYPE));
                @SuppressLint("Range") String perimeterUnit = cursor.getString(cursor.getColumnIndex(COLUMN_PERMETER_UNITS));
                @SuppressLint("Range") String type = cursor.getString(cursor.getColumnIndex(COLUMN_DISTANCE_TYPE));
                @SuppressLint("Range") String mapImage = cursor.getString(cursor.getColumnIndex(COLUMN_IMAGE));
                @SuppressLint("Range") int color = cursor.getInt(cursor.getColumnIndex(COLUMN_COLOR));


                MesurmentModel polygon = new MesurmentModel(name, area, markerPoints, midpoints, areaUnit, mapType, perimeterUnit, type, mapImage,color);
                polygonList.add(polygon);
            }
            cursor.close();
        }
        db.close();
        return polygonList;
    }


    public void updatePolygonData(String name, double area, String pointsJson, String midpoints, String areaUnit, String mapType, String perimeterUnit, String measureType, String mapImage,int color) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_AREA, area);
        values.put(COLUMN_MARKER_POINTS, pointsJson);
        values.put(COLOUM_MIDPOINTS_MARKER, midpoints);
        values.put(COLUM_AREA_UNIT, areaUnit);
        values.put(COLUMN_MAPTYPE, mapType);
        values.put(COLUMN_PERMETER_UNITS, perimeterUnit);
        values.put(COLUMN_DISTANCE_TYPE, measureType);
        values.put(COLUMN_IMAGE, mapImage);
        values.put(COLUMN_COLOR, color);

        int rowsAffected = db.update(TABLE_POLYGON, values, COLUMN_NAME + " = ?", new String[]{name});
        db.close();
    }


    public boolean deletePolygonByName(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean isDeleted = db.delete(TABLE_POLYGON, COLUMN_NAME + " = ?", new String[]{name}) > 0;
        db.close();
        return isDeleted;
    }
}
