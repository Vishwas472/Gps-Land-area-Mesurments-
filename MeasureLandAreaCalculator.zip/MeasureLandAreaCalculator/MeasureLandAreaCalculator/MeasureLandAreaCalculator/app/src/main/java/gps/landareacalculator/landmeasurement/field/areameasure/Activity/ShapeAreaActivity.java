package gps.landareacalculator.landmeasurement.field.areameasure.Activity;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;

import java.util.ArrayList;
import java.util.List;

import gps.landareacalculator.landmeasurement.field.areameasure.Adpter.ShapeAreaAdpter;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.AppCompany_const;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.PrefManager;
import gps.landareacalculator.landmeasurement.field.areameasure.Modelclass.ShapeAreaModel;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.BaseActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class ShapeAreaActivity extends BaseActivity {

    private RecyclerView rcv_shape_area;
    private ShapeAreaAdpter adpter_shape;
    private List<ShapeAreaModel> shapeList;
    ImageView img_back ;
    Toolbar toolbar;

    PrefManager prefManager;
    RelativeLayout layout;

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shape_area);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        prefManager = new PrefManager(ShapeAreaActivity.this);
        layout = (RelativeLayout) findViewById(R.id.adView);
        if (!prefManager.getvalue()) {
            if (AppCompany_const.isActive_adMob) {
                com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(this);
                adView.setAdSize(getAdSize());
                adView.setAdUnitId(AppCompany_const.BANNER_AD_PUB_ID);
                layout.addView(adView);
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);

            }
        }

        rcv_shape_area = findViewById(R.id.rcv_shape_area);
        img_back = findViewById(R.id.img_back);


        rcv_shape_area.setLayoutManager(new LinearLayoutManager(this));

        shapeList = new ArrayList<>();
        shapeList.add(new ShapeAreaModel("Square",getString(R.string.square), "Area = side²", "Perimeter = 4 × side",R.drawable.ic_square));
        shapeList.add(new ShapeAreaModel("Rectangle",getString(R.string.rectangle), "Area = length × width", "Perimeter = 2 × (length + width)",R.drawable.ic_rectangle__1_));
        shapeList.add(new ShapeAreaModel("Triangle",getString(R.string.triangle), "Area = ½ × base × height", "Perimeter = a + b + c",R.drawable.ic_triangle));
        shapeList.add(new ShapeAreaModel("Circle",getString(R.string.circle), "Area = π × radius²", "Circumference = 2π × radius",R.drawable.ic_circle));
        shapeList.add(new ShapeAreaModel("Ellipse",getString(R.string.ellipse), "Area = π × a × b", "Perimeter ≈ π × [3(a + b) - sqrt((3a + b) × (a + 3b))]",R.drawable.ic_ellipses));
        shapeList.add(new ShapeAreaModel("Parallelogram",getString(R.string.parallelogram), "Area = base × height", "Perimeter = 2 × (base + side)",R.drawable.ic_parallelogtam));
        shapeList.add(new ShapeAreaModel("Circular Sector",getString(R.string.circular_sector), "Area = ½ × r² × θ", "Arc Length = r × θ",R.drawable.ic_circular_sector));
        shapeList.add(new ShapeAreaModel("Quadrilateral",getString(R.string.quadrilateral), "Area = base × height", "Perimeter = sum of all sides",R.drawable.ic_quadrilateral));
        shapeList.add(new ShapeAreaModel("Polygon",getString(R.string.polygon), "Area = (n × s²) / (4 × tan(π/n))", "Perimeter = n × side",R.drawable.ic_polygon));
        shapeList.add(new ShapeAreaModel("Trapezoid",getString(R.string.trapezoid), "Area = ½ × (a + b) × h", "Perimeter = a + b + c + d",R.drawable.ic_trapezoid));
        shapeList.add(new ShapeAreaModel("Rhombus",getString(R.string.rhombus), "Area = (d1 × d2) / 2", "Perimeter = 4 × side",R.drawable.ic_rhombus));


        adpter_shape = new ShapeAreaAdpter(shapeList, this);
        rcv_shape_area.setAdapter(adpter_shape);

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}