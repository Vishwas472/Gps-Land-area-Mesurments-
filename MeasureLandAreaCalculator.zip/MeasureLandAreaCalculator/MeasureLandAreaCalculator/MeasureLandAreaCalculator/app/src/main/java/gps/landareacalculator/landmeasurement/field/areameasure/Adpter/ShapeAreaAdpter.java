package gps.landareacalculator.landmeasurement.field.areameasure.Adpter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import gps.landareacalculator.landmeasurement.field.areameasure.Activity.ShapeAreaCalculationActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.Modelclass.ShapeAreaModel;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class ShapeAreaAdpter extends RecyclerView.Adapter<ShapeAreaAdpter.ViewHolder> {
    private List<ShapeAreaModel> Shape_area_list;
    private Context context;

    public ShapeAreaAdpter(List<ShapeAreaModel> Shape_area_list, Context context) {
        this.Shape_area_list = Shape_area_list;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_shape_area, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ShapeAreaModel shape = Shape_area_list.get(position);
        holder.txt_shape_name.setText(shape.getShapeName());
        holder.image_mapes.setImageResource(shape.getImageShape());
        holder.rel_calculate.setOnClickListener(v -> {
            Intent intent = new Intent(context, ShapeAreaCalculationActivity.class);
            intent.putExtra("shapeName", shape.getShapeName());
            intent.putExtra("shape", shape.getShapeId());
            intent.putExtra("shapeFormula", shape.getShapeFormula());
            intent.putExtra("shapePermeterForumla", shape.getShapemeterlegnth());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return Shape_area_list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_shape_name;
        ImageView image_mapes;
        RelativeLayout rel_calculate ;

        public ViewHolder(View itemView) {
            super(itemView);
            txt_shape_name = itemView.findViewById(R.id.txt_shape_name);
            image_mapes = itemView.findViewById(R.id.image_mapes);
            rel_calculate = itemView.findViewById(R.id.rel_Calculate);
        }
    }
}
