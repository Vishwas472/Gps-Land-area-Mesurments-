package gps.landareacalculator.landmeasurement.field.areameasure.Modelclass;

public class ShapeAreaModel {
    private String shapeId;
    private String shapeName;
    private String shapeFormula;
    private String Shapemeterlegnth;
    int ImageShape ;



    public ShapeAreaModel(String shapeId,String shapeName, String shapeFormula, String Shapemeterlegnth, int ImageShape) {
        this.shapeId = shapeId;
        this.shapeName = shapeName;
        this.shapeFormula = shapeFormula;
        this.Shapemeterlegnth = Shapemeterlegnth;
        this.ImageShape = ImageShape;
    }

    public String getShapeId() {
        return shapeId;
    }

    public String getShapemeterlegnth() {
        return Shapemeterlegnth;
    }

    public String getShapeName() {
        return shapeName;
    }

    public String getShapeFormula() {
        return shapeFormula;
    }

    public int getImageShape() {
        return ImageShape;
    }

}
