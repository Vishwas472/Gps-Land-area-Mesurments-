package gps.landareacalculator.landmeasurement.field.areameasure.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.BaseActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class ShapeAreaCalculationActivity extends BaseActivity {
    Toolbar toolbar;
    private TextView txt_shape_name, txt_area_formula, txt_permeter_formula, txt_area, txt_permeter;
    private EditText edt_squre_side, edt_rectangle_side_a, edt_rectangle_side_b, edt_Trigle_side_a, edt_Trigle_side_b, edt_Trigle_side_c, edt_circle_radius, edt_elips_Axis_major, edt_elips_Axis_miner, edt_Parallelogram_a, edt_Parallelogram_b, edt_Parallelogram_angle, edt_circular_radius, edt_Circular_anagle, edt_Quadrilateral_a, edt_Quadrilateral_b, edt_Quadrilateral_c, edt_Quadrilateral_d, edt_polygon_number_Sides, edt_polygon_side_legnth, edt_Trapezoid_base_1, edt_Trapezoid_base_2, edt_Trapezoid_hegiht, edt_Trapezoid_side_legnth_1, edt_Trapezoid_side_legnth_2, edt_Rhombus_diagonal_1, edt_Rhombus_diagonal_2, edt_Rhombus_side_legnth;
    RelativeLayout rel_Calculate,rel_squre, rel_rectagle, rel_Trigle, rel_Circle, rel_elipse, rel_Parallelogram, rel_Circular_Sectore, rel_Quadrilateral, rel_polygon, rel_Trapezoid, rel_Rhombus;
    ImageView img_back ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shape_area_calculation);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        txt_shape_name = findViewById(R.id.txt_shape_name);
        txt_permeter_formula = findViewById(R.id.txt_permeter_formula);
        txt_area_formula = findViewById(R.id.txt_area_formula);
        edt_squre_side = findViewById(R.id.edt_squre_side);
        rel_squre = findViewById(R.id.rel_squre);
        edt_rectangle_side_a = findViewById(R.id.edt_rectangle_side_a);
        edt_rectangle_side_b = findViewById(R.id.edt_rectangle_side_b);
        rel_rectagle = findViewById(R.id.rel_rectagle);
        edt_Trigle_side_a = findViewById(R.id.edt_Trigle_side_a);
        edt_Trigle_side_b = findViewById(R.id.edt_Trigle_side_b);
        edt_Trigle_side_c = findViewById(R.id.edt_Trigle_side_c);
        rel_Trigle = findViewById(R.id.rel_Trigle);
        edt_circle_radius = findViewById(R.id.edt_circle_radius);
        rel_Circle = findViewById(R.id.rel_Circle);
        edt_elips_Axis_major = findViewById(R.id.edt_elips_Axis_major);
        edt_elips_Axis_miner = findViewById(R.id.edt_elips_Axis_miner);
        rel_elipse = findViewById(R.id.rel_elipse);
        edt_Parallelogram_a = findViewById(R.id.edt_Parallelogram_a);
        edt_Parallelogram_b = findViewById(R.id.edt_Parallelogram_b);
        edt_Parallelogram_angle = findViewById(R.id.edt_Parallelogram_angle);
        rel_Parallelogram = findViewById(R.id.rel_Parallelogram);
        edt_Circular_anagle = findViewById(R.id.edt_Circular_anagle);
        edt_circular_radius = findViewById(R.id.edt_circular_radius);
        rel_Circular_Sectore = findViewById(R.id.rel_Circular_Sectore);
        edt_Quadrilateral_a = findViewById(R.id.edt_Quadrilateral_a);
        edt_Quadrilateral_b = findViewById(R.id.edt_Quadrilateral_b);
        edt_Quadrilateral_c = findViewById(R.id.edt_Quadrilateral_c);
        edt_Quadrilateral_d = findViewById(R.id.edt_Quadrilateral_d);
        rel_Quadrilateral = findViewById(R.id.rel_Quadrilateral);
        edt_polygon_number_Sides = findViewById(R.id.edt_polygon_number_Sides);
        edt_polygon_side_legnth = findViewById(R.id.edt_polygon_side_legnth);
        rel_polygon = findViewById(R.id.rel_polygon);
        edt_Trapezoid_base_1 = findViewById(R.id.edt_Trapezoid_base_1);
        edt_Trapezoid_base_2 = findViewById(R.id.edt_Trapezoid_base_2);
        edt_Trapezoid_hegiht = findViewById(R.id.edt_Trapezoid_hegiht);
        edt_Trapezoid_side_legnth_1 = findViewById(R.id.edt_Trapezoid_side_legnth_1);
        edt_Trapezoid_side_legnth_2 = findViewById(R.id.edt_Trapezoid_side_legnth_2);
        rel_Trapezoid = findViewById(R.id.rel_Trapezoid);
        edt_Rhombus_diagonal_1 = findViewById(R.id.edt_Rhombus_diagonal_1);
        edt_Rhombus_diagonal_2 = findViewById(R.id.edt_Rhombus_diagonal_2);
        edt_Rhombus_side_legnth = findViewById(R.id.edt_Rhombus_side_legnth);
        rel_Rhombus = findViewById(R.id.rel_Rhombus);
        rel_Calculate = findViewById(R.id.rel_Calculate);
        txt_area = findViewById(R.id.txt_area);
        txt_permeter = findViewById(R.id.txt_permeter);
        img_back = findViewById(R.id.img_back);

        String shapeName = getIntent().getStringExtra("shapeName");
        String shape = getIntent().getStringExtra("shape");
        String shapeFormula = getIntent().getStringExtra("shapeFormula");
        String shapepermeterFormula = getIntent().getStringExtra("shapePermeterForumla");

        txt_shape_name.setText(shapeName);
        txt_area_formula.setText(shapeFormula);
        txt_permeter_formula.setText(shapepermeterFormula);

        if (shape != null) {
            switch (shape) {
                case "Square":
                    rel_squre.setVisibility(View.VISIBLE);
                    break;

                case "Rectangle":
                    rel_rectagle.setVisibility(View.VISIBLE);
                    break;

                case "Triangle":
                    rel_Trigle.setVisibility(View.VISIBLE);
                    break;

                case "Circle":
                    rel_Circle.setVisibility(View.VISIBLE);
                    break;

                case "Ellipse":
                    rel_elipse.setVisibility(View.VISIBLE);
                    break;

                case "Parallelogram":
                    rel_Parallelogram.setVisibility(View.VISIBLE);
                    break;
                case "Circular Sector":
                    rel_Circular_Sectore.setVisibility(View.VISIBLE);
                    break;
                case "Quadrilateral":
                    rel_Quadrilateral.setVisibility(View.VISIBLE);
                    break;
                case "Polygon":
                    rel_polygon.setVisibility(View.VISIBLE);
                    break;
                case "Trapezoid":
                    rel_Trapezoid.setVisibility(View.VISIBLE);
                    break;

                case "Rhombus":
                    rel_Rhombus.setVisibility(View.VISIBLE);

                    break;

                default:
                    break;
            }
        }

        rel_Calculate.setOnClickListener(v -> {
            if (shape != null) {
                switch (shape) {
                    case "Square":
                        calculateSquare();
                        break;
                    case "Rectangle":
                        calculateRectangle();
                        break;
                    case "Triangle":
                        calculateTriangle();
                        break;

                    case "Circle":
                        calculateCircle();
                        break;

                    case "Ellipse":
                        calculateEllipse();
                        break;

                    case "Parallelogram":
                        calculateParallelogram();
                        break;

                    case "Circular Sector":
                        calculateCircularSector();
                        break;

                    case "Quadrilateral":
                        calculateQuadrilateral();
                        break;


                    case "Polygon":
                        calculatePolygon();
                        break;

                    case "Trapezoid":
                        calculateTrapezoid();
                        break;

                    case "Rhombus":
                        calculateRhombus();
                        break;

                    default:
                        break;
                }
            }
        });

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    private void calculateTrapezoid() {
        String base1Str = edt_Trapezoid_base_1.getText().toString();
        String base2Str = edt_Trapezoid_base_2.getText().toString();
        String side1Str = edt_Trapezoid_side_legnth_1.getText().toString();
        String side2Str = edt_Trapezoid_side_legnth_2.getText().toString();
        String heightStr = edt_Trapezoid_hegiht.getText().toString();

        if (!base1Str.isEmpty() && !base2Str.isEmpty() && !side1Str.isEmpty() &&
                !side2Str.isEmpty() && !heightStr.isEmpty()) {

            double base1 = Double.parseDouble(base1Str);
            double base2 = Double.parseDouble(base2Str);
            double side1 = Double.parseDouble(side1Str);
            double side2 = Double.parseDouble(side2Str);
            double height = Double.parseDouble(heightStr);

            if (base1 <= 0 || base2 <= 0 || side1 <= 0 || side2 <= 0 || height <= 0) {
                Toast.makeText(this, "All values must be greater than zero!", Toast.LENGTH_SHORT).show();
                return;
            }

            double perimeter = base1 + base2 + side1 + side2;
            double area = 0.5 * (base1 + base2) * height;

            txt_permeter.setText("Perimeter: " + perimeter);
            txt_area.setText("Area: " + String.format("%.2f", area));

        } else {
            Toast.makeText(this, "Please enter all values!", Toast.LENGTH_SHORT).show();
        }
    }

    private void calculateRhombus() {
        String diagonal1Value = edt_Rhombus_diagonal_1.getText().toString();
        String diagonal2Value = edt_Rhombus_diagonal_2.getText().toString();
        String sideValue = edt_Rhombus_side_legnth.getText().toString();

        if (!diagonal1Value.isEmpty() && !diagonal2Value.isEmpty() && !sideValue.isEmpty()) {
            double diagonal1 = Double.parseDouble(diagonal1Value);
            double diagonal2 = Double.parseDouble(diagonal2Value);
            double side = Double.parseDouble(sideValue);

            double area = (diagonal1 * diagonal2) / 2;

            double perimeter = 4 * side;

            txt_area.setText("Area: " + area);
            txt_permeter.setText("Perimeter: " + perimeter);
        } else {
            Toast.makeText(this, "Please enter all values", Toast.LENGTH_SHORT).show();
        }
    }

    private void calculatePolygon() {
        String sidesCountStr = edt_polygon_number_Sides.getText().toString();
        String sideLengthStr = edt_polygon_side_legnth.getText().toString();

        if (!sidesCountStr.isEmpty() && !sideLengthStr.isEmpty()) {
            int sides = Integer.parseInt(sidesCountStr);
            double sideLength = Double.parseDouble(sideLengthStr);

            if (sides < 3) {
                Toast.makeText(this, "Polygon must have at least 3 sides!", Toast.LENGTH_SHORT).show();
                return;
            }


            double perimeter = sides * sideLength;

            double area = (sides * Math.pow(sideLength, 2)) / (4 * Math.tan(Math.PI / sides));

            txt_permeter.setText("Perimeter: " + perimeter);
            txt_area.setText("Area: " + String.format("%.2f", area));
        } else {
            Toast.makeText(this, "Please enter all values!", Toast.LENGTH_SHORT).show();
        }
    }

    private void calculateSquare() {
        String sideValue = edt_squre_side.getText().toString();
        if (!sideValue.isEmpty()) {
            double side = Double.parseDouble(sideValue);


            double area = side * side;

            double perimeter = 4 * side;


            txt_area.setText("Area: " + area);
            txt_permeter.setText("Perimeter: " + perimeter);
        } else {
            Toast.makeText(this, "Please enter the side length", Toast.LENGTH_SHORT).show();
        }

    }

    private void calculateRectangle() {
        String sideAValue = edt_rectangle_side_a.getText().toString();
        String sideBValue = edt_rectangle_side_b.getText().toString();

        if (!sideAValue.isEmpty() && !sideBValue.isEmpty()) {
            double sideA = Double.parseDouble(sideAValue);
            double sideB = Double.parseDouble(sideBValue);


            double area = sideA * sideB;

            double perimeter = 2 * (sideA + sideB);

            txt_area.setText("Area: " + area);
            txt_permeter.setText("Perimeter: " + perimeter);
        } else {
            Toast.makeText(this, "Please enter both side values", Toast.LENGTH_SHORT).show();
        }
    }

    private void calculateTriangle() {
        String sideAValue = edt_Trigle_side_a.getText().toString();
        String sideBValue = edt_Trigle_side_b.getText().toString();
        String sideCValue = edt_Trigle_side_c.getText().toString();

        if (!sideAValue.isEmpty() && !sideBValue.isEmpty() && !sideCValue.isEmpty()) {
            double sideA = Double.parseDouble(sideAValue);
            double sideB = Double.parseDouble(sideBValue);
            double sideC = Double.parseDouble(sideCValue);


            double perimeter = sideA + sideB + sideC;

            double s = perimeter / 2;
            double area = Math.sqrt(s * (s - sideA) * (s - sideB) * (s - sideC));

            txt_area.setText("Area: " + area);
            txt_permeter.setText("Perimeter: " + perimeter);
        } else {
            Toast.makeText(this, "Please enter the values for all sides", Toast.LENGTH_SHORT).show();
        }
    }

    private void calculateCircle() {
        String radiusValue = edt_circle_radius.getText().toString();
        if (!radiusValue.isEmpty()) {
            double radius = Double.parseDouble(radiusValue);
            double area = Math.PI * radius * radius;
            double perimeter = 2 * Math.PI * radius;
            txt_area.setText("Area: " + area);
            txt_permeter.setText("Perimeter: " + perimeter);
        } else {
            Toast.makeText(this, "Please enter the radius", Toast.LENGTH_SHORT).show();
        }
    }

    private void calculateEllipse() {
        String majorAxisValue = edt_elips_Axis_major.getText().toString();
        String minorAxisValue = edt_elips_Axis_miner.getText().toString();

        if (!majorAxisValue.isEmpty() && !minorAxisValue.isEmpty()) {
            double a = Double.parseDouble(majorAxisValue);
            double b = Double.parseDouble(minorAxisValue);


            double area = Math.PI * a * b;


            double perimeter = Math.PI * (3 * (a + b) - Math.sqrt((3 * a + b) * (a + 3 * b)));

            txt_area.setText("Area: " + area);
            txt_permeter.setText("Perimeter: " + perimeter);
        } else {
            Toast.makeText(this, "Please enter both major and minor axis values", Toast.LENGTH_SHORT).show();
        }
    }

    private void calculateParallelogram() {
        String sideAValue = edt_Parallelogram_a.getText().toString();
        String sideBValue = edt_Parallelogram_b.getText().toString();
        String angleValue = edt_Parallelogram_angle.getText().toString();

        if (!sideAValue.isEmpty() && !sideBValue.isEmpty() && !angleValue.isEmpty()) {
            double sideA = Double.parseDouble(sideAValue);
            double sideB = Double.parseDouble(sideBValue);
            double angleInDegrees = Double.parseDouble(angleValue);
            double angleInRadians = Math.toRadians(angleInDegrees);
            double area = sideA * sideB * Math.sin(angleInRadians);
            double perimeter = 2 * (sideA + sideB);
            txt_area.setText("Area: " + area);
            txt_permeter.setText("Perimeter: " + perimeter);
        } else {
            Toast.makeText(this, "Please enter all values", Toast.LENGTH_SHORT).show();
        }
    }

    private void calculateCircularSector() {
        String radiusValue = edt_circular_radius.getText().toString();
        String angleValue = edt_Circular_anagle.getText().toString();
        if (!radiusValue.isEmpty() && !angleValue.isEmpty()) {
            double radius = Double.parseDouble(radiusValue);
            double angle = Double.parseDouble(angleValue);
            double area = (angle / 360) * Math.PI * Math.pow(radius, 2);
            double perimeter = 2 * radius + (angle / 360) * 2 * Math.PI * radius;
            txt_area.setText("Area: " + area);
            txt_permeter.setText("Perimeter: " + perimeter);
        } else {
            Toast.makeText(this, "Please enter both radius and angle", Toast.LENGTH_SHORT).show();
        }
    }

    private void calculateQuadrilateral() {
        String sideAValue = edt_Quadrilateral_a.getText().toString();
        String sideBValue = edt_Quadrilateral_b.getText().toString();
        String sideCValue = edt_Quadrilateral_c.getText().toString();
        String sideDValue = edt_Quadrilateral_d.getText().toString();

        if (!sideAValue.isEmpty() && !sideBValue.isEmpty() && !sideCValue.isEmpty() && !sideDValue.isEmpty()) {
            double a = Double.parseDouble(sideAValue);
            double b = Double.parseDouble(sideBValue);
            double c = Double.parseDouble(sideCValue);
            double d = Double.parseDouble(sideDValue);

            double perimeter = a + b + c + d;

            double s = perimeter / 2;
            double area = Math.sqrt((s - a) * (s - b) * (s - c) * (s - d));

            txt_area.setText("Area: " + area);
            txt_permeter.setText("Perimeter: " + perimeter);
        } else {
            Toast.makeText(this, "Please enter all four side values", Toast.LENGTH_SHORT).show();
        }


    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}