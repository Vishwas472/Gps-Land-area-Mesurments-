package gps.landareacalculator.landmeasurement.field.areameasure.Activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.SphericalUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import gps.landareacalculator.landmeasurement.field.areameasure.Adpter.KmlFileReaderAdpter;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.AppCompany_const;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.PrefManager;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.BaseActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.DatabaseHelper;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.KMLParser;
import gps.landareacalculator.landmeasurement.field.areameasure.Modelclass.MesurmentModel;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class KmlFileReaderActivity extends BaseActivity implements OnMapReadyCallback {
    private GoogleMap map;
    Toolbar toolbar;
    private DatabaseHelper dbHelper;
    private List<MesurmentModel> placemarkList;
    private List<MesurmentModel> map_Snap_shot_list = new ArrayList<>();
    private RelativeLayout rel_save;
    private TextView txt_Satutus;
    SupportMapFragment mapFragment;
    RelativeLayout rel_Progressbar, rel_map;
    private int polygonColor = Color.argb(51, 255, 0, 0);
    public KmlFileReaderAdpter adpter_kml_file;
    private RecyclerView rcv_kml_file_read;
    ImageView img_back ;

    PrefManager prefManager;
    RelativeLayout layout;

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kml_file_reader);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        prefManager = new PrefManager(KmlFileReaderActivity.this);
        layout = (RelativeLayout) findViewById(R.id.adView);
        if (!prefManager.getvalue()) {
            if (AppCompany_const.isActive_adMob) {
                com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(this);
                adView.setAdSize(getAdSize());
                adView.setAdUnitId(AppCompany_const.BANNER_AD_PUB_ID);
                layout.addView(adView);
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);

            }
        }


        rcv_kml_file_read = findViewById(R.id.rcv_kml_file_read);
        rcv_kml_file_read.setLayoutManager(new LinearLayoutManager(this));
        rel_save = findViewById(R.id.rel_save);
        txt_Satutus = findViewById(R.id.txt_Satutus);
        rel_Progressbar = findViewById(R.id.rel_Progressbar);
        rel_map = findViewById(R.id.rel_map);
        img_back = findViewById(R.id.img_back);

        dbHelper = new DatabaseHelper(this);
        placemarkList = new ArrayList<>();

        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        Intent intent = getIntent();
        String kmlFileUriString = intent.getStringExtra("KML_FILE_URI");
        if (kmlFileUriString != null) {
            Uri kmlFileUri = Uri.parse(kmlFileUriString);
            loadKmlData(kmlFileUri);
        } else {
            Toast.makeText(this, "No KML file provided", Toast.LENGTH_SHORT).show();
        }
        adpter_kml_file = new KmlFileReaderAdpter(map_Snap_shot_list);
        rcv_kml_file_read.setAdapter(adpter_kml_file);

        rel_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<MesurmentModel> selectedPlacemarks = adpter_kml_file.getSelectedPlacemarks();
                if (selectedPlacemarks.isEmpty()) {
                    Toast.makeText(KmlFileReaderActivity.this, "No placemarks selected", Toast.LENGTH_SHORT).show();
                    return;
                }

                for (MesurmentModel placemark : selectedPlacemarks) {
                    String name = placemark.getName();
                    String type = placemark.getMarkerPoints();
                    String description = placemark.getDistanceType();
                    Bitmap image = placemark.getBitmap();


                    double Area = placemark.getArea();

                    if (description == null || description.trim().isEmpty()) {
                        return;
                    }

                    String[] coordinateParts = description.trim().split("\\s+");
                    JSONArray jsonArray = new JSONArray();

                    for (String coordinatePart : coordinateParts) {
                        String[] latLong = coordinatePart.replace("(", "").replace(")", "").split(",");
                        if (latLong.length >= 2) {
                            try {
                                double latitude = Double.parseDouble(latLong[1].trim());
                                double longitude = Double.parseDouble(latLong[0].trim());

                                JSONObject jsonObject = new JSONObject();
                                jsonObject.put("latitude", latitude);
                                jsonObject.put("longitude", longitude);

                                jsonArray.put(jsonObject);

                                Log.d("golu ji", "onBindViewHolder: " + jsonObject.toString());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    String jsonString = jsonArray.toString();
                    String imageString = saveBitmapToFile(image);


                    dbHelper.insertPolygonData(name, Area, jsonString, "", "meter", "Street View", "", type, imageString, polygonColor);

                }

                Toast.makeText(KmlFileReaderActivity.this, "Data Saved Succesfully ", Toast.LENGTH_SHORT).show();
            }
        });
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    @Override
    public void onMapReady(GoogleMap map) {
        this.map = map;
        updateMap();
    }

    private String saveBitmapToFile(Bitmap bitmap) {
        File directory = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "PolygonImages");
        if (!directory.exists()) {
            directory.mkdirs();
        }

        String fileName = "polygon_" + System.currentTimeMillis() + ".png";
        File imageFile = new File(directory, fileName);

        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

        return imageFile.getAbsolutePath();
    }

    private void loadKmlData(Uri kmlFileUri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(kmlFileUri);
            if (inputStream != null) {
                placemarkList = KMLParser.parseKML(inputStream);
                updateMap();
            } else {
                Toast.makeText(this, "Error opening the selected file", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error reading the KML file", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateMap() {
        if (map == null || placemarkList.isEmpty()) return;

        map.clear();
        final Handler handler = new Handler();
        final int delay = 2000;
        final int[] index = {0};

        Runnable stepByStepRunnable = new Runnable() {
            @Override
            public void run() {
                if (index[0] < placemarkList.size()) {
                    MesurmentModel placemark = placemarkList.get(index[0]);
                    map.clear();

                    if (placemark.getDistanceType().equalsIgnoreCase("polygon")) {
                        drawPolygon(map, placemark.getMarkerPoints(), txt_Satutus, placemark);
                    } else if (placemark.getDistanceType().equalsIgnoreCase("linestring")) {
                        drawLineString(map, placemark.getMarkerPoints(), txt_Satutus, placemark);
                    } else {
                        addMarkersFromIntent(map, placemark.getMarkerPoints());
                    }

                    handler.postDelayed(() -> captureMapScreen(placemark.getName(), placemark.getArea(), placemark.getMarkerPoints(), placemark.getDistanceType()), 1500);

                    index[0]++;
                    handler.postDelayed(this, delay);
                }
            }
        };
        handler.post(stepByStepRunnable);
    }

    private void captureMapScreen(String name, double Area, String coordinates, String type) {
        map.snapshot(new GoogleMap.SnapshotReadyCallback() {
            @Override
            public void onSnapshotReady(Bitmap bitmap) {
                if (bitmap != null) {
                    map_Snap_shot_list.add(new MesurmentModel(name, Area, bitmap, coordinates, type));
                    updateRecyclerView();

                    if (map_Snap_shot_list.size() == placemarkList.size()) {

                        rel_map.setVisibility(View.GONE);
                        rel_Progressbar.setVisibility(View.GONE);
                    }
                }
            }
        });
    }

    private void updateRecyclerView() {
        if (adpter_kml_file == null) {
            adpter_kml_file = new KmlFileReaderAdpter(map_Snap_shot_list);
            rcv_kml_file_read.setAdapter(adpter_kml_file);
        } else {
            adpter_kml_file.notifyDataSetChanged();
        }
    }

    private void drawPolygon(GoogleMap map, String coordinates, TextView areaTextView, MesurmentModel placemark) {
        if (coordinates == null || coordinates.trim().isEmpty()) {
            return;
        }

        String[] coordinateParts = coordinates.trim().split("\\s+");
        List<LatLng> polygonPoints = new ArrayList<>();
        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();

        for (String coordinatePart : coordinateParts) {
            String[] latLong = coordinatePart.replace("(", "").replace(")", "").split(",");
            if (latLong.length >= 2) {
                try {
                    double latitude = Double.parseDouble(latLong[1].trim());
                    double longitude = Double.parseDouble(latLong[0].trim());

                    LatLng point = new LatLng(latitude, longitude);
                    polygonPoints.add(point);
                    boundsBuilder.include(point);

                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }
        int polygonColor = Color.argb(51, 255, 0, 0);
        int strokeColor = ContextCompat.getColor(this, R.color.RED);

        if (!polygonPoints.isEmpty()) {
            PolygonOptions polygonOptions = new PolygonOptions()
                    .addAll(polygonPoints)
                    .strokeColor(strokeColor)
                    .strokeWidth(5)
                    .fillColor(polygonColor);
            map.addPolygon(polygonOptions);

            try {
                LatLngBounds bounds = boundsBuilder.build();
                int padding = 70;
                CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, padding);
                map.animateCamera(cu);
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }

            double area = SphericalUtil.computeArea(polygonPoints);
            placemark.setArea(area);

            areaTextView.setText(String.format("Area: %.2f m² ", placemark.getArea()));
        }
    }

    private void drawLineString(GoogleMap map, String coordinates, TextView areaTextView, MesurmentModel placemark) {
        if (coordinates == null || coordinates.trim().isEmpty()) {
            return;
        }

        String[] coordinateParts = coordinates.trim().split("\\s+");
        List<LatLng> linePoints = new ArrayList<>();
        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();

        for (String coordinatePart : coordinateParts) {
            String[] latLong = coordinatePart.replace("(", "").replace(")", "").split(",");
            if (latLong.length >= 2) {
                try {
                    double latitude = Double.parseDouble(latLong[1].trim());
                    double longitude = Double.parseDouble(latLong[0].trim());
                    LatLng point = new LatLng(latitude, longitude);
                    linePoints.add(point);
                    boundsBuilder.include(point);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }

        if (!linePoints.isEmpty()) {
            int strokeColor = ContextCompat.getColor(this, R.color.color_primary);

            map.addPolyline(new PolylineOptions().addAll(linePoints).color(strokeColor));

            try {
                LatLngBounds bounds = boundsBuilder.build();
                int padding = 70;
                CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, padding);
                map.animateCamera(cu);
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }

            double length = SphericalUtil.computeLength(linePoints);
            placemark.setArea(length);
            areaTextView.setText(String.format("Length: %.2f m", placemark.getArea()));
        }
    }

    private void addMarkersFromIntent(GoogleMap map, String coordinates) {
        if (coordinates == null || coordinates.trim().isEmpty()) {
            return;
        }

        String[] coordinateParts = coordinates.trim().split("\\s+");
        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();

        for (String coordinatePart : coordinateParts) {
            String[] latLong = coordinatePart.replace("(", "").replace(")", "").split(",");
            if (latLong.length >= 2) {
                try {
                    double latitude = Double.parseDouble(latLong[1].trim());
                    double longitude = Double.parseDouble(latLong[0].trim());
                    LatLng point = new LatLng(latitude, longitude);

                    map.addMarker(new MarkerOptions().position(point).title("Lat: " + latitude + ", Lng: " + longitude));

                    boundsBuilder.include(point);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }

        if (map != null) {
            try {
                LatLngBounds bounds = boundsBuilder.build();
                int padding = 70;
                CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, padding);
                map.animateCamera(cu);
            } catch (IllegalStateException e) {
                e.printStackTrace();
            }
        }
    }


    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
