package gps.landareacalculator.landmeasurement.field.areameasure.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.AppCompany_const;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.PrefManager;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.BaseActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.DatabaseHelper;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class AutomaticDistanceCalculateActivity extends BaseActivity implements OnMapReadyCallback {
    private GoogleMap map;
    private MapView mapView;
    DatabaseHelper databaseHelper;
    private List<Marker> all_marker_list = new ArrayList<>();
    private List<Float> polyline_segment_legnth_list = new ArrayList<>();
    private List<Float> polyline_distance_list = new ArrayList<>();
    private List<Marker> marker_list = new ArrayList<>();
    private List<LatLng> polyline_point_list = new ArrayList<>();
    private Polyline polyline;
    Toolbar toolbar;
    private ImageView img_start_tracking,
            img_stop_tracking,img_map_type,img_Delet,img_back,img_current_location;
    private TextView txt_distance, txt_total_marker;
    public Spinner sp_permeter_unit;
    RelativeLayout rel_save;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationRequest locationRequest;
    private LocationCallback locationCallback;
    private boolean isTracking = false;
    private boolean isPaused = false;
    int color ;
    private float totalDistance = 0f;
    private LatLng lastLocation = null;
    private int totalMarkers = 0;
    private long lastMarkerTimestamp = 0;
    private String str_selected_unit = "Meters";
    private String str_current_map_type = "Street View";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;
    private static final int LOCATION_REQUEST_CODE = 1001;
    private static final long MARKER_INTERVAL = 14000;

    PrefManager prefManager;
    RelativeLayout layout;

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_automatic_distance_calculate);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        prefManager = new PrefManager(AutomaticDistanceCalculateActivity.this);
        layout = (RelativeLayout) findViewById(R.id.adView);
        if (!prefManager.getvalue()) {
            if (AppCompany_const.isActive_adMob) {
                com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(this);
                adView.setAdSize(getAdSize());
                adView.setAdUnitId(AppCompany_const.BANNER_AD_PUB_ID);
                layout.addView(adView);
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);

            }
        }


        mapView = findViewById(R.id.mapView);
        img_Delet = findViewById(R.id.img_Delet);
        img_start_tracking = findViewById(R.id.img_start_tracking);
        img_stop_tracking = findViewById(R.id.img_stop_tracking);
        img_map_type = findViewById(R.id.img_map_type);

        txt_distance = findViewById(R.id.txt_distance);
        txt_total_marker = findViewById(R.id.txt_total_marker);
        sp_permeter_unit = findViewById(R.id.sp_permeter_unit);
        rel_save = findViewById(R.id.rel_save);
        img_back = findViewById(R.id.img_back);
        img_current_location = findViewById(R.id.img_current_location);


        databaseHelper = new DatabaseHelper(this);


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.permeter_units, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_permeter_unit.setAdapter(adapter);

        sp_permeter_unit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                str_selected_unit = parent.getItemAtPosition(position).toString();
                updateDistanceDisplay();
                updateAllPolylineData(str_selected_unit);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        locationRequest = LocationRequest.create();
        locationRequest.setInterval(5000);
        locationRequest.setFastestInterval(3000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null || !isTracking) return;

                for (Location location : locationResult.getLocations()) {
                    LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
                    updatePolyline(currentLocation);
                }
            }
        };

        img_start_tracking.setOnClickListener(v -> {
            if (isPaused) {
                resumeTracking();
            } else {
                startTracking();
            }
        });
        img_stop_tracking.setOnClickListener(v -> pauseTracking());
        rel_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSaveDialog();

            }
        });
        img_map_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMapTypeDialog();

            }
        });

        img_Delet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (map != null) {

                    for (Marker marker : all_marker_list) {
                        marker.remove();
                    }
                    all_marker_list.clear();
                    marker_list.clear();
                    totalMarkers = 0;
                    txt_total_marker.setText("Total Markers: 0");


                    if (polyline != null) {
                        polyline.remove();
                        polyline = null;
                    }
                    polyline_point_list.clear();
                    polyline_segment_legnth_list.clear();
                    polyline_distance_list.clear();
                    totalDistance = 0f;
                    txt_distance.setText("Distance: 0 km");


                    lastLocation = null;
                    isTracking = false;
                    isPaused = false;
                    fusedLocationClient.removeLocationUpdates(locationCallback);


                    map.clear();


                    img_start_tracking.setEnabled(true);
                    img_stop_tracking.setEnabled(false);

                }
            }
        });

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        img_current_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getCurrentLocation();
            }
        });
    }
    @Override
    public void onMapReady(@NonNull GoogleMap map) {
        this.map = map;

        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 5));
            } else {
                LatLng defaultLocation = new LatLng(20.5937, 78.9629);
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 5));
            }
        });

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);
            return;
        }

        map.setMyLocationEnabled(true);
        checkLocationPermission();

    }
    private void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15));
            }
        });
    }
    private void showSaveDialog() {

        Dialog dialog = new Dialog(AutomaticDistanceCalculateActivity.this);
        dialog.setContentView(R.layout.custom_dialog_save);
        dialog.setCancelable(true);

        EditText dialogEditText = dialog.findViewById(R.id.dialog_name_input);
        RelativeLayout btnSave = dialog.findViewById(R.id.rel_save);
        RelativeLayout btnCancel = dialog.findViewById(R.id.rel_cancel);

        dialog.setCancelable(true);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );


        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = dialogEditText.getText().toString().trim();
                if (data.isEmpty()) {
                    Toast.makeText(AutomaticDistanceCalculateActivity.this, "Please enter data!", Toast.LENGTH_SHORT).show();
                    return;
                }


                JSONArray pointsArray = new JSONArray();
                for (Marker marker : all_marker_list) {
                    LatLng position = marker.getPosition();
                    try {
                        JSONObject point = new JSONObject();
                        point.put("latitude", position.latitude);
                        point.put("longitude", position.longitude);
                        pointsArray.put(point);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                JSONArray MidpointsArray = new JSONArray();
                for (Marker marker : marker_list) {
                    LatLng position = marker.getPosition();
                    try {
                        JSONObject point = new JSONObject();
                        point.put("latitude", position.latitude);
                        point.put("longitude", position.longitude);
                        pointsArray.put(point);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                double convertedDistance = convertDistance(totalDistance, str_selected_unit);
                map.snapshot(bitmap -> {
                    if (bitmap != null) {

                        String encodedImage = saveBitmapToFile(bitmap);

                        databaseHelper.insertPolygonData(
                                data, convertedDistance, pointsArray.toString(), MidpointsArray.toString(),str_selected_unit,
                                str_current_map_type, "", "AUTO_MANNUAL_DISTANCE",encodedImage,color);

                        Toast.makeText(AutomaticDistanceCalculateActivity.this, "Distance saved successfully", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    } else {
                        Toast.makeText(AutomaticDistanceCalculateActivity.this, "Failed to capture screenshot", Toast.LENGTH_SHORT).show();

                    }
                });





                Toast.makeText(AutomaticDistanceCalculateActivity.this, "Saved Successfully", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });


        dialog.show();

    }
    private void checkLocationPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        }
    }
    private String saveBitmapToFile(Bitmap bitmap) {
        File directory = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "PolygonImages");
        if (!directory.exists()) {
            directory.mkdirs();
        }

        String fileName = "polygon_" + System.currentTimeMillis() + ".png";
        File imageFile = new File(directory, fileName);

        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

        return imageFile.getAbsolutePath();
    }
    private void startTracking() {
        if (isTracking) return;

        isTracking = true;
        isPaused = false;
        img_start_tracking.setEnabled(false);
        img_stop_tracking.setEnabled(true);


        if (polyline == null) {
            int strokeColor = ContextCompat.getColor(this, R.color.color_primary);
            polyline = map.addPolyline(new PolylineOptions().color(strokeColor).width(8f));
        }

        if (polyline_point_list.isEmpty()) {
            polyline_point_list = new ArrayList<>();
            polyline.setPoints(polyline_point_list);
        }
        txt_distance.setText(String.format("Distance: %.2f meters", totalDistance));
        txt_total_marker.setText("Total Markers: " + totalMarkers);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null && lastLocation == null) {
                LatLng startLocation = new LatLng(location.getLatitude(), location.getLongitude());
                map.addMarker(new MarkerOptions().position(startLocation).title("Start Point").icon(getCustomMarkerIcon(R.drawable.purple_marker)));
                lastLocation = startLocation;
                totalMarkers++;
                txt_total_marker.setText("Total Markers: " + totalMarkers);


                all_marker_list.add(map.addMarker(new MarkerOptions()
                        .position(startLocation)
                        .title("Start Point").
                        icon(getCustomMarkerIcon(R.drawable.purple_marker))));
                Toast.makeText(this, "Start Tracking ", Toast.LENGTH_SHORT).show();
            }
        });

        startLocationUpdates();
    }
    private BitmapDescriptor getCustomMarkerIcon(int drawableResId) {
        Drawable drawable = getResources().getDrawable(drawableResId);
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
    private void pauseTracking() {
        if (!isTracking) return;

        isTracking = false;
        isPaused = true;
        img_start_tracking.setEnabled(true);
        img_stop_tracking.setEnabled(false);

        fusedLocationClient.removeLocationUpdates(locationCallback);

        if (lastLocation != null) {
            map.addMarker(new MarkerOptions().position(lastLocation).title("Paused Point").icon(getCustomMarkerIcon(R.drawable.purple_marker)));
            totalMarkers++;
            txt_total_marker.setText("Total Markers: " + totalMarkers);
            all_marker_list.add(map.addMarker(new MarkerOptions()
                    .position(lastLocation)
                    .title("Paused Point").icon(getCustomMarkerIcon(R.drawable.purple_marker))));
            Toast.makeText(this, "Tracking Stop ", Toast.LENGTH_SHORT).show();
        }
    }
    private void resumeTracking() {
        if (!isPaused) return;

        isTracking = true;
        isPaused = false;
        img_start_tracking.setEnabled(false);
        img_stop_tracking.setEnabled(true);

        startLocationUpdates();
    }
    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);
            return;
        }

        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
    }
    private void updatePolyline(LatLng currentLocation) {
        if (lastLocation != null) {
            float[] results = new float[1];
            Location.distanceBetween(lastLocation.latitude, lastLocation.longitude,
                    currentLocation.latitude, currentLocation.longitude, results);
            float segmentLengthInMeters = results[0];


            polyline_segment_legnth_list.add(segmentLengthInMeters);


            polyline_point_list.add(currentLocation);
            if (polyline != null) {
                polyline.setPoints(polyline_point_list);
            }
        }

        lastLocation = currentLocation;

        updateDistanceDisplay();

        long currentTime = System.currentTimeMillis();
        if (currentTime - lastMarkerTimestamp >= MARKER_INTERVAL) {
            if (!all_marker_list.isEmpty()) {
                LatLng lastMarkerPosition = all_marker_list.get(all_marker_list.size() - 1).getPosition();
                float[] markerResults = new float[1];
                Location.distanceBetween(lastMarkerPosition.latitude, lastMarkerPosition.longitude,
                        currentLocation.latitude, currentLocation.longitude, markerResults);
                float markerSegmentLength = markerResults[0];
                polyline_distance_list.add(markerSegmentLength);

                LatLng midPoint = new LatLng(
                        (lastMarkerPosition.latitude + currentLocation.latitude) / 2,
                        (lastMarkerPosition.longitude + currentLocation.longitude) / 2
                );
                String markerDistanceText = convertDistances(markerSegmentLength, str_selected_unit);
                Marker distanceMarker = map.addMarker(new MarkerOptions()
                        .position(midPoint)
                        .icon(BitmapDescriptorFactory.fromBitmap(createTextBitmap(markerDistanceText))));
                totalDistance += markerSegmentLength;

                if (marker_list != null) {
                    marker_list.add(distanceMarker);
                }

            }


            Marker marker = map.addMarker(new MarkerOptions()
                    .position(currentLocation)
                    .title("Marker " + (totalMarkers + 1)).icon(getCustomMarkerIcon(R.drawable.purple_marker)));


            all_marker_list.add(marker);
            totalMarkers++;
            txt_total_marker.setText("Total Markers: " + totalMarkers);
            lastMarkerTimestamp = currentTime;
        }

        map.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 15));
    }
    private void updateAllPolylineData(String str_selected_unit) {

        for (Marker marker : marker_list) {
            marker.remove();
        }
        marker_list.clear();
        for (int i = 0; i < polyline_distance_list.size(); i++) {
            float distanceInMeters = polyline_distance_list.get(i);

            String convertedDistanceText = convertDistances(
                    distanceInMeters, str_selected_unit);

            if (i < all_marker_list.size()) {
                Marker marker = all_marker_list.get(i);
                Bitmap updatedBitmap = createTextBitmap(convertedDistanceText);
                marker.setIcon(BitmapDescriptorFactory.fromBitmap(updatedBitmap));
            }
        }
    }
    private void showMapTypeDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_map_type, null);

        CheckBox checkStreetView = dialogView.findViewById(R.id.check_street_view);
        CheckBox checkSatelliteView = dialogView.findViewById(R.id.check_satilite_view);
        CheckBox checkTerrainView = dialogView.findViewById(R.id.check_terrain_view);
        CheckBox checkHybridView = dialogView.findViewById(R.id.check_hybrid_view);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();

        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        switch (str_current_map_type) {
            case "Street View":
                checkStreetView.setChecked(true);
                break;
            case "Satellite View":
                checkSatelliteView.setChecked(true);
                break;
            case "Terrain View":
                checkTerrainView.setChecked(true);
                break;
            case "Hybrid View":
                checkHybridView.setChecked(true);
                break;
        }


        View.OnClickListener listener = v -> {

            checkStreetView.setChecked(false);
            checkSatelliteView.setChecked(false);
            checkTerrainView.setChecked(false);
            checkHybridView.setChecked(false);
            ((CheckBox) v).setChecked(true);
            if (v == checkStreetView) {
                map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                str_current_map_type = "Street View";
            } else if (v == checkSatelliteView) {
                map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                str_current_map_type = "Satellite View";
            } else if (v == checkTerrainView) {
                map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                str_current_map_type = "Terrain View";
            } else if (v == checkHybridView) {
                map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                str_current_map_type = "Hybrid View";
            }


            dialog.dismiss();
        };
        checkStreetView.setOnClickListener(listener);
        checkSatelliteView.setOnClickListener(listener);
        checkTerrainView.setOnClickListener(listener);
        checkHybridView.setOnClickListener(listener);

        dialog.show();
    }
    private void updateDistanceDisplay() {
        float convertedDistance = convertDistance(totalDistance, str_selected_unit);
        txt_distance.setText(String.format("Distance: %.2f %s", convertedDistance, str_selected_unit));
    }
    private String convertDistances(float distanceInMeters, String unit) {
        switch (unit) {
            case "Kilometers":
                return String.format("%.2f Km", distanceInMeters / 1000);
            case "Miles":
                return String.format("%.2f Mi", distanceInMeters / 1609.34);
            case "Feet":
                return String.format("%.2f Ft", distanceInMeters * 3.28084);
            case "Yards":
                return String.format("%.2f Yd", distanceInMeters * 1.09361);
            case "Hectares":
                return String.format("%.2f H", distanceInMeters / 100);
            default:
                return String.format("%.2f M", distanceInMeters);
        }
    }
    private float convertDistance(float distanceInMeters, String unit) {
        switch (unit) {
            case "Kilometers":
                return distanceInMeters / 1000;
            case "Yards":
                return distanceInMeters * 1.09361f;
            case "Feet":
                return distanceInMeters * 3.28084f;
            case "Miles":
                return distanceInMeters * 0.000621371f;
            case "Hectares":
                return distanceInMeters / 10000;
            default:
                return distanceInMeters;
        }
    }
    private Bitmap createTextBitmap(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextSize(14);
        textView.setTextColor(Color.BLACK);
        textView.setBackgroundColor(getResources().getColor(R. color. white_with_low_opacity));

        textView.setPadding(5, 5, 5, 5);

        textView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        Bitmap bitmap = Bitmap.createBitmap(textView.getMeasuredWidth(), textView.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        textView.layout(0, 0, textView.getMeasuredWidth(), textView.getMeasuredHeight());
        textView.draw(canvas);

        return bitmap;
    }
    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }
    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause();
        if (isTracking) {
            pauseTracking();
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
        fusedLocationClient.removeLocationUpdates(locationCallback);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST_CODE && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (isTracking) {
                startLocationUpdates();
            }


        }
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation();
            }
        }

    }
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);


    }


    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

}