package gps.landareacalculator.landmeasurement.field.areameasure.Activity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Objects;

import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.BaseActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class CustomShapeAreaCalculationActivity extends BaseActivity {
    Toolbar toolbar;

    private Spinner sp_spinner_shape;
    private EditText edt_side_value_1, edt_side_value_2, edt_side_value_3, edt_side_value_4, edt_side_value_5;
    private RelativeLayout rel_Calculate, rel_slid_4, rel_slid_5;
    private TextView txt_area, txt_permeter;
    ImageView img_back ;
    CardView card_change_unit;
    private double perimeter, area;
    private String str_selected_perameter = "meters";
    private String str_selected_area_unit = "Square Meters (m²)";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_shape_area_calculation);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
      
        sp_spinner_shape = findViewById(R.id.sp_spinner_shape);
        txt_area = findViewById(R.id.txt_area);
        txt_permeter = findViewById(R.id.txt_permeter);
        edt_side_value_1 = findViewById(R.id.edt_side_value_1);
        edt_side_value_2 = findViewById(R.id.edt_side_value_2);
        edt_side_value_3 = findViewById(R.id.edt_side_value_3);
        edt_side_value_4 = findViewById(R.id.edt_side_value_4);
        edt_side_value_5 = findViewById(R.id.edt_side_value_5);
        card_change_unit = findViewById(R.id.card_change_unit);
        rel_slid_4 = findViewById(R.id.rel_slid_4);
        rel_slid_5 = findViewById(R.id.rel_slid_5);
        rel_Calculate = findViewById(R.id.rel_Calculate);
        img_back = findViewById(R.id.img_back);


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.shape_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_spinner_shape.setAdapter(adapter);

        sp_spinner_shape.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                handleShapeSelection(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }
        });

        rel_Calculate.setOnClickListener(v -> {
            double side1 = Double.parseDouble(edt_side_value_1.getText().toString());
            double side2 = Double.parseDouble(edt_side_value_2.getText().toString());
            double side3 = Double.parseDouble(edt_side_value_3.getText().toString());
            double side4 = rel_slid_4.getVisibility() == View.VISIBLE ? Double.parseDouble(edt_side_value_4.getText().toString()) : 0;
            double side5 = rel_slid_5.getVisibility() == View.VISIBLE ? Double.parseDouble(edt_side_value_5.getText().toString()) : 0;

            perimeter = side1 + side2 + side3 + side4 + side5;
            area = 0;
            String shape = sp_spinner_shape.getSelectedItem().toString();

            if (shape.equals("3 Sides")) {
                area = calculateTriangleArea(side1, side2, side3);
            } else if (shape.equals("4 Sides")) {
                area = calculateRectangleArea(side1, side2);
            } else if (shape.equals("5 Sides")) {
                area = calculatePentagonArea(side1);
            }

            perimeter = convertPerimeter(perimeter);
            area = convertArea(area);

            txt_area.setText("Area: " + String.format("%.2f", area) + " " + str_selected_area_unit);
            txt_permeter.setText("Distance: " + String.format("%.2f", perimeter) + " " + str_selected_perameter);
        });

        card_change_unit.setOnClickListener(v -> showUnitDialog());

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    private void handleShapeSelection(int position) {
        if (position == 0) {
            rel_slid_4.setVisibility(View.GONE);
            rel_slid_5.setVisibility(View.GONE);
        } else if (position == 1) {
            rel_slid_4.setVisibility(View.VISIBLE);
            rel_slid_5.setVisibility(View.GONE);
        } else if (position == 2) {
            rel_slid_4.setVisibility(View.VISIBLE);
            rel_slid_5.setVisibility(View.VISIBLE);
        }
    }

    private double calculateTriangleArea(double a, double b, double c) {
        double s = (a + b + c) / 2;
        return Math.sqrt(s * (s - a) * (s - b) * (s - c));
    }

    private double calculateRectangleArea(double length, double width) {
        return length * width;
    }

    private double calculatePentagonArea(double side) {
        return (5 * side * side) / (4 * Math.tan(Math.PI / 5));
    }


    private double convertPerimeter(double value) {
        if (str_selected_perameter.equals("kilometers")) {
            return value / 1000;
        } else if (str_selected_perameter.equals("feet")) {
            return value * 3.28084;
        } else if (str_selected_perameter.equals("yards")) {
            return value * 1.09361;
        } else if (str_selected_perameter.equals("miles")) {
            return value / 1609.34;
        } else if (str_selected_perameter.equals("hectares")) {
            return value / 10000;
        }
        return value;
    }

    private double convertArea(double value) {
        if (str_selected_area_unit.equals("Square Kilometers (km²)")) {
            return value / 1e6;
        } else if (str_selected_area_unit.equals("Square Feet (ft²)")) {
            return value * 10.7639;
        } else if (str_selected_area_unit.equals("Square Yards (yd²)")) {
            return value * 1.19599;
        } else if (str_selected_area_unit.equals("Square Miles (mi²)")) {
            return value / 2.58999e6;
        } else if (str_selected_area_unit.equals("Hectares (ha)")) {
            return value / 10000;
        }
        return value;
    }


    private void showUnitDialog() {

        Dialog dialog = new Dialog(CustomShapeAreaCalculationActivity.this);

        dialog.setContentView(R.layout.dialog_unit_change);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"})
        Spinner perimeterSpinner = dialog.findViewById(R.id.spinnerPerimeterUnit);
        Spinner areaSpinner = dialog.findViewById(R.id.spinnerAreaUnit);
        RelativeLayout rel_cancel = dialog.findViewById(R.id.rel_cancel);
        RelativeLayout rel_save = dialog.findViewById(R.id.rel_save);

        ArrayAdapter<CharSequence> perimeterAdapter = ArrayAdapter.createFromResource(this,
                R.array.perimeter_units, android.R.layout.simple_spinner_item);
        perimeterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        perimeterSpinner.setAdapter(perimeterAdapter);

        ArrayAdapter<CharSequence> areaAdapter = ArrayAdapter.createFromResource(this,
                R.array.area_units, android.R.layout.simple_spinner_item);
        areaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        areaSpinner.setAdapter(areaAdapter);

        perimeterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                str_selected_perameter = perimeterSpinner.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }
        });

        areaSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                str_selected_area_unit = areaSpinner.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }
        });


        rel_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        rel_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });


        dialog.setCancelable(true);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );

        dialog.show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}