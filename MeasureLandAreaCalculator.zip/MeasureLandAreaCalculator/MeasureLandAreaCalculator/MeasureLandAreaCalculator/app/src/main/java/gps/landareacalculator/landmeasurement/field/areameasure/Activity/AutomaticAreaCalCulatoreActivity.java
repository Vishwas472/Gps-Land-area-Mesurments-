package gps.landareacalculator.landmeasurement.field.areameasure.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.flask.colorpicker.ColorPickerView;
import com.flask.colorpicker.OnColorSelectedListener;
import com.flask.colorpicker.builder.ColorPickerClickListener;
import com.flask.colorpicker.builder.ColorPickerDialogBuilder;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.maps.android.SphericalUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.AppCompany_const;
import gps.landareacalculator.landmeasurement.field.areameasure.AppcompanyCommon.PrefManager;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.BaseActivity;
import gps.landareacalculator.landmeasurement.field.areameasure.OtherClass.DatabaseHelper;
import gps.landareacalculator.landmeasurement.field.areameasure.R;

public class AutomaticAreaCalCulatoreActivity extends BaseActivity implements OnMapReadyCallback {
    private GoogleMap map;
    DatabaseHelper databaseHelper;
    private List<Float> Polyline_distance_list = new ArrayList<>();
    private ArrayList<LatLng> poly_line_point_list = new ArrayList<>();
    private ArrayList<LatLng> marker_point_list = new ArrayList<>();
    private ArrayList<Marker> marker_list = new ArrayList<>();
    private List<Marker> Midpoint_marker_list = new ArrayList<>();
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;
    private Polyline currentPolyline;
    private Polygon polygon;
    private int polygonColor = Color.argb(51, 255, 0, 0);
    private FusedLocationProviderClient fusedLocationProviderClient;
    private LocationCallback locationCallback;
    private LatLng lastLocationLatLng;
    Toolbar toolbar;
    private ImageView img_start_tracking,
            img_stop_tracking,
            img_current_location,
            img_delet,
            img_map_type,
            img_colour,
            img_back;
    private TextView txt_area,
            txt_total_marker;
    private RelativeLayout rel_save;
    private Spinner sp_area_unit, sp_permeter_unit;
    private long lastMarkerTime = 0;
    private static final long MARKER_INTERVAL = 15000;
    double polygonArea = 0.0;
    private String str_selcted_unit = "meter";
    private String str_current_map_type = "Street View";
    private boolean isTracking = false;
    private float Flt_polyline_legnth_in_meter = 0f;


    PrefManager prefManager;
    RelativeLayout layout;

    private AdSize getAdSize() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);
        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;
        int adWidth = (int) (widthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_automatic_area_calculatore);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        prefManager = new PrefManager(AutomaticAreaCalCulatoreActivity.this);
        layout = (RelativeLayout) findViewById(R.id.adView);
        if (!prefManager.getvalue()) {
            if (AppCompany_const.isActive_adMob) {
                com.google.android.gms.ads.AdView adView = new com.google.android.gms.ads.AdView(this);
                adView.setAdSize(getAdSize());
                adView.setAdUnitId(AppCompany_const.BANNER_AD_PUB_ID);
                layout.addView(adView);
                AdRequest adRequest = new AdRequest.Builder().build();
                adView.loadAd(adRequest);

            }
        }


        img_start_tracking = findViewById(R.id.img_start_tracking);
        img_stop_tracking = findViewById(R.id.img_stop_tracking);
        rel_save = findViewById(R.id.rel_save);
        txt_area = findViewById(R.id.txt_area);
        txt_total_marker = findViewById(R.id.txt_total_marker);
        sp_area_unit = findViewById(R.id.sp_area_unit);
        sp_permeter_unit = findViewById(R.id.sp_permeter_unit);
        img_delet = findViewById(R.id.img_delet);
        img_map_type = findViewById(R.id.img_map_type);
        img_colour = findViewById(R.id.img_colour);
        img_current_location = findViewById(R.id.img_current_location);
        img_back = findViewById(R.id.img_back);

        databaseHelper = new DatabaseHelper(this);


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);


        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {

                if (locationResult == null || !isTracking) return;

                Location location = locationResult.getLastLocation();
                LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());

                if (System.currentTimeMillis() - lastMarkerTime >= MARKER_INTERVAL) {
                    lastMarkerTime = System.currentTimeMillis();
                    if (lastLocationLatLng == null || !currentLatLng.equals(lastLocationLatLng)) {
                        poly_line_point_list.add(currentLatLng);
                        addMarker(currentLatLng, "Marker " + marker_list.size());
                        drawPolyline(currentLatLng);
                        lastLocationLatLng = currentLatLng;
                    }
                }


                map.moveCamera(CameraUpdateFactory.newLatLng(currentLatLng));
            }
        };


        img_start_tracking.setOnClickListener(view -> startTracking());


        img_stop_tracking.setOnClickListener(view -> stopTracking());


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.area_units, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_area_unit.setAdapter(adapter);

        sp_area_unit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, android.view.View selectedItemView, int position, long id) {
                str_selcted_unit = parentView.getItemAtPosition(position).toString();
                updateAreaDisplay();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                str_selcted_unit = "meter";
            }
        });
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.permeter_units, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_permeter_unit.setAdapter(adapter2);
        sp_permeter_unit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, android.view.View selectedItemView, int position, long id) {
                str_selcted_unit = parentView.getItemAtPosition(position).toString();

                updatePolylineMarkers();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                str_selcted_unit = "meter";
            }
        });
        img_map_type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMapTypeDialog();

            }
        });
        img_delet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (map != null) {
                    map.clear();
                }
                poly_line_point_list.clear();
                marker_point_list.clear();
                marker_list.clear();
                Polyline_distance_list.clear();
                Flt_polyline_legnth_in_meter = 0f;

                polygonArea = 0.0;


                txt_area.setText("Area: 0");
                txt_total_marker.setText("Markers: 0");


                if (polygon != null) {
                    polygon.remove();
                    polygon = null;
                }
                if (currentPolyline != null) {
                    currentPolyline.remove();
                    currentPolyline = null;
                }

                stopTracking();

            }
        });
        rel_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(AutomaticAreaCalCulatoreActivity.this);
                dialog.setContentView(R.layout.custom_dialog_save);
                dialog.setCancelable(true);


                EditText nameInput = dialog.findViewById(R.id.dialog_name_input);
                RelativeLayout saveButton = dialog.findViewById(R.id.rel_save);
                RelativeLayout cancelButton = dialog.findViewById(R.id.rel_cancel);
                dialog.setCancelable(true);
                Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.getWindow().setLayout(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );

                dialog.show();

                saveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String name = nameInput.getText().toString();
                        if (name.isEmpty()) {
                            Toast.makeText(AutomaticAreaCalCulatoreActivity.this, "Please enter an area name", Toast.LENGTH_SHORT).show();
                        } else {
                            String areaText = txt_area.getText().toString();


                            double areaValue = 0.0;
                            try {
                                String numericAreaText = areaText.replaceAll("[^0-9.]", "");
                                areaValue = Double.parseDouble(numericAreaText);
                            } catch (NumberFormatException e) {
                                Toast.makeText(AutomaticAreaCalCulatoreActivity.this, "Invalid area value", Toast.LENGTH_SHORT).show();
                                return;
                            }


                            JSONArray pointsArray = new JSONArray();
                            for (Marker marker : marker_list) {
                                LatLng position = marker.getPosition();
                                try {
                                    JSONObject point = new JSONObject();
                                    point.put("latitude", position.latitude);
                                    point.put("longitude", position.longitude);
                                    pointsArray.put(point);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }


                            JSONArray Middledata = new JSONArray();
                            for (Marker markerdata : Midpoint_marker_list) {
                                LatLng ssss = markerdata.getPosition();
                                try {
                                    JSONObject point = new JSONObject();
                                    point.put("latitude", ssss.latitude);
                                    point.put("longitude", ssss.longitude);
                                    Middledata.put(point);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }


                            String Areaunit = sp_area_unit.getSelectedItem().toString();
                            String permterunit = sp_permeter_unit.getSelectedItem().toString();


                            double finalAreaValue = areaValue;
                            map.snapshot(bitmap -> {
                                if (bitmap != null) {

                                    String encodedImage = saveBitmapToFile(bitmap);
                                    databaseHelper.insertPolygonData(name, finalAreaValue, pointsArray.toString(), Middledata.toString(), Areaunit, str_current_map_type, permterunit, "AUTO-MANNUAL-AREA", encodedImage, polygonColor);
                                    Toast.makeText(AutomaticAreaCalCulatoreActivity.this, "Polygon saved successfully", Toast.LENGTH_SHORT).show();
                                    dialog.dismiss();
                                } else {

                                    Toast.makeText(AutomaticAreaCalCulatoreActivity.this, "Failed to capture screenshot", Toast.LENGTH_SHORT).show();
                                }
                            });


                            Toast.makeText(AutomaticAreaCalCulatoreActivity.this, "Polygon saved!", Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        }
                    }
                });


                cancelButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();

                    }
                });


            }
        });
        img_colour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openColorPicker();
            }
        });


        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        img_current_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getCurrentLocation();
            }
        });
    }
    public  void getCurrentLocation() {
        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15));
            }
        });
    }
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;
        enableLocation();
        zoomToCurrentCountry();
    }

    private void zoomToCurrentCountry() {
        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                try {
                    List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                    if (addresses != null && !addresses.isEmpty()) {
                        String countryName = addresses.get(0).getCountryName();
                        List<Address> countryAddresses = geocoder.getFromLocationName(countryName, 1);
                        if (countryAddresses != null && !countryAddresses.isEmpty()) {
                            Address countryLocation = countryAddresses.get(0);
                            LatLng countryLatLng = new LatLng(countryLocation.getLatitude(), countryLocation.getLongitude());

                            map.animateCamera(CameraUpdateFactory.newLatLngZoom(countryLatLng, 5.0f));
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
    @SuppressLint("MissingPermission")
    private void startTracking() {
        if (isTracking) {
            Toast.makeText(this, "Already tracking!", Toast.LENGTH_SHORT).show();
            return;
        }

        isTracking = true;
        poly_line_point_list.clear();

        fusedLocationProviderClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 18));
                int strokeColor = ContextCompat.getColor(this, R.color.RED);

                lastLocationLatLng = currentLatLng;
                PolylineOptions polylineOptions = new PolylineOptions().
                        add(currentLatLng)
                        .color(strokeColor)
                        .width(10);
                currentPolyline = map.addPolyline(polylineOptions);


                addMarker(currentLatLng, "Start");
            }
        });


        startLocationUpdates();
    }

    private void stopTracking() {
        if (!isTracking) {
            Toast.makeText(this, "Tracking not started!", Toast.LENGTH_SHORT).show();
            return;
        }

        isTracking = false;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        fusedLocationProviderClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());


                addMarker(currentLatLng, "Stop");
            }
        });


        stopLocationUpdates();
    }

    private void openColorPicker() {
        ColorPickerDialogBuilder
                .with(this)
                .setTitle("Choose color")
                .initialColor(polygonColor)
                .wheelType(ColorPickerView.WHEEL_TYPE.FLOWER)
                .density(12)
                .setOnColorSelectedListener(new OnColorSelectedListener() {
                    @Override
                    public void onColorSelected(int selectedColor) {
                    }
                })
                .setPositiveButton("ok", new ColorPickerClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedColor, Integer[] allColors) {
                        changeBackgroundColor(selectedColor);
                    }
                })
                .setNegativeButton("cancel", (dialog, which) -> {
                })
                .build()
                .show();
    }

    private void enableLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        map.setMyLocationEnabled(true);
    }

    private void changeBackgroundColor(int selectedColor) {
        polygonColor = selectedColor;
        if (polygon != null && marker_list.size() >= 3) {
            int strokeColor = ContextCompat.getColor(this, R.color.RED);
            PolygonOptions polygonOptions = new PolygonOptions()
                    .strokeWidth(5)
                    .strokeColor(strokeColor)
                    .fillColor(polygonColor);
            for (Marker m : marker_list) {
                polygonOptions.add(m.getPosition());
            }
            polygon.remove();
            polygon = map.addPolygon(polygonOptions);
        } else if (marker_list.size() >= 3) {
            createPolygonIfPossible();
        }
    }

    private String saveBitmapToFile(Bitmap bitmap) {
        File directory = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "PolygonImages");
        if (!directory.exists()) {
            directory.mkdirs();
        }

        String fileName = "polygon_" + System.currentTimeMillis() + ".png";
        File imageFile = new File(directory, fileName);

        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

        return imageFile.getAbsolutePath();
    }

    private void updateAreaDisplay() {
        if (marker_point_list.size() >= 3) {
            double area = calculatePolygonArea(marker_point_list);

            int selectedUnitPosition = sp_area_unit.getSelectedItemPosition();
            double convertedArea = convertArea(area, selectedUnitPosition);
            polygonArea = convertedArea;
            txt_area.setText(String.format("Area: %.2f %s", convertedArea, getUnitSuffix(selectedUnitPosition)));
        } else {
            txt_area.setText("Area: 0.00 sq meters");
        }
    }

    private String getUnitSuffix(int unitPosition) {
        switch (unitPosition) {
            case 0:
                return "m²";
            case 1:
                return "km²";
            case 2:
                return "ft²";
            case 3:
                return "yd²";
            case 4:
                return "mi²";
            case 5:
                return "ha";
            default:
                return "m²";
        }
    }

    private void showMapTypeDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_map_type, null);

        CheckBox checkStreetView = dialogView.findViewById(R.id.check_street_view);
        CheckBox checkSatelliteView = dialogView.findViewById(R.id.check_satilite_view);
        CheckBox checkTerrainView = dialogView.findViewById(R.id.check_terrain_view);
        CheckBox checkHybridView = dialogView.findViewById(R.id.check_hybrid_view);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();

        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        switch (str_current_map_type) {
            case "Street View":
                checkStreetView.setChecked(true);
                break;
            case "Satellite View":
                checkSatelliteView.setChecked(true);
                break;
            case "Terrain View":
                checkTerrainView.setChecked(true);
                break;
            case "Hybrid View":
                checkHybridView.setChecked(true);
                break;
        }

        View.OnClickListener listener = v -> {
            checkStreetView.setChecked(false);
            checkSatelliteView.setChecked(false);
            checkTerrainView.setChecked(false);
            checkHybridView.setChecked(false);
            ((CheckBox) v).setChecked(true);
            if (v == checkStreetView) {
                map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                str_current_map_type = "Street View";
            } else if (v == checkSatelliteView) {
                map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                str_current_map_type = "Satellite View";
            } else if (v == checkTerrainView) {
                map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                str_current_map_type = "Terrain View";
            } else if (v == checkHybridView) {
                map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                str_current_map_type = "Hybrid View";
            }


            dialog.dismiss();
        };
        checkStreetView.setOnClickListener(listener);
        checkSatelliteView.setOnClickListener(listener);
        checkTerrainView.setOnClickListener(listener);
        checkHybridView.setOnClickListener(listener);
        dialog.show();
    }

    private void startLocationUpdates() {
        LocationRequest locationRequest = LocationRequest.create().setInterval(5000).setFastestInterval(2000).setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, null);
    }

    private void stopLocationUpdates() {
        fusedLocationProviderClient.removeLocationUpdates(locationCallback);
    }

    private void addMarker(LatLng position, String title) {
        BitmapDescriptor customIcon = bitmapDescriptorFromVector(R.drawable.red_marker);


        Marker marker = map.addMarker(new MarkerOptions()
                .position(position)
                .title(title)
                .icon(customIcon));
        marker_list.add(marker);
        marker_point_list.add(position);


        txt_total_marker.setText("Total Markers: " + marker_list.size());


        if (marker_list.size() >= 3) {
            createPolygonIfPossible();
        }
    }

    private BitmapDescriptor bitmapDescriptorFromVector(int vectorResId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(this, vectorResId);
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());

        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);

        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    private void drawPolyline(LatLng currentLatLng) {
        if (lastLocationLatLng != null) {

            float[] results = new float[1];
            Location.distanceBetween(
                    lastLocationLatLng.latitude, lastLocationLatLng.longitude,
                    currentLatLng.latitude, currentLatLng.longitude, results);
            float distanceInMeters = results[0];

            Polyline_distance_list.add(distanceInMeters);
            Flt_polyline_legnth_in_meter += distanceInMeters;

            String Permeter_unit = sp_permeter_unit.getSelectedItem().toString();
            String distanceText = convertDistanceData(distanceInMeters, Permeter_unit);

            Bitmap distanceBitmap = createTextBitmap(distanceText);
            int strokeColor = ContextCompat.getColor(this, R.color.RED);
            PolylineOptions polylineOptions = new PolylineOptions()
                    .add(lastLocationLatLng, currentLatLng)
                    .color(strokeColor)
                    .width(10);


            map.addPolyline(polylineOptions);

            LatLng midPoint = calculateMidPoint(lastLocationLatLng, currentLatLng);

            MarkerOptions markerOptions = new MarkerOptions()
                    .position(midPoint)
                    .icon(BitmapDescriptorFactory.fromBitmap(distanceBitmap))
                    .anchor(0.5f, 0.5f);
            Marker marker = map.addMarker(markerOptions);
            Midpoint_marker_list.add(marker);
        }

        lastLocationLatLng = currentLatLng;
    }

    private void updatePolylineMarkers() {
        for (int i = 0; i < Midpoint_marker_list.size(); i++) {
            float distanceInMeters = Polyline_distance_list.get(i);
            String updatedDistanceText = convertDistanceData(distanceInMeters, str_selcted_unit);
            Bitmap updatedBitmap = createTextBitmap(updatedDistanceText);

            Midpoint_marker_list.get(i).setIcon(BitmapDescriptorFactory.fromBitmap(updatedBitmap));
        }
    }

    private String convertDistanceData(float distanceInMeters, String str_selcted_unit) {

        switch (str_selcted_unit) {
            case "Kilometers":
                return String.format(Locale.getDefault(), "%.2f km", distanceInMeters / 1000);
            case "Feet":
                return String.format(Locale.getDefault(), "%.2f ft", distanceInMeters * 3.28084);
            case "Yards":
                return String.format(Locale.getDefault(), "%.2f yd", distanceInMeters * 1.09361);
            case "Miles":
                return String.format(Locale.getDefault(), "%.2f mi", distanceInMeters / 1609.34);
            case "Hectares":
                return String.format(Locale.getDefault(), "%.6f ha", distanceInMeters / 10000);
            default:
                return String.format(Locale.getDefault(), "%.2f m", distanceInMeters);
        }

    }

    private LatLng calculateMidPoint(LatLng start, LatLng end) {
        return new LatLng((start.latitude + end.latitude) / 2, (start.longitude + end.longitude) / 2);
    }

    private Bitmap createTextBitmap(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTextSize(14);
        textView.setTextColor(Color.BLACK);
        textView.setBackgroundColor(getResources().getColor(R. color. white_with_low_opacity));
        textView.setPadding(10, 10, 10, 10);
        textView.measure(android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED), android.view.View.MeasureSpec.makeMeasureSpec(0, android.view.View.MeasureSpec.UNSPECIFIED));
        textView.layout(0, 0, textView.getMeasuredWidth(), textView.getMeasuredHeight());
        Bitmap bitmap = Bitmap.createBitmap(textView.getMeasuredWidth(), textView.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        textView.draw(canvas);
        return bitmap;
    }

    private double convertArea(double areaInSquareMeters, int unitPosition) {
        switch (unitPosition) {
            case 0:
                return areaInSquareMeters;
            case 1:
                return areaInSquareMeters / 1_000_000;
            case 2:
                return areaInSquareMeters * 10.7639;
            case 3:
                return areaInSquareMeters * 1.19599;
            case 4:
                return areaInSquareMeters / 2_589_988;
            case 5:
                return areaInSquareMeters / 10_000;
            default:
                return areaInSquareMeters;
        }
    }

    private void createPolygonIfPossible() {
        if (marker_point_list.size() >= 3) {
            if (polygon != null) {
                polygon.remove();
            }
            int strokeColor = ContextCompat.getColor(this, R.color.RED);
            PolygonOptions polygonOptions = new PolygonOptions().addAll(marker_point_list).strokeColor(strokeColor).fillColor(polygonColor);

            polygon = map.addPolygon(polygonOptions);

            double area = calculatePolygonArea(marker_point_list);
            polygonArea = area;
            int selectedUnitPosition = sp_area_unit.getSelectedItemPosition();
            double convertedArea = convertArea(area, selectedUnitPosition);

            txt_area.setText(String.format("Area: %.2f %s", convertedArea, getUnitSuffix(selectedUnitPosition)));
        } else {
            Toast.makeText(this, "Please add at least 3 marker", Toast.LENGTH_SHORT).show();
        }
    }

    private double calculatePolygonArea(ArrayList<LatLng> points) {
        return SphericalUtil.computeArea(points);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            enableLocation();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

}